<?php

define("SYSTEM_VERSION", "1.0.0.0"); // die Version des Systems
// Datenbank Connection 


define("DB_SERVER", "127.0.0.1"); // die adresse des Mysql server
define("DB_DATABASE", "DBName");  // die datenbank die ausgewählt werden soll	
define("DB_USER", "User");   // der User Mit dem sich das system einloggen soll
define("DB_PASS", "Pass");  // Das Passwort für den server
define("DB_PORT", "1433");


define("DOMAIN_NAME", ""); //der domain name
define("LANGUAGE_GER", "Ger");
define("HEAD_TITLE", "");

define("DEBUG_MODE", true );
define("WRITE_CACHE", true ); // ob er den Cache Schreiben soll oder nicht
define("LOG_SQL", true );

define("SMTP_CRYPT", "ssl" );


define("PDO_PSQL", "pgsql"); // pdo postgres
define("PDO_MYSQL", "mysql"); // pdo mysql
define("PDO_MSSQL", "mssql"); // pdo mssql

define("PDO_DRIVER", PDO_MYSQL ); // auf Mysql gestellt

define(SYSTEM_ADMIN_MAIL,"devaron@itservice-herzog.de");
define(SMTP_USERNAME,"devaron@itservice-herzog.de");
define(SMTP_SERVER,"127.0.0.1");
define(SMTP_PORT,"465");
define(SMTP_PASS,"Pass");

define( "SYSTEM_MAIL_ADDRESS_TECHNICAL", "devaron@itservice-herzog.de" );
define( "BASE_URL","api.local" );












?>