<?php

define('BASE_URL', 'http://localhost/');
define('BASE_URL_ADMIN', 'http://localhost/');

define("SYSTEM_NAME","EPL API");
define("DEFAULT_META_TITLT", SYSTEM_NAME );


define("API_KEY", "ydher646urjfnklze4zsehxdhdzu6rjf" );

// space for all const member

  
