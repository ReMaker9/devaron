<?php
class UserCollection extends BaseUserCollection
{

}
?>