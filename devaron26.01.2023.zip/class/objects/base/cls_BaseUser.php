<?php
class BaseUser extends i_CollectionElement 
{
	protected $Id;
	protected $CreateDate;
	protected $Name;
	protected $Pass;
	protected $LastLogin;
	protected $Mail;
	protected $Type;
	protected $AdName;
	protected $Active;
	protected $EntryIds;
	protected $LeasedEmployee;
	protected $Department;
	protected $ErrorReporter;
	protected $MailCC;
	protected $CanPlan;

	function __construct($Id,$CreateDate,$Name,$Pass,$LastLogin,$Mail,$Type,$AdName,$Active,$EntryIds,$LeasedEmployee,$Department,$ErrorReporter,$MailCC,$CanPlan)
	{

		if (is_array($Id))
        	{
        		$this->setValuesFromArray($Id);
        		return;
        	}
        

		$this->Id=$Id;
		$this->CreateDate=$CreateDate;
		$this->Name=$Name;
		$this->Pass=$Pass;
		$this->LastLogin=$LastLogin;
		$this->Mail=$Mail;
		$this->Type=$Type;
		$this->AdName=$AdName;
		$this->Active=$Active;
		$this->EntryIds=$EntryIds;
		$this->LeasedEmployee=$LeasedEmployee;
		$this->Department=$Department;
		$this->ErrorReporter=$ErrorReporter;
		$this->MailCC=$MailCC;
		$this->CanPlan=$CanPlan;
	}

	public function getId()
	{
		return $this->Id;
	}
	public function setId($Id)
	{
		$this->Id=$Id;
	}

	public function getCreateDate()
	{
		return $this->CreateDate;
	}
	public function setCreateDate($CreateDate)
	{
		$this->CreateDate=$CreateDate;
	}

	public function getName()
	{
		return $this->Name;
	}
	public function setName($Name)
	{
		$this->Name=$Name;
	}

	public function getPass()
	{
		return $this->Pass;
	}
	public function setPass($Pass)
	{
		$this->Pass=$Pass;
	}

	public function getLastLogin()
	{
		return $this->LastLogin;
	}
	public function setLastLogin($LastLogin)
	{
		$this->LastLogin=$LastLogin;
	}

	public function getMail()
	{
		return $this->Mail;
	}
	public function setMail($Mail)
	{
		$this->Mail=$Mail;
	}

	public function getType()
	{
		return $this->Type;
	}
	public function setType($Type)
	{
		$this->Type=$Type;
	}

	public function getAdName()
	{
		return $this->AdName;
	}
	public function setAdName($AdName)
	{
		$this->AdName=$AdName;
	}

	public function getActive()
	{
		return $this->Active;
	}
	public function setActive($Active)
	{
		$this->Active=$Active;
	}

	public function getEntryIds()
	{
		return $this->EntryIds;
	}
	public function setEntryIds($EntryIds)
	{
		$this->EntryIds=$EntryIds;
	}

	public function getLeasedEmployee()
	{
		return $this->LeasedEmployee;
	}
	public function setLeasedEmployee($LeasedEmployee)
	{
		$this->LeasedEmployee=$LeasedEmployee;
	}

	public function getDepartment()
	{
		return $this->Department;
	}
	public function setDepartment($Department)
	{
		$this->Department=$Department;
	}

	public function getErrorReporter()
	{
		return $this->ErrorReporter;
	}
	public function setErrorReporter($ErrorReporter)
	{
		$this->ErrorReporter=$ErrorReporter;
	}

	public function getMailCC()
	{
		return $this->MailCC;
	}
	public function setMailCC($MailCC)
	{
		$this->MailCC=$MailCC;
	}

	public function getCanPlan()
	{
		return $this->CanPlan;
	}
	public function setCanPlan($CanPlan)
	{
		$this->CanPlan=$CanPlan;
	}

	public static function getEmptyInstance()
	{
	    return new User($Id,$CreateDate,$Name,$Pass,$LastLogin,$Mail,$Type,$AdName,$Active,$EntryIds,$LeasedEmployee,$Department,$ErrorReporter,$MailCC,$CanPlan);
	}
}
		?>