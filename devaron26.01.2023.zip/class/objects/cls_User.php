<?php
class User extends BaseUser
{
	public function getMembersForTemplate()
	{
		$temp = get_object_vars( $this );
        unset($temp['CreateDate']);
		unset($temp['Type']);
		unset($temp['Pass']);
		unset($temp['LastLogin']);
        return $temp;
	}
	
	/**
	*
	* gibt die css klasse zurück ob der mitarbeiter ein leiharbeiter ist.
	*
	*/
	public function getLeasedClass()
	{
		if( $this->LeasedEmployee )
		{
			return " ExternalEmployee ";
		}
		
		
		
	}
	
	
	
	
	
}
?>