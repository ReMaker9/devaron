<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class OrderPdf extends FPDF
{

    Protected $Order;
    Protected $Buyer;
    Protected $Products;
    Protected $Counts;

    function Header()
    {
        
    }

    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', '', 8);



        $this->Text(15, 270, utf8_decode("Die Ware bleibt bis zur vollständigen Bezahlung der Rechnung Eigentum unserer Firma."));
        $this->Text(15, 274, utf8_decode("Die Rechnung ist von Privatpersonen nach § 14b Abs. 1 S. 5 Ustg zwei Jahre aufzubewahren."));
        //utf8_decode(STATIC_FINANZ_NUMBER)


        $this->Text(15, 279, utf8_decode("Geschäftsführer:"));



        $this->Text(40, 279, "Bankverbindung:");
        $this->Text(40, 283, "IBAN.:" . utf8_decode(STATIC_IBAN));
        $this->Text(40, 287, "BIC.:" . utf8_decode(STATIC_BIC));
        $this->Text(40, 291, utf8_decode(STATIC_BANK_NAME));


        $this->Text(90, 279, "Amtsgericht Dresden:");
        $this->Text(90, 283, "HRB 34874");
        $this->Text(90, 287, utf8_decode(STATIC_FINANZ_NUMBER));


        $this->Text(130, 279, "Telefon: " . STATIC_PHONE);
        $this->Text(130, 283, "Telefax: " . STATIC_FAX);
        $this->Text(130, 287, "Mail: " . STATIC_MAIL);
        $this->Text(130, 291, "Web: " . utf8_decode(STATIC_WEB));
        $this->Text(178, 284, "Seite:" . $this->PageNo());
        $this->SetLineWidth(0.5);
        $this->SetDrawColor(255, 213, 0);
        $this->Line(15, 280, 190, 280);
    }

    public function __construct($Order, $Buyer)
    {
        parent::__construct();
        $this->Order = $Order;
        $this->Buyer = $Buyer;

        //$this->renderPage();
        $this->Products = $Order['Products'];
        $this->Counts = count($Order['Products']);

        $this->SetAutoPageBreak(false);
    }

    /**
     * fügt die adresse hinzu
     */
    public function writeAdress()
    {

        $this->SetY(0);
        $this->SetFont('Arial', 'b', 42);
        //$this->Image('./img/logo.png',15,20);
        //$this->Image('./img/CE.png',15,32);
        $this->SetTextColor(204, 204, 204);

        $this->SetFont('Arial', '', 8);

        $this->Text(35, 38, utf8_decode("DIN EN 14351-1:2006"));

        $this->Text(15, 45, utf8_decode("Torshop Hentschel") . " " . utf8_decode(STATIC_STREET) . " " . utf8_decode(STATIC_CITY));

        $this->SetTextColor(0, 0, 0);

        $this->SetFont('Arial', '', 12);

        $this->Text(129, 45, "Rechnungsdatum:");
        $this->Text(137, 55, "Rechnungsnr:");
        //$this->Text(140, 65, "Lieferdatum:");

        $this->SetLineWidth(0.1);
        $this->Line(165, 46, 190, 46); // Datum
        $this->Line(165, 56, 190, 56); //Rechnungs nummer

        $this->Line(165, 66, 190, 66); // Lieferdatum


        //$this->Text(165, 45, date("d.m.Y"));

        $this->Text(165, 55, "TSH / " . $this->Order['OrderId'], 0, 1, 'R');

        //$this->Text(165, 65, date("d.m.Y"));


        $this->SetFont('Arial', 'b', 12);
        $this->Text(15, 55, utf8_decode("Rechnung an:"));


        $this->SetFont('Arial', '', 12);
        if ($this->Buyer['tb_CompanyName'])
        {
            $this->Text(15, 60, utf8_decode($this->Buyer['tb_CompanyName']));
            $this->Text(15, 65, utf8_decode($this->Buyer['tb_SureName'] . " " . $this->Buyer['tb_Name']));
            $this->Text(15, 70, utf8_decode($this->Buyer['tb_Street']));
            $this->Text(15, 75, utf8_decode($this->Buyer['tb_Zip']));
            $this->Text(28, 75, utf8_decode($this->Buyer['tb_Town']));
        } else
        {
            $this->Text(15, 80, utf8_decode($this->Buyer['tb_SureName'] . " " . $this->Buyer['tb_Name']));
            $this->Text(15, 85, utf8_decode($this->Buyer['tb_Street']));
            $this->Text(15, 90, utf8_decode($this->Buyer['tb_Zip']));
            $this->Text(28, 90, utf8_decode($this->Buyer['tb_Town']));
        }


        if ($this->Buyer['cb_Title'] == 'Herr')
        {
            $this->Text(15, 120, "Sehr geehrter Herr " . $this->Buyer['tb_Name'] . ",");
        } else
        {
            $this->Text(15, 120, "Sehr geehrte Frau " . $this->Buyer['tb_Name'] . ",");
        }

        $this->Text(15, 125, utf8_decode("wir erlauben uns, folgende Waren in Rechnung zu stellen:"));
    }

    public function renderPage()
    {

        $this->AddPage();

        $this->writeAdress();
        ;

        // start Suppe

        $StartHeight = 150;
        $StartLeft = 25;
        // header schreiben
        $this->SetFont('Arial', 'b', 12);
        $this->Text($StartLeft + 22, $StartHeight - 8, utf8_decode("Artikel"));
        $this->Text($StartLeft + 75, $StartHeight - 8, utf8_decode("Menge"));
        $this->Text($StartLeft + 100, $StartHeight - 8, utf8_decode("Einzelpreis"));
        $this->Text($StartLeft + 135, $StartHeight - 8, utf8_decode("Gesamtbetrag"));
        $this->Line($StartLeft, $StartHeight - 7, 190, $StartHeight - 7);

        $this->SetFont('Arial', '', 12);
        $Result = 0;
        $ResultSmallTax = 0;
        $ProductCount = count($this->Products);
        $I = 1;
        $MinHeight = 80;
        foreach ($this->Products as $Product)
        {
            $ElementStartHeight = $StartHeight;
            $this->SetFont('Arial', 'b', 12);

            $this->Text($StartLeft, $StartHeight, Convert::truncate(utf8_decode(Translator::translate($Product["Type"]) . " Tor " . utf8_decode(Translator::translate($Product["Profile"]))), 35));
            $this->SetFont('Arial', '', 12);
            $this->SetXY($StartLeft + 63, $StartHeight - 4);
            $this->Cell(22, 5, utf8_decode($Product["Count"]), 0, 1, 'R');

            $this->SetXY($StartLeft + 78, $StartHeight - 4);
            $this->Cell(45, 5, utf8_decode(Convert::format($Product["EndPrice"]) . " EUR"), 0, 1, 'R');

            $this->SetXY($StartLeft + 128, $StartHeight - 4);
            $this->Cell(35, 5, utf8_decode(Convert::format($Product["Count"] * $Product["EndPrice"]) . " EUR"), 0, 1, 'R');

            $StartHeight += 6;
            $this->SetXY(25, $StartHeight - 4);
            $this->Cell(60, 5, utf8_decode("Art:") . " " . utf8_decode(Translator::translate($Product["Type"])), 0, 1, 'L');

            $StartHeight += 6;
            $this->SetXY(25, $StartHeight - 4);
            $this->Cell(60, 5, utf8_decode("Maße:") . " " . $Product["Width"] . "x" . $Product["Height"] . " mm", 0, 1, 'L');

            switch ($Product["Type"])
            {
                case SEKTIONAL:



                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Abstand:") . " Rechts: " . $Product["Right"] . "mm Links:" . $Product["Left"] . " mm", 0, 1, 'L');

                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Tiefe:") . " " . $Product["Deep"] . "mm Sturz:" . $Product["Lintel"] . " mm", 0, 1, 'L');

                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Oberfläche:") . "  " . $Product["SurfaceStructure"], 0, 1, 'L');

                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Sicke:") . "  " . Translator::translate($Product["Sicke"]), 0, 1, 'L');

                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    if ($Product["DoorColor"] == "DECOR_COLOR")
                    {

                        $this->Cell(60, 5, utf8_decode("Dekorart :") . "RAL " . utf8_decode(Translator::translate($Product["DoorColorRal"])), 0, 1, 'L');
                    } else
                    { 
                        $this->Cell(60, 5, utf8_decode("Dekor:") . " " . utf8_decode(Translator::translate($Product["DoorColorDecor"])), 0, 1, 'L');
                    }
                    

                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    switch ($Product["EngineType"])
                    {
                        case "NoEngine":
                            $this->Cell(60, 5, utf8_decode("Antriebsart:") . " Kein Antrieb ", 0, 1, 'L');
                            break;

                        case "Manuel":
                            $this->Cell(60, 5, utf8_decode("Antriebsart:") . " Manuel ", 0, 1, 'L');
                            break;

                        default:
                            $this->Cell(60, 5, utf8_decode("Antriebsart:") . " " . $Product["EngineType"], 0, 1, 'L');
                            $StartHeight += 6;
                            $this->SetXY(25, $StartHeight - 4);
                            if($Product["RemoteCount"])
                            {
                                $this->Cell(60, 5, utf8_decode("Zusätzliche Funkhandsender:") . " " . $Product["RemoteCount"], 0, 1, 'L');
                            }
                    }


                    if ($Product["InnerDoorType"] != NO_INNERDOOR_TYPE)
                    {
                        $StartHeight += 6;
                        $this->SetXY(25, $StartHeight - 4);
                        //echo '<p><span class="Lable">Tür: </span> ' . Translator::translate(  $Product["InnerDoorType"] ) . ' </p> ';  
                        $this->Cell(60, 5, utf8_decode("Tür:") . " " . Translator::translate($Product["InnerDoorType"]), 0, 1, 'L');
                    }


                    if ($Product["InnerDoorColor"] && $Product["InnerDoorColor"] != NO_UTILS)
                    {
                        $StartHeight += 6;
                        $this->SetXY(25, $StartHeight - 4);
                        $this->Cell(60, 5, utf8_decode("Tür Rahmen:") . " " . utf8_decode(Translator::translate($Product["InnerDoorColor"])), 0, 1, 'L');
                    }




                    if ($Product["DoorOpenType"] && $Product["DoorOpenType"] != NO_BINDER)
                    {
                        $StartHeight += 6;
                        $this->SetXY(25, $StartHeight - 4);
                        $this->Cell(60, 5, utf8_decode("Tür öffnet nach:") . " " . utf8_decode(Translator::translate($Product["DoorOpenType"])), 0, 1, 'L');
                    }

                    if ($Product["BinderType"] != NO_BENCH)
                    {
                        $StartHeight += 6;
                        $this->SetXY(25, $StartHeight - 4);
                        $this->Cell(60, 5, utf8_decode("Beschlag:") . " " . utf8_decode(Translator::translate($Product["BinderType"])), 0, 1, 'L');
                    }


                    /* if( $Product["Shutter"] != NO_SHUTTER )
                      {
                      $StartHeight += 6;
                      $this->SetXY( 25 , $StartHeight - 4 );
                      $this->Cell( 60, 5, utf8_decode( Translator::translate( $Product["Shutter"] ) ) , 0, 1 ,'L');
                      } */

                    break;
                case TWO:
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Rahmenaußenmaß Breite:") . " " . $Product["OutlineWidth"] . " mm", 0, 1, 'L');
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Rahmenaußenmaß Höhe:") . " " . $Product["OutlineHeight"] . " mm", 0, 1, 'L'); 

                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Oberfläche:") . "  " . $Product["SurfaceStructure"], 0, 1, 'L');
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Sicke:") . "  " . Translator::translate($Product["Sicke"]), 0, 1, 'L');
                    
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    if($Product["DoorColor"] == "DECOR_COLOR" )
                    {
                        $this->Cell(60, 5, utf8_decode("Dekorart :") . "RAL " . utf8_decode(Translator::translate($Product["DoorColorRal"])), 0, 1, 'L');
                        
                    } else 
                    {
                        $this->Cell(60, 5, utf8_decode("Dekorart :") . " " . utf8_decode(Translator::translate($Product["DoorColorDecor"])), 0, 1, 'L');
                    }
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Rahmenlackierung:") . "  " . Translator::translate($Product["BinderTowLack"]), 0, 1, 'L');
                    
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Verriegelung:") . "  " . utf8_decode( Translator::translate($Product["CloserType"])), 0, 1, 'L');
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Platzierung:") . "  " . utf8_decode(Translator::translate($Product["TowPlacement"])), 0, 1, 'L');
                    
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Öffnungrichtung:") . "  " . utf8_decode(Translator::translate($Product["OpenKind"])), 0, 1, 'L');
                    
                    $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Klinke:") . "  " . Translator::translate($Product["Clinke"]), 0, 1, 'L');
                    
                     $StartHeight += 6;
                    $this->SetXY(25, $StartHeight - 4);
                    $this->Cell(60, 5, utf8_decode("Befestigung:") . "  " . Translator::translate($Product["BinderType"]), 0, 1, 'L');
                    
                    
                    break;
            }
            $UsedHeight = $ElementStartHeight - $StartHeight;

            if ($UsedHeight < 0) // wenn die mindest höhe nicht eingehalten worden ist
            {
                $StartHeight = $ElementStartHeight + $MinHeight;
            }


            if ($StartHeight > 220 && $I < $ProductCount)
            {
                $this->AddPage();
                $StartHeight = 20;

                $this->SetFont('Arial', 'b', 12);
                $this->Text($StartLeft + 22, $StartHeight - 8, utf8_decode("Artikel"));
                $this->Text($StartLeft + 75, $StartHeight - 8, utf8_decode("Menge"));
                $this->Text($StartLeft + 100, $StartHeight - 8, utf8_decode("Einzelpreis"));
                $this->Text($StartLeft + 135, $StartHeight - 8, utf8_decode("Gesamtbetrag"));
                $this->Line($StartLeft, $StartHeight - 7, 190, $StartHeight - 7);
            }

            $StartHeight+=5;
            $I++;
        }

        $this->Line($StartLeft, $StartHeight - 2, 190, $StartHeight - 2);
        $StartHeight+=5;


        // berechnungen
        $this->SetFont('Arial', 'b', 12);
        //$this->Text($StartLeft+100 ,$StartHeight , utf8_decode("Gesamt:"));

        $this->SetXY($StartLeft + 78, $StartHeight - 4);
        $this->Cell(45, 5, utf8_decode("Gesamt:"), 0, 1, 'R');
        $this->SetFont('Arial', 'bu', 12);

        // Text schreiben
        $this->SetXY($StartLeft + 128, $StartHeight - 4);


        $this->Cell(35, 5, utf8_decode(Convert::format($this->Order['EndPrice']) . " EUR"), 0, 1, 'R');

        //$this->Text($StartLeft+140 ,$StartHeight ,  utf8_decode(Convert::format($Result)." EUR"));

        $this->SetFont('Arial', '', 12);
        $StartHeight+=2;

        $this->SetXY($StartLeft + 78, $StartHeight);
        $this->Cell(45, 5, utf8_decode("Mwst 19%:"), 0, 1, 'R');

        //$this->Text($StartLeft+140 ,$StartHeight ,  utf8_decode(Convert::format($ResultLargeTax)." EUR"));
        $this->SetXY($StartLeft + 128, $StartHeight);
        $this->Cell(35, 5, utf8_decode(Convert::format($this->Order['EndPrice'] * 0.19) . " EUR"), 0, 1, 'R');

        $StartHeight+=6;
        //$this->Text($StartLeft+100 ,$StartHeight , utf8_decode("Netto:"));
        $this->SetXY($StartLeft + 78, $StartHeight);
        $this->Cell(45, 5, utf8_decode("Netto:"), 0, 1, 'R');

        //$this->Text($StartLeft+140 ,$StartHeight ,  utf8_decode(Convert::format($Result -($ResultLargeTax + $ResultSmallTax))." EUR"));

        $this->SetXY($StartLeft + 128, $StartHeight);
        $this->Cell(35, 5, utf8_decode(Convert::format($this->Order['EndPrice'] - ( $this->Order['EndPrice'] * 0.19 )) . " EUR"), 0, 1, 'R');

        if( isset($_SESSION['Basket']['Description']) )
        {
            $StartHeight+=6;
            $this->SetXY($StartLeft , $StartHeight);
            $this->Cell(35, 5, utf8_decode("Bemerkung:") . "  " . utf8_decode( $_SESSION['Basket']['Description']), 0, 1, 'L');
        }
        

        $this->SetXY($StartLeft - 10, $StartHeight + 20);
        /* $this->Cell( 35, 5, 'Rechnung wurde Bar bezahlt am: ', 0, 1 );
          $this->Line(78, $StartHeight + 24, 120,$StartHeight + 24); */
    }

}
