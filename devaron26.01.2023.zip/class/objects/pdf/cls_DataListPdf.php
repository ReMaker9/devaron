<?php

/**
 * Diese Klasse ist zum Erzeugen einer PDF-Datenliste aus einem Array
 * @author Simon Brandt
 */
class DataListPdf extends DocumentPdf
{
    protected $DataArray;
    protected $ColWidth;
    protected $RowCount;
    protected $CellBorder;
    protected $TextArrayFontSize;
    protected $AutoBreakHeight;
    protected $FooterText;
    /**
     * Generates a DataList-PDF
     * @param array $DataArray
     * @param array $TextArray
     * @param array $Headline
     * @return int
     * @author Simon Brandt
     */
    public function __construct($DataArray, $TextArray, $Headline, $LengthArray = array(), $LnArray = array())
    {
        parent::__construct();

        $this->Headline = $Headline;
        $this->TextArray = $TextArray;
        $this->DataArray = $DataArray;
        $this->LengthArray = $LengthArray;
        $this->LnArray = $LnArray;
        $this->Borders = 0;
        $this->TextArrayFontSize = 10;
        $this->TextArrayFontBold = "0";
        $this->AutoBreakHeight = 5;
        $this->FooterText = "";
        // Dynamische Spaltenbreite
        $NumberOfFields = (count($this->DataArray[0]) > 10) ? 10 : count($this->DataArray[0]);
        $this->ColWidth = 170 / $NumberOfFields;

        if(count($this->LengthArray) != $NumberOfFields)
        {
            for($i = 0; $i < count($this->LengthArray); $i++)
            {
                $this->LengthArray[$i] =$this->ColWidth; 
            }
        }
        
        if(count($this->LnArray) != $NumberOfFields)
        {
            for($i = 0; $i < count( $this->LnArray ); $i++)
            {
                $this->LnArray[$i] = "L"; 
            }
        }
        
        
        // set author, creator and tile
        //$this->SetAuthor(ULSTO_NAME);
        //$this->SetCreator(ULSTO_NAME);


        $this->DefaultMarginTop = 12;
        $this->DefaultMarginLeft = 20;

        $this->applyDefaultStyle();

        $this->SetAutoPageBreak(true, $this->AutoBreakHeight);
        $this->AddPage();
    }

    public function setFooterText ($FooterText)
    {
        $this->FooterText = utf8_decode($FooterText);
    }
    
    public function setCellBoder ($Border)
    {
        $this->CellBorder = $Border;
    }
    
    public function setDefaultFontSize($FontSize)
    {
        $this->DefaultFontSize = $FontSize;
    }
    
    
    
    public function setTextArrayFontSize($FontSize, $Bold = "")
    {
        $this->TextArrayFontSize = $FontSize;
        $this->TextArrayFontBold = $Bold;
    }
    
    /**
     * Erzeugt die Datenliste
     * @author Simon Brandt
     */
    public function generatePdf()
    {
        // Headline
        $this->printHeadline();

        // optionales Text-Array
        if (sizeof($this->TextArray)) {
            $this->printTextArray(3);
        }

        // TabellenKopf (Array-Keys)
        $this->printTableHead();

        // Ausgabe der Zeilen
        $this->RowCount = 1;

        foreach ($this->DataArray as $DataRow) 
        {
            $this->SetDrawColor(200, 200, 200);

            // gestreifte Zeilen
            if ($this->RowCount % 2 == 0) 
            {
                $this->SetFillColor(255, 255, 255);
            } else 
            {
                $this->SetFillColor(240, 240, 240);
            }

            // Ausgabe Spalten
            $ColCount = 0;
            foreach ($DataRow as $Key => $Value) 
            {
                // Rausgehen, wenn mehr als 10 Spalten  
                if ($ColCount > 9) break;
                
                if($Value == "NewPage")
                {
                    $this->AddPage();
                }
                
                $i = 0;
                do
                {
                    $i += 0.2;
                    $this->SetFont($this->DefaultFontFamily, '', $this->DefaultFontSize - $i);
                }while( $this->GetStringWidth( $DataRow[$Key] ) + 2 > $this->LengthArray[$ColCount] ); // größen korrektur eingebaut wenn text zu lang für Zelle
                $this->Cell($this->LengthArray[$ColCount], 4, utf8_decode($DataRow[$Key]), $this->CellBorder, 0, $this->LnArray[$ColCount], true);
                $this->SetFont($this->DefaultFontFamily, '', $this->DefaultFontSize);
                $ColCount++;
            }

            $this->Ln();

            // !hacky: das Rechteckt Ã¼berdeckt Text-Overflow am rechten Rand
            $this->SetFillColor(255, 255, 255);
            $this->Rect(190, 0, 50, 999, "F");
            $this->SetFillColor(240, 240, 240);

            $this->RowCount++;
        }
    }

    protected function printHeadline()
    {
        $this->SetFont('Arial', '', $this->DefaultFontSize + 10);
        $this->Ln(5);
        $this->Cell(0, 5, utf8_decode($this->Headline));
        $this->Ln(10);
        $this->SetFont('Arial', '', $this->DefaultFontSize);
    }

    /**
     * Prints optional TextArray at the top of the document
     * @author Simon Brandt
     */
    protected function printTextArray($top = null, $width = null, $x = null, $y = null)
    {
        
        foreach ($this->TextArray as $Text) 
        {
            $this->openContainer($top, $x, $y);
            $Text = str_replace('â‚¬', 'EUR', $Text);
            $this->SetFont('Arial', $this->TextArrayFontBold, $this->TextArrayFontSize );
            $this->MultiCell($width, $this->LineHeightS, utf8_decode($Text), $this->Borders, 'L');

            $this->closeContainer();
        };
        $this->Ln(10);
    }

    /**
     * Prints Tablehead
     * @author Simon Brandt
     */
    protected function printTableHead()
    {
        $ColCount = 0;
        // Ausgabe Tabellen-Kopf
        
        foreach ($this->DataArray[0] as $Key => $Value) 
        {
            // Rausgehen, wenn mehr als 10 Spalten  
            if ($ColCount > 9) break;
            // Spalten-Bezeichnung (Key) drucken
            $this->SetFillColor(255, 255, 255);
            $this->SetDrawColor(150, 150, 150);
            $this->SetFont('Arial', 'B', $this->DefaultFontSize);
            $this->Cell($this->LengthArray[$ColCount], 5, utf8_decode($Key), "B", 0, $this->LnArray[$ColCount], true);
            $this->SetFont('Arial', '', $this->DefaultFontSize);
            $this->SetFillColor(240, 240, 240);
            $ColCount++;
        }
        $this->Ln();

    }

    /**
     * This is a fpdf-callback-function.
     * Prints background-image OR logo and seller-information on every site.
     * @return bool
     * @author Simon Brandt
     */
    public function Header()
    {
        $this->SetDrawColor(0, 0, 0);
        if($this->PageNo() > 1) return;
        $this->printLogo();
        
        //$this->printTableHead();
    }

    /**
     * This is a fpdf-callback-function.
     * Prints page-number and seller- and tax-office-information on every site.
     * @return bool
     * @author Simon Brandt
     */
    public function Footer()
    {
        $this->SetDrawColor(0, 0, 0);
        $this->printPageNumber();
        $this->printSellerFooter();
    }

    /**
     * Prints the current page-number.
     * @author Simon Brandt
     */
    protected function printPageNumber()
    {
        $this->openContainer();

        $this->y = $this->h - 10;
        $this->Cell(0, 8, 'Seite ' . $this->PageNo(), 0, 1, 'L');
        $this->y = $this->h - 6;
        $this->Cell(0, 0, $this->FooterText , 0, 1, 'R');
        /*if( strlen( $this->FooterText ) > 0)
        {
            $this->Cell(0, 8, $this->FooterText , 0, 1, 'R');
        }*/

        $this->closeContainer();
    }

//    Funktion wird in aktueller Version nicht verwendet
    /**
     * Prints the seller-info (Company, Name, Address).
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     * @author Simon Brandt
     */
//    protected function printSellerInfo($top = null, $x = null, $y = null)
//    {
//        $this->openContainer($top, $x, $y);
//
//        $this->SetFont('Arial', '', $this->DefaultFontSize);
//        $this->x = 104;
//
//        $this->Cell(0, 10, utf8_decode(
//            ULSTO_STREET . " " . ULSTO_HOUSENUMBER . ", " . ULSTO_ZIP . " " . ULSTO_CITY
//        ), $this->Borders, 1, "L");
//
//        $this->closeContainer();
//    }

    /**
     * Prints seller-information for the footer.
     * @author Simon Brandt
     */
    protected function printSellerFooter()
    {
        return;
        $this->openContainer();

        $this->SetMargins(15, 0, 0);
        $this->x = $this->DefaultMarginLeft;
        $this->y = $this->h - $this->DefaultMarginBottom;
        $this->SetFontSize($this->DefaultFontSize - 2);

        $ContentWidth = 60;
        $MarginWidth = 12;

        $this->Line($this->x, $this->y - 2, $this->w - $this->x, $this->y - 2);

        // Adresse
        $this->MultiCell($ContentWidth + 10, $this->LineHeightS, utf8_decode(
            PDF_NAME . "\n" .
            PDF_STREET . ' ' . PDF_HOUSENUMBER . "\n" .
            PDF_ZIP . ' ' . PDF_CITY
        ), $this->Borders);


        // Tel, Fax, E-Mail, Internet
        $this->x += 0.95 * $ContentWidth + $MarginWidth;
        $this->y = $this->h - $this->DefaultMarginBottom;

        $this->MultiCell($ContentWidth, $this->LineHeightS, utf8_decode(
            "Tel.: " . PDF_PHONE . "\n" .
            "E-Mail: " . PDF_MAIL . "\n" .
            "Internet: " . PDF_WEBSITE
        ), $this->Borders);


        // GeschÃ¤ftsfÃ¼hrer, SteuerbehÃ¶rde, Steuernummer
        $this->x += 1.9 * $ContentWidth + $MarginWidth + 5;
        $this->y = $this->h - $this->DefaultMarginBottom;

        $this->MultiCell($ContentWidth, $this->LineHeightS, utf8_decode(
            "GeschÃ¤ftsfÃ¼hrer: " . STATIC_NAME . "\n" .
            "SteuerbehÃ¶rde: " . PDF_TAXOFFICE . "\n" .
            "Steuer-Nr.: " . PDF_TAXID
        ), $this->Borders);

        $this->closeContainer();
    }
}