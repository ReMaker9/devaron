<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class BillPdf extends DocumentPdf
{
    protected $DefaultFields;
    protected $Fields;
    protected $StyleColor;
    protected $Positions;

    /**
     * Generates a Bill-PDF from a JSON-file.
     *
     * @param string $JsonUrl Path to JSON-file
     *
     * @return int
     */
    public function __construct($JsonString)
    {
        parent::__construct();

        if (!Utility::jsonLint($JsonString)) {
            echo 'Ungültiges JSON!';

            return 0;
        }

        $Bill = json_decode($JsonString);

        // import json-information
        $this->Fields = $Bill;

        // set default-style-attributes
        $this->DefaultFontFamily = ($Bill->Style->FontFamily) ? $Bill->Style->FontFamily : 'Arial';
        $this->DefaultFontSize = ($Bill->Style->FontSize) ? $Bill->Style->FontSize : 9;
        $this->DefaultTextColor = ($Bill->Style->FontColor) ? Utility::hexToRgbAsArray($Bill->Style->FontColor) : Utility::hexToRgbAsArray('#222222');
        $this->DefaultStyleColor = ($Bill->Style->StyleColor) ? Utility::hexToRgbAsArray($Bill->Style->StyleColor) : Utility::hexToRgbAsArray('#d70b13');
        $this->DefaultMarginLeft = 25;
        $this->DefaultMarginTop = 60;
        $this->DefaultMarginRight = 25;
        $this->DefaultMarginBottom = 30;

        // apply default-style-attributes
        $this->applyDefaultStyle();

        // toggle borders and define line heights
        $this->Borders = 0;
        $this->LineHeightXS = 3;
        $this->LineHeightS = 4;
        $this->LineHeightM = 6;
        $this->LineHeightL = 8;
        $this->LineHeightXL = 10;
        $this->LineHeightXXL = 12;

        // create shortcuts for printing seller-information
        $this->SellerContact = $Bill->Seller->Contact;
        $this->SellerBank = $Bill->Seller->Bank;
        $this->SellerTaxOffice = $Bill->Seller->TaxOffice;

        // for printing the €-sign
        define('EURO', chr(128));

        // initialize positions-counter and sum-variables
        $this->PositionsTotal = count($Bill->Positions);
        $this->PositionIndex = 0;
        $this->SumNet = 0;
        $this->SumTax7 = 0;
        $this->SumTax19 = 0;
        $this->SumGross = 0;


        $this->TaxFree = 1;
        if ($this->TaxFree) {
            $this->TableHeader = ['', 'Artikel/Leistung', 'Menge', 'Einzel', 'Gesamt'];
            $this->TableAlign = ['C', 'C', 'C', 'R', 'R'];
            $this->TableWidths = [10, 90, 15, 25, 25];
        } else {
            $this->TableHeader = ['', 'Artikel/Leistung', 'MwSt.', 'Menge', 'Einzel', 'Gesamt'];
            $this->TableAlign = ['C', 'C', 'C', 'C', 'R', 'R'];
            $this->TableWidths = [10, 75, 15, 15, 25, 25];
        }

        // set author, creator and ttile
        $this->SetAuthor($this->SellerContact->FirstName . ' ' . $this->SellerContact->LastName);
        $this->SetCreator($this->SellerContact->FirstName . ' ' . $this->SellerContact->LastName);

        switch ($this->Fields->BillType) {
            // Rechnung
            case 1:
                $this->Fields->Labels->Title = 'Rechnung';
                $this->Fields->Labels->Number = 'Rechnung Nr.:';
                $this->Fields->Labels->Date1 = 'Rechnungsdatum:';
                $this->Fields->Labels->Date2 = 'Leistungsdatum:';
                $this->Fields->Labels->ValueDate2 = Date::getGermanDate($this->Fields->PerformanceDate);
                $this->Fields->Labels->DefaultText = 'wir möchten Ihnen gern folgende Positionen in Rechnung stellen.';
                break;

            // Angebot
            case 2:
                $this->Fields->Labels->Title = 'Angebot';
                $this->Fields->Labels->Number = 'Angebot Nr.:';
                $this->Fields->Labels->Date1 = 'Angebotsdatum:';
                $this->Fields->Labels->Date2 = 'Gültig bis:';
                $this->Fields->Labels->ValueDate2 = Date::getGermanDate($this->Fields->ValidityDate);
                $this->Fields->Labels->DefaultText = 'wir möchten Ihnen gern folgendes Angebot unterbreiten.';
                break;

            //Bestellung
            case 3:
                $this->Fields->Labels->Title = 'Bestellung';
                $this->Fields->Labels->Number = 'Bestellung Nr.:';
                $this->Fields->Labels->Date1 = 'Bestelldatum:';
                $this->Fields->Labels->Date2 = '';
                $this->Fields->Labels->ValueDate2 = '';
                $this->Fields->Labels->DefaultText = 'wir bedanken uns für Ihr Interesse. Im folgenden Ihre Bestellung für den Teilnehmer ';
                break;

            default:
                break;
        }

        if (!isset($this->Fields->BillNumber)) {
            $this->Fields->BillNumber = '000-000-000';
        }

        $this->SetTitle($this->Fields->Labels->Number . ' ' . $this->Fields->BillNumber);

        // set auto-page-break and add the first page
        $this->SetAutoPageBreak(true, 40);

        $this->AddPage();
    }


    /**
     * This is a fpdf-callback-function.
     * Prints background-image OR logo and seller-information on every site.
     *
     * @return bool
     */
    public function Header()
    {
        $this->printLogo();
    }

    /**
     * This is a fpdf-callback-function.
     * Prints page-number and - if no background-image is provided - seller- and tax-office-information on every site.
     *
     * @return bool
     */
    public function Footer()
    {
        $this->printPageNumber();
        $this->printSellerFooter();
    }


    /**
     * Prints the seller-info (Company, Name, Address).
     *
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printSellerInfo($top = null, $x = null, $y = null)
    {
        $this->openContainer($top, $x, $y);

        $this->SetFont('Arial', '', $this->DefaultFontSize - 1);

        $this->Cell(70, $this->LineHeightS, utf8_decode(
            MEA_SHORTNAME . ", " . MEA_STREET . " " . MEA_HOUSENUMBER . ", " . MEA_ZIP . " " . MEA_CITY
        ), $this->Borders);

        $this->closeContainer();
    }


    /**
     * Prints the buyer-info (Company, Name, Address).
     *
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printBuyerInfo($top = null, $x = null, $y = null)
    {
        $this->openContainer($top, $x, $y);

        $this->SetFont('Arial', '', $this->DefaultFontSize + 1);


        $this->MultiCell(70, $this->LineHeightS, utf8_decode(
            $this->Fields->Buyer->Contact->CompanyName . "\n" .
            $this->Fields->Buyer->Contact->Street . ' ' . $this->Fields->Buyer->Contact->HouseNumber . "\n" .
            $this->Fields->Buyer->Contact->ZIP . ' ' . $this->Fields->Buyer->Contact->City
        ), $this->Borders);

        $this->closeContainer();
    }

    /**
     * Prints the bill-info (bill-number, bill-date, performance-date).
     *
     * @Warning: Does currently not work without parameters!
     *
     * @param int $top Space left before this container in mm
     * @param int $width width of this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printBillInfo($top = null, $width = null, $x = null, $y = null)
    {
        $this->openContainer($top, $x, $y);

        if (strlen($this->Fields->Buyer->Contact->DebitorId) > 0) {
            $this->Cell(20, 0, utf8_decode("Kundennr.:"), 0, 0, 'L');
            $this->Cell(65, 0, utf8_decode($this->Fields->Buyer->Contact->DebitorId), 0, 1, 'L');
        }

        if (strlen($this->Fields->Buyer->Contact->CompanyName) > 0) {
            $this->Cell(20, 8, utf8_decode("Für:"), 0, 0, 'L');
            $this->Cell(65, 8, utf8_decode($this->Fields->Buyer->Contact->CompanyName), 0, 1, 'L');
        }
        // $this->Cell(20, 0, utf8_decode("Monat:"), 0, 0, 'L');
        //$this->Cell(65, 0, utf8_decode("XXXXXX"), 0, 1, 'L');

        $this->closeContainer();
    }

    /**
     * Prints City and current Date.
     *
     * @param int $top Space left before this container in mm
     */
    public function printReferenceAndDate($top = null)
    {
        $this->openContainer($top);

        //$this->Cell(75, 0, utf8_decode("Ihr Zeichen / Bestellung"), 0, 0, 'L');
        //$this->Cell(65, 0, utf8_decode("Unser Zeichen"), 0, 0, 'L');
        $this->Cell(155, $this->LineHeightM, utf8_decode("Datum: " . date('d.m.Y')), 0, 1, 'R');
        $this->Cell(155, $this->LineHeightM, utf8_decode("Unser Zeichen: " . $_SESSION["UserLastName"]), 0, 1, 'R');

        $this->SetFont('Arial', 'B', $this->DefaultFontSize);
        //$this->Cell(75, 8, utf8_decode("XXXXXX"), 0, 0, 'L'); // Ihr Zeichen
        $this->SetFont('Arial', '', $this->DefaultFontSize);

        $this->closeContainer();
    }

    /**
     * Prints the subject (bill-number), bold and as a headline.
     *
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printSubject($top = null, $x = null, $y = null)
    {
        $this->openContainer($top, $x, $y);

        $this->SetFont('Arial', 'B', $this->DefaultFontSize + 5);
        $this->Cell(0, $this->LineHeightS, utf8_decode(
            $this->Fields->Labels->Number . ' ' . $this->Fields->BillNumber
        ), $this->Borders);

        $this->closeContainer();
    }

    /**
     * Prints the salutation.
     *
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printSalutation($top = null, $x = null, $y = null)
    {
        $this->openContainer($top, $x, $y);

        if ($this->Fields->Buyer->Contact->Salutation == 'Herr') {
            $this->MultiCell(0, $this->LineHeightM, utf8_decode(
                    'Sehr geehrter Herr ' . $this->Fields->Buyer->Contact->LastName) . ',');
        } elseif ($this->Fields->Buyer->Contact->Salutation == 'Frau') {
            $this->MultiCell(0, $this->LineHeightM, utf8_decode(
                    'Sehr geehrte Frau ' . $this->Fields->Buyer->Contact->LastName) . ',');
        } else {
            $this->MultiCell(0, $this->LineHeightM, utf8_decode(
                'Sehr geehrte Damen und Herren,'));
        }

        $this->closeContainer();
    }

    /**
     * Prints the bill-positions.
     * Includes:
     * Printing table-headers,
     * Printing each position on a new line,
     * Automatic page-breaks,
     * Printing subtotals at the end of each page,
     * Printing totals at the end of the table.
     */
    public function printPositions()
    {
        $this->openContainer();

        // adjust container-style
        $this->SetLineWidth(.1 );
        $this->SetFillColor(240, 240, 240);
        $fill = 0;

        // print position header
        $this->printPositionsHeader(10);


        // print data for every position
        foreach ($this->Fields->Positions as $row) {
            ++$this->PositionIndex;
            $this->SetFontSize($this->DefaultFontSize - 2);

            $colCount = 0;

            // Artikel-Bezeichnung passt in eine Zeile
            if ($this->GetStringWidth($row->Label) / $this->TableWidths[1] < 1) {
                $labelCellHeight = $this->LineHeightM;
                // Nr
                $this->Cell($this->TableWidths[$colCount], $labelCellHeight, $this->PositionIndex, 'T', 0, 'C', $fill);
                $colCount++;
                // Artikel-Bezeichnung
                $this->Cell($this->TableWidths[$colCount], $labelCellHeight, utf8_decode($row->Label), 'T', 0, 'L', $fill);
                $colCount++;
            }
            // Artikel-Bezeichnung passt NICHT in eine Zeile
            else {
                $labelCellHeight = $this->GetMultiCellHeight($this->TableWidths[1], $this->LineHeightS, $row->Label, 0, 'L');
                // Nr
                $this->Cell($this->TableWidths[$colCount], $labelCellHeight, $this->PositionIndex, 'T', 0, 'C', $fill);
                $colCount++;
                $tempX = $this->x;
                $tempY = $this->y;
                // Artikel-Bezeichnung
                $this->MultiCell($this->TableWidths[$colCount], $this->LineHeightS, utf8_decode($row->Label), 'T', 'L');
                $this->x = $tempX + $this->TableWidths[$colCount];
                $colCount++;
                $this->y = $tempY;
            }
            if (!$this->TaxFree) {
                // MwSt.
                $this->Cell($this->TableWidths[$colCount], $labelCellHeight, $row->Tax . '%', 'T', 0, 'C', $fill);
                $colCount++;
            }
            // Menge
            $this->Cell($this->TableWidths[$colCount], $labelCellHeight, utf8_decode(number_format($row->Quantity, 1, ',', '.') . ' ' . $row->Unit), 'T', 0, 'C', $fill);
            $colCount++;
            // Einzelpreis
            $this->Cell($this->TableWidths[$colCount], $labelCellHeight, number_format($row->UnitPrice, 2, ',', '.') . ' ' . EURO, 'T', 0, 'R', $fill);
            $colCount++;
            // Summe Netto
            $this->Cell($this->TableWidths[$colCount], $labelCellHeight, number_format($row->SumNet, 2, ',', '.') . ' ' . EURO, 'T', 0, 'R', $fill);
            $colCount++;

            $this->Ln();

            $this->addToSums($row);
            $fill = !$fill;
            $this->handlePageBreak();
        }

        $this->closeContainer();
    }

    /**
     * Prints carry over for the bill-positions.
     *
     * @param array $this ->TableWidths widths of the individual columns
     * @param int $top Space left before this container in mm
     */
    public function printCarryOver($top = null)
    {
        $this->openContainer($top);

        $width = array_sum($this->TableWidths) - end($this->TableWidths);

        $this->SetLineWidth(.2);
        $this->SetFontSize($this->DefaultFontSize);
        $this->Cell($width, $this->LineHeightL, utf8_decode('Übertrag Netto:'), 'T', 0, 'R');
        $this->SetFontSize($this->DefaultFontSize - 2);
        $this->Cell(end($this->TableWidths), $this->LineHeightL, number_format($this->SumNet, 2, ',', '.') . ' ' . EURO, 'T', 1, 'R');
        $this->SetLineWidth(.1);

        $this->closeContainer();
    }

    /**
     * Prints header for the bill-positions.
     *
     * @param array $this ->TableWidths widths of the individual columns
     * @param int $top Space left before this container in mm
     */
    public function printPositionsHeader($top = null)
    {
        $this->openContainer($top);

        for ($i = 0; $i < count($this->TableHeader); ++$i) {
            $this->Cell($this->TableWidths[$i], 7, $this->TableHeader[$i], 'TB', 0, $this->TableAlign[$i], 1);
        }
        $this->Ln();

        $this->closeContainer();
    }

    /**
     * Handles the page break when printing positions.
     * Prints sums and table-header.
     *
     * @param array $this ->TableWidths widths of the individual columns
     */
    public function handlePageBreak()
    {
        // print sums before page-end and table-header after page-add
        // (but not if the last element is reached anyways)
        if ($this->y > $this->h - 100 && $this->PositionIndex != $this->PositionsTotal) {
            $this->printSums('Zwischensumme');
            $this->AddPage();
            $this->printPositionsHeader(10);
            $this->printCarryOver();
        } elseif ($this->PositionIndex == $this->PositionsTotal) {
            // TODO: ! nicht sicher, wofür diese If-Klausel war!

            // if ($this->y > $this->h / 2) {
            //     $this->printSums('Zwischensumme');
            //     $this->AddPage();
            //     $this->Ln(20);
            // }
            $this->printSums('Gesamtbetrag');
        }
    }

    /**
     * Builds sums over the bill-data.
     *
     * @param array $row data of the current bill-position
     */
    public function addToSums($row)
    {
        $this->SumNet = $this->SumNet + $row->SumNet;

        switch ($row->Tax) {
            case 0:
                $this->SumGross = $this->SumGross + $row->SumNet;
                break;
            case 7:
                $this->SumTax7 = $this->SumTax7 + $row->SumNet * 0.07;
                $this->SumGross = $this->SumGross + $row->SumNet * 1.07;
                break;
            case 19:
                $this->SumTax19 = $this->SumTax19 + $row->SumNet * 0.19;
                $this->SumGross = $this->SumGross + $row->SumNet * 1.19;
                break;
        }
    }

    /**
     * Prints the bill-sums.
     *
     * @param array $this ->TableWidths widths of the individual columns
     * @param string $sumLabel Label for the sum (e.g. "Zwischensumme", "Gesamtbetrag")
     */
    public function printSums($sumLabel)
    {
        $width = array_sum($this->TableWidths) - end($this->TableWidths);

        $this->SetLineWidth(.2);
        $this->SetFontSize($this->DefaultFontSize);
        $this->Cell($width, $this->LineHeightL, $sumLabel . ' Netto:', 'T', 0, 'R');
        $this->SetFontSize($this->DefaultFontSize - 2);
        $this->Cell(end($this->TableWidths), $this->LineHeightL, number_format($this->SumNet, 2, ',', '.') . ' ' . EURO, 'T', 1, 'R');

        $this->SetLineWidth(.2);
        // Ausgabe Stuern auskommentiert
        // if ($this->SumTax7) {
        //     $this->Cell($width, $this->LineHeightL, 'MwSt. 7%:', 'T', 0, 'R');
        //     $this->Cell($this->TableWidths[5], $this->LineHeightL, number_format($this->SumTax7, 2, ',', '.').' '.EURO, 'T', 1, 'R');
        // }
        // $this->Cell($width, $this->LineHeightL, 'MwSt. 19%:', 'T', 0, 'R');
        // $this->Cell($this->TableWidths[5], $this->LineHeightL, number_format($this->SumTax19, 2, ',', '.').' '.EURO, 'T', 1, 'R');
        $this->SetFont('', 'B');
        $this->SetFontSize($this->DefaultFontSize);
        $this->Cell($width, $this->LineHeightL, $sumLabel . ' Brutto:', 'T', 0, 'R');
        $this->SetFontSize($this->DefaultFontSize - 2);
        $this->Cell(end($this->TableWidths), $this->LineHeightL, number_format($this->SumGross, 2, ',', '.') . ' ' . EURO, 'T', 1, 'R');
        $this->SetFont('');

        // Doppelte Linie
        // $this->SetDrawColor(0, 0, 0);
        // if ($sumLabel == 'Gesamtbetrag') {
        //     $this->Line(172, $this->y - 1, $this->w - 20, $this->y - 1);
        //     $this->Line(172, $this->y, $this->w - 20, $this->y);
        // }
    }

    /**
     * Prints signature-container ("Vielen Dank. Mit freundlichen Grüßen. [LEERZEILEN] Vorname Nachname").
     *
     * @param int $top Space left before this container in mm
     */
    public function printSignature($top = null)
    {
        $this->openContainer($top);

        if ($this->y > $this->h) {
            $this->AddPage();
        }
        $this->Cell(0, 8, utf8_decode('Nach §4 Nr. 21 UstG ist die MEA GGmbH von der Umstatzsteuer befreit.'), 0, 1);
        $this->Ln(10);
        $this->Cell(0, 8, utf8_decode('Vielen Dank.'), 0, 1);
        $this->Cell(0, 8, utf8_decode('Mit freundlichen Grüßen'), 0, 1);
        //$this->Ln(5);
        $this->Cell(0, 8, $this->SellerContact->FirstName . ' ' . $this->SellerContact->LastName);

        $this->closeContainer();
    }

    /**
     * Prints the current page-number.
     */
    public function printPageNumber()
    {
        $this->openContainer();

        $this->SetDrawColor($this->DefaultStyleColor['r'] - 50, $this->DefaultStyleColor['g'] - 50, $this->DefaultStyleColor['b'] - 50);
        $this->y = $this->h - 40;
        $this->Cell(0, 8, 'Seite ' . $this->PageNo(), 0, 1, 'C');

        $this->closeContainer();
    }

    /**
     * Prints seller-information for the footer.
     */
    public function printSellerFooter()
    {
        $this->openContainer();

        $this->SetMargins(15, 0, 0);
        $this->x = $this->DefaultMarginLeft - 10;
        $this->y = $this->h - $this->DefaultMarginBottom;
        $this->SetFontSize($this->DefaultFontSize - 3);

        $ContentWidth = 40;
        $MarginWidth = 12;

        $this->Line($this->x, $this->y - 2, $this->w - $this->x, $this->y - 2);

        // Adresse
        $this->MultiCell($ContentWidth + 10, $this->LineHeightXS, utf8_decode(
            $this->Fields->Seller->Contact->CompanyName . "\n" .
            $this->Fields->Seller->Contact->Street . ' ' . $this->Fields->Seller->Contact->HouseNumber . "\n" .
            $this->Fields->Seller->Contact->ZIP . ' ' . $this->Fields->Seller->Contact->City
        ), $this->Borders);


        // Tel, Fax, E-Mail, Internet
        $this->x += $ContentWidth + $MarginWidth;
        $this->y = $this->h - $this->DefaultMarginBottom;

        $this->MultiCell($ContentWidth, $this->LineHeightXS, utf8_decode(
            "Tel.: " . $this->Fields->Seller->Contact->Phone . "\n" .
            "Fax: " . $this->Fields->Seller->Contact->Fax . "\n" .
            "E-Mail: " . $this->Fields->Seller->Contact->Mail . "\n" .
            "Internet: " . $this->Fields->Seller->Contact->Website
        ), $this->Borders);


        // Geschäftsführer, Steuerbehörde, Steuernummer
        $this->x += 2 * $ContentWidth + $MarginWidth + 5;
        $this->y = $this->h - $this->DefaultMarginBottom;

        $this->MultiCell($ContentWidth, $this->LineHeightXS, utf8_decode(
            "Geschäftsführer \n" .
            $this->Fields->Seller->Contact->CompanyOwner . "\n" .
            $this->Fields->Seller->TaxOffice->OfficeName . "\n" .
            "Steuer-Nr.: " . $this->Fields->Seller->TaxOffice->TaxNumber
        ), $this->Borders);


        // Bank, IBAN, BIC 
        $this->x += 3 * $ContentWidth + $MarginWidth;
        $this->y = $this->h - $this->DefaultMarginBottom;

        $this->MultiCell($ContentWidth + 20, $this->LineHeightXS, utf8_decode(
            $this->Fields->Seller->Bank->Name . "\n" .
            "IBAN: " . $this->Fields->Seller->Bank->IBAN . "\n" .
            "BIC: " . $this->Fields->Seller->Bank->BIC
        ), $this->Borders);


        $this->closeContainer();
    }
}