<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class DocumentPdf extends FPDF
{
    protected $DefaultFields;
    protected $Fields;
    protected $StyleColor;
    protected $Positions;

    /**
     * Generates a Dokument-PDF.
     */
    public function __construct()
    {
        parent::__construct();

        // set default-style-attributes
        
        $this->DefaultFontFamily = ( $this->Fields->Style->FontFamily ) ? $this->Fields->Style->FontFamily : 'Arial';
        $this->DefaultFontSize = ( $this->Fields->Style->FontSize ) ? $this->Fields->Style->FontSize : 10;
        $this->DefaultTextColor = ( $this->Fields->Style->FontColor ) ? Utility::hexToRgbAsArray($$this->Fields->Style->FontColor) : Utility::hexToRgbAsArray('#222222');
        $this->DefaultStyleColor = ( $this->Fields->Style->StyleColor ) ? Utility::hexToRgbAsArray($this->Fields->Style->StyleColor) : Utility::hexToRgbAsArray('#d70b13');

        
        
       /*$this->DefaultFontFamily = ($Certificate->Style->FontFamily) ? $Certificate->Style->FontFamily : 'Arial';
        $this->DefaultFontSize = ($Certificate->Style->FontSize) ? $Certificate->Style->FontSize : 10;
        $this->DefaultTextColor = ($Certificate->Style->FontColor) ? Utility::hexToRgbAsArray($Certificate->Style->FontColor) : Utility::hexToRgbAsArray('#222222');
        $this->DefaultStyleColor = ($Certificate->Style->StyleColor) ? Utility::hexToRgbAsArray($Certificate->Style->StyleColor) : Utility::hexToRgbAsArray('#d70b13');*/
        $this->DefaultMarginLeft = 25;
        $this->DefaultMarginTop = 60;
        $this->DefaultMarginRight = 25;
        $this->DefaultMarginBottom = 30;

        // apply default-style-attributes
        $this->applyDefaultStyle();

        // toggle borders and define line heights
        $this->Borders = 0;
        $this->LineHeightXS = 3;
        $this->LineHeightS = 4;
        $this->LineHeightM = 6;
        $this->LineHeightL = 8;
        $this->LineHeightXL = 10;
        $this->LineHeightXXL = 12;
    }

 

    /**
     * Prints the background-image.
     */
    public function printBackground()
    {
        $LocalPath = getcwd();
        $ImagePath = $LocalPath.$this->Fields->Style->BackgroundPath;
        $this->Image($ImagePath, 0, 0, 210, 0);
    }

    /**
     * Prints the logo if provided.
     */
    public function printLogo($align = 'right', $printedHeight = 14)
    {
        $LocalPath = getcwd();
        $LogoPath = "img/mea-logo.png";
        
        $ImagePath = $LocalPath."/img/mea-logo.png";

        $ImageSize = getimagesize($ImagePath);

        $imageWidth = $ImageSize[0];
        $imageHeight = $ImageSize[1];

        // set printedHeight and calculate the printedWidth for centering
        $printedWidth = $printedHeight / ($imageHeight / $imageWidth);

        $this->Image($LogoPath, 105, 25, 0, $printedHeight);
    }

    /**
     * Prints a text.
     *
     * @param int $i     index of the text
     * @param int $top   Space left before this container in mm
     * @param int $width Width of this container in mm
     * @param int $x     x-Position of this container in mm (absolute)
     * @param int $y     y-Position of this container in mm (absolute)
     */
    public function printText($i = null, $top = null, $width = null, $x = null, $y = null)
    {
        $this->openContainer($top, $x, $y);

        $Text = $this->Fields->Text[$i];

        // Falls Text[0] nicht gesetzt, nutze DefaultText
        if ($i == 0 && !isset($Text)) {
            $Text = $this->Fields->Labels->DefaultText;
        }

        if (!isset($Text[$i])) {
            return;
        }

        $Text = str_replace('€', 'EUR', $Text);
        $this->MultiCell($width, $this->LineHeightM, utf8_decode($Text), $this->Borders, 'L');

        $this->closeContainer();
    }

    /**
     * Sets style attributes to default values.
     * Sets the x- and y-property for the container.
     *
     * @param int $top Space left before this container in mm
     * @param int $x   x-position in mm (absolute)
     * @param int $y   y-position in mm (absolute)
     */
    public function openContainer($top = null, $x = null, $y = null)
    {
        $this->applyDefaultStyle();

        if ($top !== null) {
            $this->Ln($top);
        }
        if ($x !== null) {
            $this->x = $x;
        }
        if ($y !== null) {
            $this->y = $y;
        }
    }

    /**
     * Does a CRLF (line-size: 0).
     * Sets style attributes to default values.
     */
    public function closeContainer()
    {
        $this->Ln(0);
        $this->applyDefaultStyle();
    }

    /**
     * Sets these attributes back to its default values:
     * FontFamily,
     * FontStyle,
     * FontSize,
     * TextColor,
     * DrawColor,
     * FillColor,
     * Margins (left, top, right).
     */
    public function applyDefaultStyle()
    {
        $this->SetFont($this->DefaultFontFamily, '', $this->DefaultFontSize);
        $this->SetTextColor($this->DefaultTextColor['r'], $this->DefaultTextColor['g'], $this->DefaultTextColor['b']);

        // $this->SetDrawColor($this->DefaultStyleColor['r'] - 50, $this->DefaultStyleColor['g'] - 50, $this->DefaultStyleColor['b'] - 50);
        $this->SetFillColor(255, 255, 255);

        $this->SetMargins($this->DefaultMarginLeft, $this->DefaultMarginTop, $this->DefaultMarginRight);
    }

    /**
     * @param type $w
     * @param type $h
     * @param type $txt
     * @param type $border
     * @param type $align
     *
     * @author Internet
     *
     * @return type
     */
    public function GetMultiCellHeight($w, $h, $txt, $border = null, $align = 'J')
    {
        // Calculate MultiCell with automatic or explicit line breaks height
        // $border is un-used, but I kept it in the parameters to keep the call
        //   to this function consistent with MultiCell()
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0) {
            $w = $this->w - $this->rMargin - $this->x;
        }
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb - 1] == "\n") {
            --$nb;
        }
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $ns = 0;
        $height = 0;
        while ($i < $nb) {
            // Get next character
            $c = $s[$i];
            if ($c == "\n") {
                // Explicit line break
                if ($this->ws > 0) {
                    $this->ws = 0;
                    $this->_out('0 Tw');
                }
                //Increase Height
                $height += $h;
                ++$i;
                $sep = -1;
                $j = $i;
                $l = 0;
                $ns = 0;
                continue;
            }
            if ($c == ' ') {
                $sep = $i;
                $ls = $l;
                ++$ns;
            }
            $l += $cw[$c];
            if ($l > $wmax) {
                // Automatic line break
                if ($sep == -1) {
                    if ($i == $j) {
                        ++$i;
                    }
                    if ($this->ws > 0) {
                        $this->ws = 0;
                        $this->_out('0 Tw');
                    }
                    //Increase Height
                    $height += $h;
                } else {
                    if ($align == 'J') {
                        $this->ws = ($ns > 1) ? ($wmax - $ls) / 1000 * $this->FontSize / ($ns - 1) : 0;
                        $this->_out(sprintf('%.3F Tw', $this->ws * $this->k));
                    }
                    //Increase Height
                    $height += $h;
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $ns = 0;
            } else {
                ++$i;
            }
        }
        // Last chunk
        if ($this->ws > 0) {
            $this->ws = 0;
            $this->_out('0 Tw');
        }
        //Increase Height
        $height += $h;

        return $height;
    }
    
    function MultiCellBltArray($w, $h, $blt_array, $border=0, $align='J', $fill=false)
    {
        if (!is_array($blt_array))
        {
            die('MultiCellBltArray requires an array with the following keys: bullet,margin,text,indent,spacer');
            exit;
        }
                
        //Save x
        $bak_x = $this->x;
        
        for ($i=0; $i<sizeof($blt_array['text']); $i++)
        {
            //Get bullet width including margin
            $blt_width = $this->GetStringWidth($blt_array['bullet'] . $blt_array['margin'])+$this->cMargin*2;
            
            // SetX
            $this->SetX($bak_x);
            
            //Output indent
            if ($blt_array['indent'] > 0)
                $this->Cell($blt_array['indent']);
            
            //Output bullet
            $this->Cell($blt_width,$h,$blt_array['bullet'] . $blt_array['margin'],0,'',$fill);
            
            //Output text
            $this->MultiCell($w-$blt_width,$h,$blt_array['text'][$i],$border,$align,$fill);
            
            //Insert a spacer between items if not the last item
            if ($i != sizeof($blt_array['text'])-1)
                $this->Ln($blt_array['spacer']);
            
            //Increment bullet if it's a number
            if (is_numeric($blt_array['bullet']))
                $blt_array['bullet']++;
        }
    
        //Restore x
        $this->x = $bak_x;
    }
    
    
    
    
    
    
}