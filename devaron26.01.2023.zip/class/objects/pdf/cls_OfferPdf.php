<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class OfferPdf extends OrderPdf
{
    
    function Header()
    {
        /*global $title;
        // Arial bold 15
        $this->SetFont('Arial','B',15);
        // Calculate width of title and position
        $w = $this->GetStringWidth($title)+6;
        $this->SetX((210-$w)/2);
        // Colors of frame, background and text
        $this->SetDrawColor(0,80,180);
        $this->SetFillColor(230,230,0);
        $this->SetTextColor(220,50,50);
        // Thickness of frame (1 mm)
        $this->SetLineWidth(1);
        // Title
        $this->Cell($w,9,$title,1,1,'C',true);
        // Line break
        $this->Ln(10);*/
    }

    

    
    public function __construct($Order, $Buyer)
    {
        parent::__construct();
        $this->Order = $Order;
        $this->Buyer = $Buyer;
        
        /* var_dump($this->Order);
        exit();*/
        
        //$this->renderPage();
        $this->Products = $Order['Products'];
        $this->Counts = count( $Order['Products'] );
        
        $this->SetAutoPageBreak( false );
        
    }
    
    
    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial','',8);
        //$this->SetTextColor(204, 204, 204);
        // Text color in gray
        //$this->SetTextColor(128);
        // Page number
        //$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');

 
        $this->Text(15,279, utf8_decode( "Geschäftsführer:" ) );
        $this->Text(15,283, utf8_decode( "" ) );     
        
        $this->Text(40,279, "Bankverbindung:" );
        $this->Text(40,283, "IBAN.:".utf8_decode(STATIC_IBAN) );
        $this->Text(40,287, "BIC.:".utf8_decode(STATIC_BIC) );
        $this->Text(40,291, utf8_decode(STATIC_BANK_NAME) );
        

        $this->Text(90,279, "Amtsgericht Dresden:" );
        $this->Text(90,283, "HRB 34874 " );
        $this->Text(90,287, utf8_decode(STATIC_FINANZ_NUMBER) );
        
        
        $this->Text(130,279, "Telefon: " . STATIC_PHONE );
        $this->Text(130,283, "Telefax: " . STATIC_FAX );
        $this->Text(130,287, "Mail: " . STATIC_MAIL );
        $this->Text(130,291, "Web: " . utf8_decode( STATIC_WEB ) );
        $this->Text(178,284, "Seite:" . $this->PageNo() );
        $this->SetLineWidth(0.5);
        $this->SetDrawColor(255,213,0);
        $this->Line(15, 280, 190,280);
        
        
    }
    
    
    
    
    
    /**
     * fügt die adresse hinzu
     */
    public function writeAdress()
    {
        $this->SetY(0);
        $this->SetFont('Arial','b',42);    
        $this->Image('./img/logo.png',15,20);
        
        //$this->Image('./img/CE.png',15,32);
        
        $this->SetTextColor(204, 204, 204);
        $this->SetFont('Arial','',8);
        
        //$this->Text(35,38,  utf8_decode("DIN EN 14351-1:2006") );
        $this->Text(15,45,  utf8_decode("Torshop Hentschel") . " " . utf8_decode(STATIC_STREET) . " " . utf8_decode(STATIC_CITY) );
        
        $this->SetTextColor(0, 0, 0); 
        
        $this->SetFont('Arial','', 12);
        $this->Text(129,45,  "Angebotsdatum:");
        $this->Text(137,55,  "Angebotsnr:");
        //$this->Text(140,65,  "Lieferdatum:");
        
        $this->SetLineWidth(0.1);
        $this->Line(165,46, 190,46); // Datum
        $this->Line(165,56, 190,56); //Rechnungs nummer
        
        //$this->Line(165,66, 190,66); // Lieferdatum
        

        $this->Text(165,45,  date("d.m.Y") );
        
        $this->Text(165,55,  "A_TSH / " . $this->Order['OrderId'],0,1,'R');
        
        //$this->Text(165,65,  date("d.m.Y") );
        
        
        $this->SetFont('Arial','b',12);
        $this->Text(15,55,  utf8_decode("Angebot an:"));
        
        
        $this->SetFont('Arial','',12);
        if($this->Buyer['CompanyName'])
        {
            $this->Text(15,60,  utf8_decode($this->Buyer['CompanyName']));
            $this->Text(15,65,  utf8_decode($this->Buyer['SureName'] . " " . $this->Buyer['Name'] ));
            $this->Text(15,70,  utf8_decode($this->Buyer['Street']));
            $this->Text(15,75,  utf8_decode($this->Buyer['Zip']));
            $this->Text(28,75,  utf8_decode($this->Buyer['Town']));
        } else 
        {
            $this->Text(15,80,  utf8_decode($this->Buyer['SureName'] . " " . $this->Buyer['Name'] ));
            $this->Text(15,85,  utf8_decode($this->Buyer['Street']));
            $this->Text(15,90,  utf8_decode($this->Buyer['Zip']));
            $this->Text(28,90,  utf8_decode($this->Buyer['Town']));
        }
        
        
        if($this->Buyer['Title'] == 'Herr')
        {
            $this->Text(15,120,  "Sehr geehrter Herr " . $this->Buyer['Name'] . ",");
        } else 
        {
            $this->Text(15,120,  "Sehr geehrte Frau " . $this->Buyer['Name'] . ",");
        }
        
        $this->Text(15,125,  utf8_decode("Ihr Angebot ist bei uns eingegangen und wir werden so schnell als möglich das Angebot prüfen.") );
    }
    
    
    
        

    
    
    

}