<?php

abstract class Collection implements Iterator
{

    protected $Elements = null;
    protected $ElementCounter = 0;

    /**
     * gibt ein object an hander seiner id zurück
     *
     * @param int $Id
     * @return objekt
     */
    public function getById($Id)
    {
        foreach ($this->Elements as $Element)
        {
            if ($Element->Id == $Id)
            {
                return $Element;
            }
        }
    }



    public function add(i_CollectionElement $Element)
    {
        $this->Elements[] = $Element;
        $this->ElementCounter++;
    }

    /**
     * gibt die anzahl der element zurück
     *
     * @return int
     */
    public function getCount()
    {
        return count($this->Elements);
    }

    public function __construct()
    {
        $this->Elements = array();
    }

    /**
     * gibt true zurück wenn die Collection elemente besitzt
     *
     * @return bool
     */
    public function hasElements()
    {
        if (!count($this->Elements))
        {
            return false;
        }
        return true;
    }

    public function getAll()
    {
        return $this->Elements;
    }

    /**
     * gibt die anzahl der element zurück
     *
     * @return int
     */
    public function countElements()
    {
        return count($this->Elements);
    }

    /**
     * gibt das element mit dem angegebene index zurück wird kein element gefunden wird false zurück gegeben
     *
     * @param int $Index
     * @return Object
     */
    public function getByIndex($Index)
    {
        if ($this->countElements() <= 0)
            return false;

        return $this->Elements[$Index];
    }

    public function rewind()
    {
        if (!isset($this->Elements))
        {
            return false;
        }
        reset($this->Elements);
    }

    public function current()
    {
        if (!isset($this->Elements))
        {
            return false;
        }
        $Var = current($this->Elements);
        return $Var;
    }

    public function key()
    {
        if (!isset($this->Elements))
        {
            return false;
        }
        $Var = key($this->Elements);
        return $Var;
    }

    public function next()
    {
        $Var = next($this->Elements);
        return $Var;
    }

    public function valid()
    {
        $Var = $this->current() !== false;
        return $Var;
    }

    public function mixElements()
    {
        shuffle($this->Elements);
        return true;
    }

    public function toArray()
    {
        $arrayList = array();
        for ($i = 0, $cn = $this->getCount(); $i < $cn; $i++)
        {
            $arrayList[] = $this->Elements[$i]->toArray();
        }
        return $arrayList;
    }

    public function toJson()
    {

        return json_encode($this->toArray());
    }

    /**
     * gibt alle Ids alls Array zurück
     * @return type
     */
    public function getIds()
    {
        $List = array();
        foreach ($this->Elements as $Element)
        {
            $List[] = $Element->getId();
        }
        return $List;
    }

    /**
     * gibt alle Ids als string zurück 1,2,10
     * @param type $Seperator
     * @return type
     */
    public function getIdsAsString( $Seperator = "," )
    {
        $List = $this->getIds();
        return implode($Seperator, $List);
    }

    /**
     * entfernt alle elemente an hand Ihrer Ids aus der Collection
     * @param Collection $Collection
     * @return \Collection
     */
    public function deleteCollection(Collection $CollectionToDelete)
    {
        $Elements = array();
        $StudentenCollection = new StudentCollection();
        
        
        foreach ($this->Elements as $Element)
        {
            if( $CollectionToDelete->getById( $Element->getId() ) ->getId() )
            {
                continue;
            }
            $StudentenCollection->add($Element);
           
        }
        return $StudentenCollection;
    }

    /**
     * entfernt das element anhand der Id aus der Collection
     * @param type $Id
     * @return type
     */
    public function deleteById($Id)
    {
        $i = 0;
        foreach ($this->Elements as $Element)
        {
            if ($Element->getId() == $Id)
            {
                unset($this->Elements[$i]); // element aus Collection entfernen
				echo "entfernt";
                $this->ElementCounter = count( $this->Elements );
                //return;
            }
            $i++;
        }
    }

    public function shuffelCollection()
    {
        shuffle($this->Elements);
    }

    /**
     * gibt ein Attrebut als Array zurück
     * @param String $Attribut
     * @return Array kann leer sein wenn nichts gefunden worden ist.
     */
    public function getAttributeAsArray($Attribut, $Unique = true)
    {
        $List = array();
        foreach ($this->Elements as $Element)
        {
            $List[] = $Element->{'get' . $Attribut}();
        }
        //var_dump($List);
        if ($Unique)
        {
            return array_unique($List);
        }
        return $List;
    }
    
    public function getByAttributeAsArray( $AttributName, $Value )
    {
        $ClassName = get_class($this);
        $NewCollection = new $ClassName();
        foreach ( $this->Elements as $Element )
        {
            if( $Element->{'get' . $AttributName}() ==  $Value )
            {
                $NewCollection->add( $Element );
            }
        }
        return $NewCollection;
    }
    

}

?>