<?php
abstract class i_CollectionElement
{

    protected $Id;
    
    public function getId()
    {
        return $this->Id;
    }

    public static function getEmptyInstance()
    {
        return new self(array());
    }

    public function __construct( $Array = false )
    {      
        if ( is_array( $Array ) )
        {
            $this->setValuesFromArray( $Array );
            return;
        }
    }

    public function setValuesFromArray( $Array, $Stripslashes = false )
    {
        //var_dump($Array);
        //var_dump($this);
        
        foreach ($Array as $Key => $Value)
        {
            
            $TempNameParts = explode( '_', $Key ); // wenn zusammen gesetzte namen
            $TempName = '';
            if( strlen($TempNameParts[1]) == 0 )
            {
                $Key = ucfirst( $TempNameParts[0] );
            } else 
            {
                $Key = ucfirst( $TempNameParts[1] );
            }
  
            try
            {
                /*var_dump($Key);
                //var_dump(get_class($this));
                if( $Key == 'ParentId')
                {
                    var_dump(get_class($this));
                    var_dump(implode($Value));
                    exit();
                    $this->setParentId(implode($Value) );
                    continue;
                }*/
                if ( method_exists( $this, 'set' . $Key ) )
                {
                    if(is_array($Value))$Value = implode (",", $Value);
                    call_user_func_array( array( $this, 'set' . $Key ), array( $Value ) ); // benutzt die setter
                     continue;
                } 
                else 
                {
                    //var_dump($Key . " Not Found");
                }
            } catch (exeption $e)
            {
                // do log
                var_dump( "ORM Error: Keine setter funktion gefunden oder Property" );
                exit(); 
            }
        }   
    }

    public function toArray()
    {
        $temp = get_object_vars($this);
        $keys = array_keys($temp);
        for ($i = 0, $cn = count($keys); $i < $cn; $i++)
        {
            $methodName = 'get' . $keys[$i];
            if (method_exists($this, $methodName))
                $temp[$keys[$i]] = $this->$methodName();
        }
        $temp['ClassType'] = get_class($this);
        return $temp;
    }

    /**
     * gibt das json äguvalent des Objectes zurück
     * @return string
     */
    public function toJson()
    {

        $Temp = $this->toArray();
        $Temp['ClassType'] = get_class($this);
        return json_encode($Temp);
    }
    
    /**
     * entfernt alle blöden zeichen aus dem string und macht ihn lowercase
     *
     * @return string
     */
    public function cleanString( $String )
    {
        $Regex ='/[^a-zA-Z :,. 0-9_,+;-]/';
        $Temp = preg_replace ( $Regex, '', $String );

        return strtolower ($String);
    }

    /**
     * Parst String für Text-Formatierung
     * [f][/f], [b][/b] ... fett
     * [k][/k], [i][/i] ... kursiv
     * [u][/u] ... unterschtrichen
     * \n ... Zeilenumbruch
     * [h1][/h1] - [h5][/h5] Überschriften
     */
    public function parseFormatting($Text)
    {
        return Utility::parseFormatting($Text);
        $OpeningTagsSearch = array("[f]","[b]","[k]","[i]","[u]","[h1]","[h2]","[h3]","[h4]","[h5]");
        $OpeningTagsReplace = array(
            "<span style='font-weight: bold;'>",
            "<span style='font-weight: bold;'>",
            "<span style='font-style: italic;'>",
            "<span style='font-style: italic;'>",
            "<span style='text-decoration: underline;'>",
            "<h1>",
            "<h2>",
            "<h3>",
            "<h4>",
            "<h5>",
        );
        
        $ClosingTagsSearch = array("[/f]","[/b]","[/k]","[/i]","[/u]","[/h1]","[/h2]","[/h3]","[/h4]","[/h5]");
        $ClosingTagsReplace = array("</span>","</span>","</span>","</span>","</span>","</h1>","</h2>","</h3>","</h4>","</h5>",);
        
        $Text = str_replace($OpeningTagsSearch, $OpeningTagsReplace, $Text);
        $Text = str_replace($ClosingTagsSearch, $ClosingTagsReplace, $Text);

        $Text = str_replace("\n", "<br>", $Text);

        return $Text;
    }

    public function clearTextOfFormatting($Text)
    {
        $OpeningTagsSearch = array("[f]","[b]","[k]","[i]","[u]","[h1]","[h2]","[h3]","[h4]","[h5]");
        $OpeningTagsReplace = array("", "", "", "", "", "", "", "", "", "");
        
        $ClosingTagsSearch = array("[/f]","[/b]","[/k]","[/i]","[/u]","[/h1]","[/h2]","[/h3]","[/h4]","[/h5]");
        $ClosingTagsReplace = array("", "", "", "", "", "", "", "", "", "");
        
        $Text = str_replace($OpeningTagsSearch, $OpeningTagsReplace, $Text);
        $Text = str_replace($ClosingTagsSearch, $ClosingTagsReplace, $Text);

        // $Text = str_replace("\n", "<br>", $Text);

        return $Text;
    }
    
    
        /**
     * gibt alle member variablen zurück
     * @return array
     */
    public function getMembers()
    {
        $temp = get_object_vars( $this );
        $temp['ClassType'] = get_class( $this );
        return $temp;
    }
    
    
    public function getMembersForTemplate()
    {
        return $this->getMembers();
    }
    
    
    
    
}
?>