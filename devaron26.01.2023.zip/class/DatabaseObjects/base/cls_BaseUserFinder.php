<?php
class BaseUserFinder extends SystemFinder
{
	function __construct()
	{
		parent::__construct();
	}

	protected $Fields = array('i_Id','d_CreateDate','s_Name','s_Pass','d_LastLogin','s_Mail','i_Type','s_adName','i_Active','s_EntryIds','i_LeasedEmployee','s_Department','b_ErrorReporter','s_MailCC','i_CanPlan');

	protected function doLoad($RecordSet)
	{
		$UserCollection = new UserCollection();
		foreach ($RecordSet as $Row)
		{
			$UserCollection->add($this->load($Row));
		}
		return $UserCollection;
	}

	protected function load($Row)
	{
		return new User($Row['i_Id'],$Row['d_CreateDate'],$Row['s_Name'],$Row['s_Pass'],$Row['d_LastLogin'],$Row['s_Mail'],$Row['i_Type'],$Row['s_adName'],$Row['i_Active'],$Row['s_EntryIds'],$Row['i_LeasedEmployee'],$Row['s_Department'],$Row['b_ErrorReporter'],$Row['s_MailCC'],$Row['i_CanPlan']);
	}

	public function findAll()
        {
            $Sql ="select  i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
                    from tbl_user";
            return $this->doLoad($this->MySql->executeQuery($Sql));
        }

	public function findById($Id)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where i_Id = '".$Id."'";
		return $this->doLoad($this->MySql->executeQuery($Sql))->getByIndex(0);
	}

	public function findByCreateDate($CreateDate)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where d_CreateDate = '".$CreateDate."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByName($Name)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where s_Name = '".$Name."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByPass($Pass)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where s_Pass = '".$Pass."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByLastLogin($LastLogin)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where d_LastLogin = '".$LastLogin."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByMail($Mail)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where s_Mail = '".$Mail."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByType($Type)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where i_Type = '".$Type."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByAdName($AdName)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where s_adName = '".$AdName."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByActive($Active)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where i_Active = '".$Active."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByEntryIds($EntryIds)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where s_EntryIds = '".$EntryIds."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByLeasedEmployee($LeasedEmployee)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where i_LeasedEmployee = '".$LeasedEmployee."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByDepartment($Department)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where s_Department = '".$Department."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByErrorReporter($ErrorReporter)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where b_ErrorReporter = '".$ErrorReporter."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByMailCC($MailCC)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where s_MailCC = '".$MailCC."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByCanPlan($CanPlan)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user
		where i_CanPlan = '".$CanPlan."'";
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByValue($StringValue ,  $Limit = 30)
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user where i_Id like '%".$StringValue."%'  or d_CreateDate like '%".$StringValue."%'  or s_Name like '%".$StringValue."%'  or s_Pass like '%".$StringValue."%'  or d_LastLogin like '%".$StringValue."%'  or s_Mail like '%".$StringValue."%'  or i_Type like '%".$StringValue."%'  or s_adName like '%".$StringValue."%'  or i_Active like '%".$StringValue."%'  or s_EntryIds like '%".$StringValue."%'  or i_LeasedEmployee like '%".$StringValue."%'  or s_Department like '%".$StringValue."%'  or b_ErrorReporter like '%".$StringValue."%'  or s_MailCC like '%".$StringValue."%'  or i_CanPlan like '%".$StringValue."%' ";		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

	public function findByIdArray($IdArray )
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan
		from tbl_user where i_Id in (".implode(",", $IdArray).")";		return $this->doLoad($this->MySql->executeQuery($Sql));
	}

}
		?>