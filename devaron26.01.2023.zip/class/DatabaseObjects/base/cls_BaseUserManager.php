<?php
class BaseUserManager extends SystemManager
{

	function __construct()
	{
		parent::__construct();
	}

	protected $Fields = array('i_Id','s_Name','s_Pass','d_LastLogin','s_Mail','i_Type','s_adName','i_Active','s_EntryIds','i_LeasedEmployee','s_Department','b_ErrorReporter','s_MailCC','i_CanPlan');

	public function insertUser(BaseUser $User)
	{
		$Sql="INSERT INTO `tbl_user`
 		(s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC,i_CanPlan)
		VALUES 
		(
		'".$User->getName()."',
		'".$User->getPass()."',
		'".$User->getLastLogin()."',
		'".$User->getMail()."',
		'".$User->getType()."',
		'".$User->getadName()."',
		'".$User->getActive()."',
		'".$User->getEntryIds()."',
		'".$User->getLeasedEmployee()."',
		'".$User->getDepartment()."',
		'".$User->getErrorReporter()."',
		'".$User->getMailCC()."',
		'".$User->getCanPlan()."'		)";
		return $this->MySql->executeNoneQuery($Sql);
	}
	public function updateUser(BaseUser $User)
	{
		$Sql="UPDATE `tbl_user` SET 	
		s_Name='".$User->getName()."',
		s_Pass='".$User->getPass()."',
		d_LastLogin='".$User->getLastLogin()."',
		s_Mail='".$User->getMail()."',
		i_Type='".$User->getType()."',
		s_adName='".$User->getadName()."',
		i_Active='".$User->getActive()."',
		s_EntryIds='".$User->getEntryIds()."',
		i_LeasedEmployee='".$User->getLeasedEmployee()."',
		s_Department='".$User->getDepartment()."',
		b_ErrorReporter='".$User->getErrorReporter()."',
		s_MailCC='".$User->getMailCC()."',
		i_CanPlan='".$User->getCanPlan()."'	 WHERE `i_Id` =".$User->getId();
		return $this->MySql->executeNoneQuery($Sql);
	}
	public function deleteUser(baseUser $User)
	{
		$Sql="DELETE FROM `tbl_user` WHERE `i_Id` =".$User->getId();
		return $this->MySql->executeNoneQuery($Sql);
	}
}
?>