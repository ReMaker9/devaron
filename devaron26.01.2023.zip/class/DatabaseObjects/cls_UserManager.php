<?php
class UserManager extends BaseUserManager
{
	/*
		aktualisiert einen nutzer in der ESB Datenbanktabelle
	*/
	public function updateEsbUser($Id, $AnzeigeName, $ClearPass , $Mail, $MailCC, $AdName, $Active, $UserLevel , $ErrorReporter )
	{
		$LoginName = $this->getLoginName( $AnzeigeName );
		//$LoginName = $AnzeigeName;
		
		// var_dump("hier weiter machen!");
		// der reconnect klappt nicht
		// exit();
		if( strlen($ClearPass) )
		{
			$Sql = "UPDATE `Users` SET 	
			loginName = '" . $LoginName . "',
			anzeigeName = '" . $AnzeigeName . "',
			passwort='" . $ClearPass . "',
			email='" . $Mail . "',
			emailcc='" . $MailCC . "',
			adName='" . $AdName . "',
			aktiv='" . $Active . "',
			klasse='" . $UserLevel . "',
			b_ErrorReporter='" . $ErrorReporter . "'
			where id = " . $Id . "";
		} else 
		{
			$Sql = "UPDATE `Users` SET 	
			loginName = '" . $LoginName . "',
			anzeigeName = '" . $AnzeigeName . "',
			email='" . $Mail . "',
			emailcc='" . $MailCC . "',
			adName='" . $AdName . "',
			aktiv='" . $Active . "',
			klasse='" . $UserLevel . "',
			b_ErrorReporter='" . $ErrorReporter . "'
			where id = " . $Id . "";
		}
		
		//echo $Sql ; exit();
		//var_dump( $this->MySql );
		
		return $this->MySql->executeNoneQuery($Sql);
	}

	
	public function insertEsbUser( $Id, $AnzeigeName, $ClearPass , $Mail, $MailCC, $AdName, $Active, $UserLevel, $UserLevelString , $ErrorReporter )
	{
		$LoginName = $this->getLoginName( $AnzeigeName );
		
		$Sql = "INSERT INTO `shiftreport`.`Users` (`id`, `loginName`, `anzeigeName`, `passwort`, `rechteStufe`, `sessionID`, `aktiv`, `klasse`, `email`, `emailcc`, `adName`, b_ErrorReporter) VALUES 
			(" . $Id . ", '" . $LoginName . "', '" . $AnzeigeName . "', '". $ClearPass . "', '" . $UserLevel . "', NULL, '" . $Active . "', '" . $UserLevelString . "', '" . $Mail . "', '" . $MailCC . "', '" . $AdName . "', '" . $ErrorReporter . "' );";
		return $this->MySql->executeNoneQuery($Sql);
	}
	
	protected function getLoginName( $AnzeigeName )
	{
		$AnzeigeName = trim( $AnzeigeName );
		//$LoginNameTemp =  preg_split("/[.- ]/", $AnzeigeName );
		$LoginNameTemp =  explode( "-", str_replace( array( " ","." ), "-" , $AnzeigeName ) );
		$LoginName = implode("-", $LoginNameTemp);
		$LoginName = str_replace( "ö", "oe", $LoginName );
		$LoginName = str_replace( "ä", "ae", $LoginName );
		$LoginName = str_replace( "ü", "ue", $LoginName );
		
		
		return strtolower($LoginName);
		
	}
	
	


}
?>