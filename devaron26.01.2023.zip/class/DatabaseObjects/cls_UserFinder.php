<?php

class UserFinder extends BaseUserFinder
{
    /**
     * 
     * @param string $Name
     * @param string $Pass
     * @return User
     */
    public function findByNameAndPass( $Name, $Pass )
    {
        $Sql = "select i_Id,s_Name,s_Pass,d_LastLogin,s_Mail,d_CreateDate,i_Type,i_CanPlan
		from tbl_user
		where s_Name = '" . $Name . "' and s_Pass = '" . $Pass . "'";
        return $this->doLoad( $this->MySql->executeQuery($Sql) )->getByIndex( 0 );
    }
	
	
	public function findAllActive()
    {
        $Sql = "select " . implode($this->Fields, ",") . "
		from tbl_user
		where i_Active = '1' ";
        return $this->doLoad( $this->MySql->executeQuery( $Sql ) );
    }
	

    /**
     * 
     * @param string $Name
     * @param string $Pass
     * @return User
     */ 
    public function findByMailAndPass( $Name, $Pass )
    {
        $Sql = "select i_Id,s_Name,s_Pass,d_LastLogin,s_Mail,d_CreateDate,i_Type,i_CanPlan
		from tbl_user
		where s_Mail = '" . $Name . "' and s_Pass = '" . $Pass . "'";
        return $this->doLoad( $this->MySql->executeQuery( $Sql ) )->getByIndex( 0 );
    }



	/**
	*	angegeben werden muss die aktuallee woche minus eine woche um die richtig berechnete schicht zurück zu bekommen
	*
	*/
    public function getLastTemplateIdByUserIdArrayAndWeekAndYear( $UserIdArray, $Week, $Year )
    {
        $Sql = "select u.i_Id as UserId
		, if(  COALESCE(pe.i_PlaningTemplateId, \"-1\" , pe.i_PlaningTemplateId) =-1, 1 ,  if( COALESCE(pe.i_PlaningTemplateId, \"1\" , pe.i_PlaningTemplateId) < 7 , COALESCE(pe.i_PlaningTemplateId, \"1\" , pe.i_PlaningTemplateId) + 3 , COALESCE(pe.i_PlaningTemplateId, \"1\" , pe.i_PlaningTemplateId) - 6 ) ) as Lastplanning 
		,pe.i_PlaningTemplateId
		
		,( select 
pe1.i_PlaningTemplateId
from tbl_user u1 
left join tbl_planningentry pe1 on pe1.i_UserId = u1.i_Id and weekofyear(pe1.d_Date) = " . $Week . " and year( pe1.d_Date ) = 2020 
where u1.i_Id = u.i_Id and weekofyear(pe1.d_Date) = " . $Week . " and year(pe1.d_Date) = 2020  or 
u1.i_Id = u.i_Id and pe1.d_Date is null 
group by u.i_Id ) as 'Last'
		
		
		,( select 
pe1.i_PlaningTemplateId
from tbl_user u1 
left join tbl_planningentry pe1 on pe1.i_UserId = u1.i_Id and weekofyear(pe1.d_Date) = " . ( $Week -1 ) . " and year(pe1.d_Date) = 2020 
where u1.i_Id = u.i_Id and weekofyear(pe1.d_Date) = " . ($Week -1 ) . " and year(pe1.d_Date) = 2020  or 
u1.i_Id = u.i_Id and pe1.d_Date is null 
group by u.i_Id ) as 'Before1'

,( select 
pe2.i_PlaningTemplateId
from tbl_user u2 
left join tbl_planningentry pe2 on pe2.i_UserId = u2.i_Id and  weekofyear(pe2.d_Date) = " . ($Week - 2) . " and year(pe2.d_Date) = " . $Year . "
where u2.i_Id = u.i_Id and weekofyear(pe2.d_Date) = " . ($Week - 2) . " and year(pe2.d_Date) = 2020  or 
u2.i_Id = u.i_Id and pe2.d_Date is null 
group by u.i_Id ) as 'Before2'

,( select 
pe3.i_PlaningTemplateId
from tbl_user u3 
left join tbl_planningentry pe3 on pe3.i_UserId = u3.i_Id and  weekofyear(pe3.d_Date) = " . ($Week - 3) . " and year(pe3.d_Date) = " . $Year . "
where u3.i_Id = u.i_Id and  weekofyear(pe3.d_Date) = " . ($Week -3) . " and year(pe3.d_Date) = " . $Year . " or 
u3.i_Id = u.i_Id and pe3.d_Date is null 
group by u.i_Id ) as 'Before3'
		
		
		from tbl_user u 
			left join tbl_planningentry pe on pe.i_UserId = u.i_Id and weekofyear(pe.d_Date) = " . $Week . " and year(pe.d_Date) = " . $Year . " 
			where u.i_Id in (" . implode($UserIdArray, ",") . ") and weekofyear(pe.d_Date) = " . $Week . " and year(pe.d_Date) = " . $Year . "  or 
			u.i_Id in (" . implode($UserIdArray, ",") . ") and pe.d_Date is null 
			group by u.i_Id";
			
			
		$Result = $this->MySql->executeQuery( $Sql );
		$ReturnArray = array();
		foreach($Result as $Row )
		{
			
			if( $Row['i_PlaningTemplateId'] )
			{
				$Shift = $Row['Lastplanning'] = $Row['i_PlaningTemplateId'];
			} else 
			{
				$Shift = Essel::rotateShiftnumber( $Row['Last'] );
				$Row['Lastplanning'] = $Shift;
			}
			
			
			

			
			
			
			if( !$Shift && $Row['Before1'] )
			{
				$Row['Lastplanning'] = Essel::rotateShiftnumber( $Row['Before1'] );
			}
			
			if( !$Shift && $Row['Before2'] )
			{
				$Row['Lastplanning'] = Essel::rotateShiftnumber( $Row['Before2'] );
			}
			
			if( !$Shift && $Row['Before3'] )
			{
				$Row['Lastplanning'] = Essel::rotateShiftnumber( $Row['Before3'] );
			}
			
			
			
			$ReturnArray[$Row['UserId']] = $Row;
		}
	
        return $ReturnArray;
    }



	public function findAllAvailableByDayWithType( $Day, $Name, $PlaningTemplateEntryId )
    {
		$Name = strtolower( $Name );
        $Sql = "
		select u.i_Id,u.s_Name,u.s_Pass,u.d_LastLogin,u.s_Mail,u.d_CreateDate,u.i_Type,u.i_CanPlan
		from tbl_user u
		left join tbl_planningentry pe on pe.i_UserId = u.i_Id and pe.d_Date = '" . $Day . "' /* die Planung auf das Datum joinen*/
		left join tbl_holidays h on h.i_UserId = u.i_Id and h.d_Date = '" . $Day . "'
		left join tbl_sickdays sd on sd.i_UserId = u.i_Id and sd.d_Date = '" . $Day . "'
		where lower(u.s_Name) like '%" . $Name . "%'
		and pe.i_Id is null /* nur zurük geben wenn der nutzer noch nicht für den tag verplant worden ist */
		and h.i_Id is null 
		and sd.i_Id is null
		and u.s_Name != ''
		and FIND_IN_SET('" . $PlaningTemplateEntryId . "' , u.s_EntryIds )
		order by u.s_Name
		limit 20
		";
		
		/* select i_Id,s_Name,s_Pass,d_LastLogin,s_Mail,d_CreateDate,i_Type
		from tbl_user
		where s_Name like '%" . $Name . "%' */
        return $this->doLoad($this->MySql->executeQuery($Sql));
    }

	public function findAllAvailableIllByDay( $Day, $Name, $PlaningTemplateEntryId )
	{
		$Name = strtolower( $Name );
        $Sql = "
		select u.i_Id,u.s_Name,u.s_Pass,u.d_LastLogin,u.s_Mail,u.d_CreateDate,u.i_Type
		from tbl_user u
		left join tbl_planningentry pe on pe.i_UserId = u.i_Id and pe.d_Date = '" . $Day . "' /* die Planung auf das Datum joinen*/
		left join tbl_holidays h on h.i_UserId = u.i_Id and h.d_Date = '" . $Day . "'
		left join tbl_sickdays sd on sd.i_UserId = u.i_Id and sd.d_Date = '" . $Day . "'
		where lower( u.s_Name ) like '%" . $Name . "%'
		and sd.i_Id is null
		and pe.i_Id is null
		and h.i_Id is null
		and u.i_Active  = 1
		and u.s_Name != ''
		and ( u.s_Department = 'Druck' || u.s_Department = 'Lager' || u.s_Department = 'Produktion' || u.s_Department = 'QS' )
		and FIND_IN_SET('" . $PlaningTemplateEntryId . "' , u.s_EntryIds )
		order by u.s_Name
		limit 20
		";
		
		/* select i_Id,s_Name,s_Pass,d_LastLogin,s_Mail,d_CreateDate,i_Type
		from tbl_user
		where s_Name like '%" . $Name . "%' */
        return $this->doLoad($this->MySql->executeQuery($Sql));
	}



	
	public function findAllAvailableByDay( $Day, $Name )
    {
		$Name = strtolower( $Name );
        $Sql = "
		select u.i_Id,u.s_Name,u.s_Pass,u.d_LastLogin,u.s_Mail,u.d_CreateDate,u.i_Type
		from tbl_user u
		left join tbl_planningentry pe on pe.i_UserId = u.i_Id and pe.d_Date = '" . $Day . "' /* die Planung auf das Datum joinen*/
		left join tbl_holidays h on h.i_UserId = u.i_Id and h.d_Date = '" . $Day . "'
		left join tbl_sickdays sd on sd.i_UserId = u.i_Id and sd.d_Date = '" . $Day . "'
		where lower( u.s_Name ) like '%" . $Name . "%'
		and pe.i_Id is null /* nur zurük geben wenn der nutzer noch nicht für den tag verplant worden ist */
		and h.i_Id is null 
		and sd.i_Id is null
		and u.i_Active  = 1
		and u.s_Name != ''
		and ( u.s_Department = 'Druck' || u.s_Department = 'Lager' || u.s_Department = 'Produktion' || u.s_Department = 'QS' )
		order by u.s_Name
		limit 20
		";
		
		/* select i_Id,s_Name,s_Pass,d_LastLogin,s_Mail,d_CreateDate,i_Type
		from tbl_user
		where s_Name like '%" . $Name . "%' */
        return $this->doLoad($this->MySql->executeQuery($Sql));
    }
	
	
	
	public function findUserInHolydayByYearAndWeek($Year ,$Week)
    {
        $Sql = "select u.* from tbl_user u 
		join tbl_holidays h on h.i_UserId = u.i_Id 
		where u.i_Active = 1 and  weekofyear( h.d_Date ) = " . $Week . " and year( h.d_Date ) = " . $Year;
        return $this->doLoad($this->MySql->executeQuery($Sql));
    }
	
	public function getUserInHolydayByYearAndWeek($Year ,$Week)
    {
        $Sql = "select u.*, h.* 
		,(select count(pe.i_UserId) from tbl_planningentry pe where pe.i_UserId = u.i_Id and weekofyear( pe.d_Date ) = " . $Week . " and year( pe.d_Date ) = " . $Year . " and pe.d_Date = h.d_Date ) as Planed
		from tbl_user u 
		join tbl_holidays h on h.i_UserId = u.i_Id 
		where u.i_Active = 1 and u.s_Department != 'Verwaltung' and weekofyear( h.d_Date ) = " . $Week . " and year( h.d_Date ) = " . $Year . " group by u.i_Id, h.d_Date";

        return $this->MySql->executeQuery($Sql);
    }
	
	public function getUserIllByYearAndWeek( $Year ,$Week )
    {
        $Sql = "select u.*, sd.* 
		,(select count(pe.i_UserId) from tbl_planningentry pe where pe.i_UserId = u.i_Id and weekofyear( pe.d_Date ) = " . $Week . " and year( pe.d_Date ) = " . $Year . " and pe.d_Date = sd.d_Date ) as Planed
		from tbl_user u 
		join tbl_sickdays sd on sd.i_UserId = u.i_Id 
		where u.i_Active = 1 and  weekofyear( sd.d_Date ) = " . $Week . " and year( sd.d_Date ) = " . $Year;

        return $this->MySql->executeQuery($Sql);
    }
	
	public function findByValueSorted( $StringValue )
	{
		$Sql="select i_Id,d_CreateDate,s_Name,s_Pass,d_LastLogin,s_Mail,i_Type,s_adName,i_Active,s_EntryIds,i_LeasedEmployee,s_Department,b_ErrorReporter,s_MailCC
		from tbl_user where i_Id like '%".$StringValue."%'  or d_CreateDate like '%".$StringValue."%'  or s_Name like '%".$StringValue."%'  or s_Pass like '%".$StringValue."%'  or d_LastLogin like '%".$StringValue."%'  or s_Mail like '%".$StringValue."%'  or i_Type like '%".$StringValue."%'  or s_adName like '%".$StringValue."%'  or i_Active like '%".$StringValue."%'  or s_EntryIds like '%".$StringValue."%'  or i_LeasedEmployee like '%".$StringValue."%'  or s_Department like '%".$StringValue."%'  or b_ErrorReporter like '%".$StringValue."%'  or s_MailCC like '%".$StringValue."%' 
		order by i_Active desc
		";		
		return $this->doLoad($this->MySql->executeQuery($Sql));
	}
	
	
	public function getCollitionByDayAndUserId( $Day, $UserId )
	{
        $Sql = "
		select pe.d_date as Datum, pte.s_Name as 'Position', pt.s_Name as Schicht
		from tbl_user u
		left join tbl_planningentry pe on pe.i_UserId = u.i_Id and pe.d_Date = '" . $Day . "' /* die Planung auf das Datum joinen */
		left join tbl_holidays h on h.i_UserId = u.i_Id and h.d_Date = '" . $Day . "'
		left join tbl_sickdays sd on sd.i_UserId = u.i_Id and sd.d_Date = '" . $Day . "'
		left join tbl_planingtemplateentrytype pte on pte.i_Id = pe.i_PlaningTemplateEntryId
		left join tbl_planingtemplate pt on pt.i_Id = pe.i_PlaningTemplateId
		where u.i_Id = " . $UserId . "
		order by u.s_Name
		limit 20
		";
        return $this->MySql->executeQuery($Sql);
	}
	
	public function getCollitionByWeekAndYear( $Week , $Year )
	{
		$Sql = "
		select /*u.*,*/
 u.s_Name as Name,   pe.d_date as Datum, group_Concat( pte.s_Name ) as 'Position', pt.s_Name as Schicht
		from tbl_user u
		left join tbl_planningentry pe on pe.i_UserId = u.i_Id and weekofyear( pe.d_Date ) = " . $Week . " and year( pe.d_Date ) = " . $Year . " /* die Planung auf das Datum joinen */
		left join tbl_planingtemplateentrytype pte on pte.i_Id = pe.i_PlaningTemplateEntryId
		left join tbl_planingtemplate pt on pt.i_Id = pe.i_PlaningTemplateId
group by pe.d_date, u.i_Id
having count(u.i_Id) >1
		";
        return $this->MySql->executeQuery( $Sql );
	}
	
	public function getCollitionHolidayByWeekAndYear( $Week , $Year )
	{
		$Sql = "
		select 
		 u.s_Name as Name, h.d_Date   as Datum, group_Concat(distinct pte.s_Name ) as 'Position', pt.s_Name as Schicht
				from tbl_user u
				 join tbl_planningentry pe on pe.i_UserId = u.i_Id and weekofyear( pe.d_Date ) = " . $Week . " and year( pe.d_Date ) = " . $Year . " /* die Planung auf das Datum joinen */
				join tbl_holidays h on h.i_UserId = u.i_Id and weekofyear( h.d_Date ) = " . $Week . " and year( h.d_Date ) = " . $Year . " 
				left join tbl_planingtemplateentrytype pte on pte.i_Id = pe.i_PlaningTemplateEntryId
				left join tbl_planingtemplate pt on pt.i_Id = pe.i_PlaningTemplateId		 
		group by  u.i_Id, h.d_Date
		";
        return $this->MySql->executeQuery($Sql);
	}
	
	
	public function getHolidayByWeekAndYear( $Week , $Year )
	{
		$Sql = "select u.s_Name as Name, h.d_Date  as 'Date',  u.s_Department as 'Department'
		from tbl_user u 
		join tbl_holidays h on h.i_UserId = u.i_Id 
		where u.i_Active = 1 and  weekofyear( h.d_Date ) = " . $Week . " and year( h.d_Date ) = " . $Year . "
		group by u.i_Id, h.d_Date
		order by  u.s_Department , u.i_Id, h.d_Date
	";
        return $this->MySql->executeQuery($Sql);
	}
	
	
	
	
	
}

?>