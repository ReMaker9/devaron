<?php

/**
 * Programm: klasse für das dynamische zuweisen von templates über die bl
 * Type: Template
 * Description: mit diesem script ist es möglich temlates über die bl zu legen und so dynamischen im
 * design zu bleiben
 * Autor: Matthias Herzog 
 * */
class Template
{

    private $Header = "tpl_Header.php";
    private $Content = "tpl_Default.php";
    private $Footer = "tpl_Footer.php";
    private $Templates = array(); // templates die zu variabelen gemacht werden sollen
    private $Vars = array(); // die variabelen
    private static $Instance = null;
    private $Language = "Ger";

    /**
     * setzt den Pfad der sprechdateien
     *
     * @param string $Language nur der sufix der Sprachdatei  Lang_Ger.php ==> Ger
     * @return void 
     *
     */
    public function setLanguage($Language)
    {
        $this->Language = $Language;
    }

    /**
     * gibt eine instance vom typ Template zurück
     *
     * @param string $Template das template das geladen werden soll
     * @return Template
     *
     */
    public static function getInstance($Template = "")
    {
        if (self::$Instance === null)
        {
            self::$Instance = new Template($Template);
        }
        self::$Instance->setTemplate($Template);
        return self::$Instance;
    }

    public function __construct($Template = "")
    {
        $this->Content = $Template;
    }

    public function setTemplate($Template)
    {
        $this->Content = $Template;
    }

    public function setHeader($Header)
    {
        $this->Header = $Header;
    }

    public function setFooter($Footer)
    {
        $this->Footer = $Footer;
    }

    /**
     * entfernt alle templates/ variabelen aus dem objekt 
     *
     * @return bool 
     *
     */
    public function clear()
    {
        $this->Content = "";
        $this->Footer = "";
        $this->Header = "";
    }

    /**
     * fügt eine neue ausgabe zum output hinzu
     * es wird dann im template nach dem namen gesucht und dieser mit dem value ersetzt 
     * achtung wenn array übergeben werden 
     *
     * @param string $name
     * @param mixed $value
     */
    public function assign($Name, $Value)
    {
        $this->Vars[$Name] = $Value;
    }

    public function assignTemplate($Name, $Value)
    {
        $this->Templates[$Name] = $Value;
    }

    private function renderTemplates()
    {
        foreach ($this->Templates as $Template)
        {
            ob_start();
            if ($Template)
            {
                require_once("./view/" . $Template); // hier die ausgaben
            }
            $this->assign(key($Template), ob_get_clean());
        }
    }

    public function render()
    {
        echo $this->renderWithoutSend();
    }

    /**
     * rendert das TEMPLATE 
     *
     * @param bool $LanguageParsing gibt an ob die sprache geparst werden soll oder nicht
     * @return string 
     *
     */
    public function renderWithoutSend($LanguageParsing = true)
    {
        header('content-type: text/html; charset=utf-8');
        ob_start();
        if ($this->Content)
        {
            require_once("./view/" . $this->Content); // hier die ausgaben
        }
        $data = ob_get_clean(); // gibt ausgabe puffer zurück und löscht den puffer
        if ($LanguageParsing)
        {
            $data = $this->rePlaceLanguage($data);
        }
        return $data;
    }

    public function rePlaceLanguage($Data)
    {
        // sprach datei laden 
        $LangArray = parse_ini_file("./language/lang_" . $this->Language . ".php");

        // platzhalter im text ersetzen	
        $SearchArray = array_keys($LangArray);
        $ValueArray = array_values($LangArray);
        /* for($i=0;$i<count($SearchArray);$i++)
          { */
        $Data = str_replace($SearchArray, $ValueArray, $Data);
        /* }	 */
        return $Data;
    }

    /**
     * gibt die fehlerseite aus, mit den angegebenen parametern
     *
     * @param string $Header die überschrift des fehlers
     * @param string $Error die fehler beschreibung
     * @param string $BackLink der link zu vorhergehenden seite (index.php?section=NextLan)
     * @return void macht eine ausgabe auf den bildschirm
     *
     */
    public function renderError($Header, $Error, $BackLink)
    {
        $this->setTemplate("tpl_Error.php");
        $this->Assign("ErrorHeader", $Header);
        $this->Assign("ErrorString", $Error);
        $this->Assign("LastPage", $BackLink);
        $this->render();
    }

    /**
     * 
     * @param int $code abfrage code
     * @param type $message // die Nachricht zur abfrage kann leer gelassen werden
     * @param type $Response // ein Object zur rückghabe an den browser
     * @return void
     */
    public function outputJSON($code, $message, $Response = "")
    {
        header('Content-type: text/json');
        if ($Response && $Response instanceof Collection || $Response && $Response instanceof i_CollectionElement)
        {
            $Response = $Response->toArray();
        }

        $result = array(
            'code' => $code,
            'message' => $message,
            'response' => $Response
        );

        if (DEBUG_MODE)
        {
            $result['sql'] = PdoDataBase::getInstance()->getStatemtnStoreArray();
            $Request = new Request();
            //var_dump($Request->getParam());
            $result['param'] = $Request->convertToUTF8($Request->getParam());
        }
        //var_dump($result);
        //var_dump(json_encode($result));
        echo json_encode($result);
        return;
    }

    
    public function outputJSONParsed( $code, $message, $Response )
    {
        header('Content-type: text/json');
        //var_dump($Response);
        if ($Response && $Response instanceof Collection || $Response && $Response instanceof i_CollectionElement)
        {
            $Response = $Response->toArrayParsed();
        } else 
        {
            throw new Error("Wrong Response Type! Only Type Collection oder i_CollectionElement");
        }

        $result = array(
            'code' => $code,
            'message' => $message,
            'response' => $Response
        );

        if ( DEBUG_MODE )
        {
            $result['sql'] = PdoDataBase::getInstance()->getStatemtnStoreArray();
            $Request = new Request();
            //var_dump($Request->getParam());
            $result['param'] = $Request->convertToUTF8($Request->getParam());
        }
        //var_dump($result);
        //var_dump(json_encode($result));
        echo json_encode($result);
        return;
    }
    
    
    
    
    /**
     * gibt eine Datei aus mit Force Download header für den Browser
     * @param type $File
     * @param type $ContentType
     */
    public function outputFile($File, $ContentType = " application/pdf")
    {
        //header('Content-Description: File Transfer');
        header('Content-Type: ' . $ContentType);
        //header('Content-Type: application/text' );
        header('Content-Disposition: attachment; filename="' . basename($File) . '"');
        //header('Content-Disposition: filename="' . basename($File) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($File));
        readfile($File);
    }

    /**
     * wird zum suchen inerhalb des templates gebrauch wenn eine variabele gesucht wir die nicht deklariert ist dann suche in 
     * dieser funktion im array ob vorhanden wenn ja wird ersettzt wenn nicht wird null übergeben
     *
     * @param string $property
     * @return mixed
     */
    public function __get($property)
    {
        if (isset($this->Vars[$property]))
        {
            return $this->Vars[$property];
        }
        return null;
    }

    public static function renderSnippet($Path, $Vars)
    {
        extract($Vars);
        require ("./view/" . $Path ); // hier die ausgaben
    }

    /**
     * gibt eine HTML Liste zurück
     * @param array $Array das Array mit den daten
     * @param bool $Lable gibt an ob die schlüssel mit ausgegeben werden sollen
     * @return type
     */
    public function arrayToHtml($Array, $Lable = false)
    {
        if (!is_array($Array))
            return;
        $Temp = '<ul class="list-group">';
        foreach ($Array as $Key => $Value)
        {

            if ($Lable)
            {
                $Temp .= '<li class="list-group-item"><span class="Lable" style="width:200px">' . $Key . ':</span>' . $Value . '</li>';
                continue;
            }
            $Temp .= '<li class="list-group-item">' . $Value . '</li>';
        }
        $Temp .= "</ul>";
        return $Temp;
    }

    /**
     * gibt den datensatz als string zurück
     * @param String $Table User
     * @param String $DisplayName Name
     * @param String $Where Id
     * @param string $WhereValue 42
     */
        public function getElementAsString($Table, $DisplayName, $Where, $WhereValue)
    {
        $ClassName = $Table . "Finder";
        $Finder = new $ClassName();
        if (strlen($Where))
        {
            $ElementCollection = $Finder->{'findBy' . $Where}($WhereValue);
        } else 
            return "";
        
        //var_dump($ElementCollection);

        $Displays = explode("-", $DisplayName);

        if( $ElementCollection instanceof Collection )
        {
            $Element = $ElementCollection->getByIndex(0);
        } else 
        {
            $Element = $ElementCollection;
        }
        
  
            //var_dump($Element);
            $DisplayText = "";
            $DisplayArray = array();
            foreach ($Displays as $Func)
            {
                $DisplayArray[] = $Element->{'get' . $Func}();
                //$DisplayText .= $Element->{'get' .$Func}() . " ";
            }
            
            $DisplayText = implode(" - ", $DisplayArray);

           return  $DisplayText ;
     
    }
    
    
    /**
     * erzeugt html option element mit den werten der angegben tabelle und der Where Bedinung
     * @param String $Table
     * @param String $DisplayName   //aus Name-CompanyName wir die fkt getName() und getCompanyName() aufgerufen
     * @param String $Where         // UserId   findByUserId() wenn hier nichts angegeben wird wird findAll des Finders aufgerufen
     * @param String $WhereValue    // 1        Der angegebene Wert wird dann über den Finder des Objectes gesucht
     */
    public function getOptionHTMLElements($Table, $DisplayName, $Where, $WhereValue)
    {
        $ClassName = $Table . "Finder";
        $Finder = new $ClassName();
        if (strlen($Where))
        {
            $ElementCollection = $Finder->{'findBy' . $Where}($WhereValue);
        } else
        {
            $ElementCollection = $Finder->findAll();
        }

        $Displays = explode("-", $DisplayName);

        foreach ($ElementCollection as $Element)
        {
            $DisplayText = "";
            $DisplayArray = array();
            foreach ($Displays as $Func)
            {
                $DisplayArray[] = $Element->{'get' . $Func}();
                //$DisplayText .= $Element->{'get' .$Func}() . " ";
            }

            $DisplayText = implode(" - ", $DisplayArray);

            echo "<option value='" . $Element->getId() . "'>" . $DisplayText . "</option>";
        }
    }

    /**
     * sucht in der DB nach dem Object  und gibt das Atribut aus
     * @param type $Table
     * @param type $Display
     * @param type $Id
     * @param type $Seperator
     */
    public function getGetAtributByID($Table, $Display, $Id, $Seperator = " - ")
    {
        $ClassName = $Table . "Finder";
        //var_dump($ClassName);
        $Finder = new $ClassName();
        //var_dump($Finder);
        $Element = $Finder->{'findById'}($Id);
        //var_dump($Element);
        return $Element->{'get' . $Display}();
    }

    /**
     * ersetzt 1= ja, 0 = nein 
     * @param String $Value
     */
    public function intToString($Value)
    {
        switch ($Value)
        {
            case 1:
                return "Ja";
            case 0:
                return "Nein";

            default:
                return "keine Angabe";
        }
    }
    
    
    
    

    /**
     * formatiert das datum anhand der user einstellungen
     * @param String $Date englische datum
     * @return string
     */
    public function formatDate($Date)
    {
        return Convert::englishDateToGerman($Date);
    }

    /**
     * gibt den inhalt des Selects zurück
     * @param int $Value
     * @param String $Posibilitys ist kmma separiert
     * @return string
     */
    public function getSelectValue($Value, $Posibilitys)
    {
        $Posibilitys = explode(",", $Posibilitys);

        return $Posibilitys[$Value];
    }

    public function arrayToTable($Data, $TableClass = "")
    {
        $rows = array();

        if (!count($Data))
            return;
        $Temp = $Data[0];
        foreach ($Temp as $Key => $cell)
        {
            if (!$Key || !strlen($Key))
                continue;
            $Keys[] = "<td class='bold'>{$Key}</td>";
        }
        $rows[] = "<tr>" . implode('', $Keys) . "</tr>";


        foreach ($Data as $row)
        {
            $cells = array();
            foreach ($row as $cell)
            {
                $cells[] = "<td>{$cell}</td>";
            }
            $rows[] = "<tr>" . implode('', $cells) . "</tr>";
        }
        echo "<table  class='hci-table " . $TableClass . "'>" . implode('', $rows) . "</table>";
    }

    
        public function renderSnipet( $Path, $Vars )
    {
        extract($Vars);
        require ("./view/" . $Path ); // hier die ausgaben
    }
    
    public function outPutArrayCsv($ObjectArray, $FileName)
    {
        $ArrayKeys = array_keys($ObjectArray[0]);

        // CSV-Ausgabe
        header("Content-type: application/csv");
        header("Content-Disposition: attachment; filename=" . $FileName . "-" . date('Y.m.d-H.i') . ".csv");
        $fp = fopen('php://output', 'w');
        fprintf($fp, chr(0xEF) . chr(0xBB) . chr(0xBF));
        fputcsv($fp, $ArrayKeys, ';');
        foreach ($ObjectArray as $Object)
        {
            fputcsv($fp, $Object, ';');
        }
    }

}

?>