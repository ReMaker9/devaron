<?php

class CbSessionHandler implements SessionHandlerInterface
{
    private $savePath;
    private $SessionName ;
    private $Db ;


    public function open($savePath, $SessionName)
    {
        $this->savePath = $savePath;
        $this->SessionName = $SessionName;
        $this->Db = PdoDataBase::getInstance(); // datenbank holen

        return true;
    }

    public function close()
    {
        return true;
    }

    public function read($id)
    {
        $Sql = "select * from tbl_session where i_Id = '" . $id . "'";
        $Result = $this->Db->executeQuery($Sql); // low level sql
        if( count( $Result ) )
        {
           return $Result[0]['t_Content'];
        }
        return '';

    }

    public function write($Id, $Data)
    {
        $Data = str_replace('"', '\"', $Data );
         $Sql = "INSERT INTO tbl_session (i_Id, t_Content) VALUES(\"" . $Id . "\", \"" . $Data . "\") ON DUPLICATE KEY UPDATE  t_Content =\"" . $Data . "\"";
         $Result = $this->Db->executeQuery($Sql); // low level sql
    }

    public function destroy($Id)
    {
        $Sql = "delete from tbl_session where i_Id =\"" . $Id . "\"";
        $Result = $this->Db->executeQuery($Sql);

        return true;
    }

    public function gc($maxlifetime) // löschen von zeit zu zeit
    {
        $Sql = "delete from tbl_session where d_CreateDate > " . $maxlifetime + time();
        $Result = $this->Db->executeQuery($Sql);

        return true;
    }
}




?>