<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ImageLib
{
    /**
     * schreibt das Base bild zum TempOrdner und gibt den namen zurück
     * @param type $ImageString
     * @return string
     */
    public static function saveBase64Image( $ImageString )
    {
        
        $ImageString = str_replace('data:image/png;base64,', '', $ImageString);
        $ImageString = str_replace(' ', '+', $ImageString);
        $Data = base64_decode($ImageString);
        $Name = "./img/temp/" . md5( $ImageString ) . ".png";
        file_put_contents($Name, $Data);
        
        return $Name;
        
        
        $Data = $ImageString;
        list($type, $Data) = explode(';', $ImageString);
        list(, $Data)      = explode(',', $Data);
        $Data = base64_decode($Data);
        $Name = "./img/temp/" . md5( $ImageString ) . ".png";
        file_put_contents($Name, $Data);
        
        return $Name;
    }
    
    public static function createThumb($img_src, $img_width = "1000", $img_height = "1000", $img_dest = "./Out/img.jpg")
    {

        // Größe und Typ ermitteln
        $Temp = getimagesize( $img_src);
        $src_width = $Temp[0];
        $src_height = $Temp[1];
        $src_typ = $Temp[2];
        
        // neue Größe bestimmen
        if ($src_width >= $src_height)
        {
            $new_image_width = $img_width;
            $new_image_height = $src_height * $img_width / $src_width;
        }
        if ($src_width < $src_height)
        {
            $new_image_height = $img_width;
            $new_image_width = $src_width * $img_height / $src_height;
        }

        $DestinationPath = $img_dest;
        $DestinationPath = str_replace("//", "/", $DestinationPath);

        if ($src_typ == 1)     // GIF
        {
            $image = imagecreatefromgif( $img_src);
            $new_image = imagecreate($new_image_width, $new_image_height);
            imagecopyresampled($new_image, $image, 0, 0, 0, 0, $new_image_width, $new_image_height, $src_width, $src_height);
            imagegif($new_image, $DestinationPath, 100);
            imagedestroy($image);
            imagedestroy($new_image);
            return true;
        } elseif ($src_typ == 2) // JPG
        {
            $image = imagecreatefromjpeg( $img_src);
            $new_image = imagecreatetruecolor($new_image_width, $new_image_height);
            imagecopyresampled($new_image, $image, 0, 0, 0, 0, $new_image_width, $new_image_height, $src_width, $src_height);
            imagejpeg($new_image, $DestinationPath, 100);
            imagedestroy($image);
            imagedestroy($new_image);
            return true;
        } elseif ($src_typ == 3) // PNG
        {
            $image = imagecreatefrompng( $img_src);
            $new_image = imagecreatetruecolor($new_image_width, $new_image_height);
            imagecopyresampled($new_image, $image, 0, 0, 0, 0, $new_image_width, $new_image_height, $src_width, $src_height);
            imagepng($new_image, $DestinationPath);
            imagedestroy($image);
            imagedestroy($new_image);
            return true;
        } else
        {
            return false;
        }
    }
    
    
    
    
    

}
