<?php

/**
 * Class Logger system logger erstellt die log/system.log
 * abstracte logger klasse für v4.
 */
class Logger
{
    protected $LogFile =  "log/Sytem.log";

    protected  $CanLog = true;

	public function __construct()
	{
        $this->CanLog = true;
		if( LIVE_SYSTEM ) $this->CanLog = false;
	}
	
	protected function write( $String, $FileName = null, $Linenummer = 0)
	{
        if(!$this->CanLog) return;
        try{
            @$File = fopen( $this->LogFile ,"a+");
            if(!$File) return;
           @fwrite($File , $datum = date("d.m.Y H:i", time()) . " " . $String . "\nFile: " . $FileName . "  zeile: " . $Linenummer . "\n");
            fclose ($File);
        }  catch(Exception $E) // falls es probleme beim schreiben gibt
        {

        }

	}

    protected function setLogFile( $LogFile)
    {
        $this->LogFile = $LogFile;
    }



    /**
     * schreibt einen logeintrag
     * @param $Message
     */
    public static function log( $Message )
    {

        $Instance = new self();
        if(!$Instance->CanLog) return;
        $bt = debug_backtrace();
        $caller = array_shift($bt); // get debug trace


        if( !is_string( $Message ) ) // wenn kein string dann zum string machen
        {
            $Message = json_encode( $Message );
        }

        $Instance->write($Message, $caller['file'], $caller['line'] );
    }
	
    
    /*public Static function write($String) {
		$File = fopen(SERVERPATH.LOGPATH."System_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}*/
	
	public Static function writeSystemLog($String) {
		$File = fopen( LOGPATH."System_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}

	public Static function writeErrorLog($String) {
		$File = fopen(LOGPATH."Error_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}
	
	public Static function writeOrderLog($String) {
		$File = fopen(LOGPATH."Order_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}
	
	public Static function writeDebugLog($String) {
		$File = fopen( LOGPATH."Debug_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}
	
	public Static function writeTaskLog($String) {
		$File = fopen( LOGPATH."Task_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}
	
	public Static function writeSensorApiLog($String) {
		$File = fopen(LOGPATH."SensorApi_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}
	
	public Static function writeDataManagerLog($String) {
		$File = fopen(LOGPATH."DataManager_".date("Ymd",time()).".log","a+");
		if( $File !== NULL ) {
			//list($usec, $sec) = explode(" ", microtime());
			//fwrite($File,$datum = date("d.m.Y H:i:s",time()).".".substr($usec,2)." ".$String."\n");
			$t = microtime(true);
			$micro = sprintf("%06d",($t - floor($t)) * 1000000);
			$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) );
			fwrite($File,$datum = $d->format("Y-m-d H:i:s.u")." ".$String."\n");
			fclose ($File);
		}
	}
	
	public function getLogFileData( $Path, $Search ) {
		$File = fopen( $Path , "r");
		if( $File !== NULL ) {
			while( !feof($File) ) {
				$line = fgets($File);
				$pics = explode( ";", $line );
				if( $pics[0] == $Search ) {
					return trim($pics[1]);
				}
			}
			return false;
		} else {
			return false;
		}
	}
    
    
    
    
	
}

/**
 * loggt wenn DEBUG_MODE = true oder wenn LOG_SQL = true
 * Class sqlLogger
 */
class SqlLogger extends Logger
{
    protected $LogFile = "log/sql.log";

    public function __construct()
    {
        $this->CanLog = false;
        if( LOG_SQL )
        {
            $this->CanLog = true;
            return;
        }

        if(!DEBUG_MODE && LIVE_SYSTEM)
        {
            $this->CanLog = false;
        }

        if(DEBUG_MODE && !LIVE_SYSTEM)
        {
            $this->CanLog = true;
        }

        $this->LogFile = "log/sql.log";
    }


    public static function log( $Message )
    {

        $Instance = new self();
        if(!$Instance->CanLog) return;
        $bt = debug_backtrace();
        $caller = array_shift($bt); // get debug trace
        $caller = array_shift($bt);

        if( !is_string( $Message ) ) // wenn kein string dann zum string machen
        {
            $Message = json_encode( $Message );
        }

        $Instance->write($Message, $caller['file'], $caller['line'] );
    }







}

/**
 * error logger logt immer
 * Class errorLogger
 */
class ErrorLogger extends Logger
{
    protected $LogFile = "log/error.log";
    public function __construct()
    {

        $this->CanLog = true;
        $this->LogFile = "log/error.log";
    }


    public static function log( $Message )
    {

        $Instance = new self();
        if(!$Instance->CanLog) return;
        $bt = debug_backtrace();
        $caller = array_shift($bt); // get debug trace


        if( !is_string( $Message ) ) // wenn kein string dann zum string machen
        {
            $Message = json_encode( $Message );
        }

        $Instance->write($Message, $caller['file'], $caller['line'] );
    }


}


/**
 * loggt nur wenn DEBUG_MODE = true
 * Class debugLogger
 */
class DebugLogger extends Logger
{
    protected  $LogFile = "log/debug.log";
    public function __construct()
    {

        if(DEBUG_MODE)
        {
            $this->CanLog = true;
        }

        $this->LogFile = "log/debug.log";

    }


    public static function log( $Message )
    {

        $Instance = new self();
        if(!$Instance->CanLog) return;
        $bt = debug_backtrace();
        $caller = array_shift($bt); // get debug trace


        if( !is_string( $Message ) ) // wenn kein string dann zum string machen
        {
            $Message = json_encode( $Message );
        }

        $Instance->write($Message, $caller['file'], $caller['line'] );
    }



}

/**
 * loggt nur wenn DEBUG_MODE = true
 * Class debugLogger
 */
class dbUpdateLogger extends Logger
{
    protected  $LogFile;
    public function __construct()
    {

        if(DEBUG_MODE)
        {
            $this->CanLog = true;
        }

        $this->LogFile = "log/db_update.log";

    }


    public static function log( $Message )
    {

        $Instance = new self();
        $Instance->write( $Message );
    }

	public static function lastMessage(  ) {
		$Instance = new self();
        if (file_exists($Instance->LogFile))
			return filemtime( $Instance->LogFile );
		else return 0;
	}


}


/**
 * loggt nur wenn DEBUG_MODE = true
 * Class debugLogger
 */
class UploaderLogger extends Logger
{
    protected  $LogFile;
    public function __construct()
    {

        if(DEBUG_MODE)
        {
            $this->CanLog = true;
        }

        $this->LogFile = "log/upload.log";

    }
    public static function log( $Message )
    {

        $Instance = new self();
        $Instance->write( $Message );
    }
}

/**
 * loggt nichts
 * Class emptyLogger
 */
class EmptyLogger extends Logger
{
    public function __construct()
    {
        $this->LogFile = "log/debug.log";
    }

    /**
     * leere logger fkt
     * @param $String
     */
    protected function write( $String, $FileName = null, $Linenummer = 0)
    {
        return;
    }


}


class DataManagerLogger extends Logger
{
    protected $LogFile = "log/Datamanager.log";
    public function __construct()
    {
        if(DEBUG_MODE)
        {
            $this->CanLog = true;
        } else 
        {
            $this->CanLog = false;
        }
        
        
        $this->LogFile = "log/Datamanager.log";
    }


    public static function log( $Message )
    {

        $Instance = new self();
        if(!$Instance->CanLog) return;
        $bt = debug_backtrace();
        $caller = array_shift($bt); // get debug trace


        if( !is_string( $Message ) ) // wenn kein string dann zum string machen
        {
            $Message = json_encode( $Message );
        }

        $Instance->write($Message, $caller['file'], $caller['line'] );
    }


}

class DeviceLogger extends Logger
{
    protected $LogFile = "log/DeviceLog.log";
    public function __construct()
    {
        if(DEBUG_MODE)
        {
            $this->CanLog = true;
        } else 
        {
            $this->CanLog = false;
        }
        
        
        $this->LogFile = "log/DeviceLog.log";
    }


    public static function log( $Message )
    {

        $Instance = new self();
        if(!$Instance->CanLog) return;
        $bt = debug_backtrace();
        $caller = array_shift($bt); // get debug trace


        if( !is_string( $Message ) ) // wenn kein string dann zum string machen
        {
            $Message = json_encode( $Message );
        }

        $Instance->write($Message, $caller['file'], $caller['line'] );
    }


}




?>