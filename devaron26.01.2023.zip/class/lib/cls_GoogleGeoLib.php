<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class GoogleGeoLib
{
    
    private Static $ApiKey = GOOGLE_API_KEY;
    private Static $Referer = CURL_GOOGLE_API_REFERER;
    
    public static function getGPS( $Street, $Zip, $Town)
    {
        $Temp = urlencode($Street . " " . $Zip . " " . $Town ) . "&Key=" . self::$ApiKey;
        $String = "http://maps.google.com/maps/api/geocode/json?address=" . $Temp;
        $ch = curl_init(); 
        // set url 

        curl_setopt($ch, CURLOPT_URL, $String); 
        //return the transfer as a string 
        curl_setopt($curl, CURLOPT_REFERER, self::$Referer ); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        // $output contains the output string 
        $Output = curl_exec($ch); 

        // close curl resource to free up system resources 
        curl_close($ch);
        return json_decode( $Output );
    }
    
    
    
}