<?php

class UniversalCollection extends Collection
{

    public function add($Element)
    {
        if (isset($Element))
        {
            $this->Elements[] = $Element;
        }
    }
    
    
    public function addCollection($Collection)
    {
        foreach($Collection as $CollectionElement)
        {
            $this->add($CollectionElement);
        }
    }

    public function getById($Id)
    {
        foreach ($this->Elements as $Element)
        {
            if ($Element->getId() == $Id)
            {
                return $Element;
            }
        }
        return ;
    }

    public function getByIndex($Index)
    {
        if (!isset($this->Elements[$Index]) || $this->countElements() < 0)
        {
            return ;
        }
        return $this->Elements[$Index];
    }

}

?>