<?php

class TextLoader
{
    
    public static function getText($Name)
    {
        $Text = (array)json_decode(file_get_contents("cfg/text.json"));
        return $Text[$Name];
    }
    
}
?>