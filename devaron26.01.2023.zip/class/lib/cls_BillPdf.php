<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class BillPdf extends FPDF {

    protected $DefaultFields;
    protected $Fields;
    protected $StyleColor;
    protected $Positions;

    /**
     * Generates a Bill-PDF from a JSON-file.
     * @param string $JsonUrl Path to JSON-file
     * @return int
     */
    public function __construct($JsonUrl) {
        parent::__construct();

        $JsonString = file_get_contents($JsonUrl);

        if (!Utility::jsonLint($JsonString))
        {
            echo "Ungültiges JSON!";
            return 0;
        }

        $Bill = json_decode($JsonString);
        
        
        
        // import json-information
        $this->Fields = $Bill;

        // set default-style-attributes
        $this->DefaultFontFamily = $Bill->Style->FontFamily;
        $this->DefaultFontSize = $Bill->Style->FontSize;
        $this->DefaultTextColor = Utility::hexToRgbAsArray($Bill->Style->FontColor);
        $this->DefaultStyleColor = Utility::hexToRgbAsArray($Bill->Style->StyleColor);
        $this->DefaultMarginLeft = 25;
        $this->DefaultMarginTop = 60;
        $this->DefaultMarginRight = 25;

        // apply default-style-attributes
        $this->applyDefaultStyle();

        // toggle borders and define line hights
        $this->Borders = 0;
        $this->LineHeightS = 4;
        $this->LineHeightM = 6;
        $this->LineHeightL = 8;
        $this->LineHeightXL = 10;
        $this->LineHeightXXL = 12;

        // create shortcuts for printing seller-information
        $this->SellerContact = $Bill->Seller->Contact;
        $this->SellerBank = $Bill->Seller->Bank;
        $this->SellerTaxOffice = $Bill->Seller->TaxOffice;

        // for printing the €-sign
        define('EURO', chr(128));

        // initialize positions-counter and sum-variables
        $this->PositionsTotal = count($Bill->Positions);
        $this->PositionIndex = 0;
        $this->SumNet = 0;
        $this->SumTax7 = 0;
        $this->SumTax19 = 0;
        $this->SumGross = 0;

        // set author, creator and ttile
        $this->SetAuthor($Bill->SellerContact->FirstName . " " . $Bill->SellerContact->LastName);
        $this->SetCreator($Bill->SellerContact->FirstName . " " . $Bill->SellerContact->LastName);
        $this->SetTitle("Rechnung " . $Bill->BillNumber);

        // set auto-page-break and add the first page
        $this->SetAutoPageBreak(true, 40);
        $this->AddPage();
    }

    /**
     * This is a fpdf-callback-function.
     * Prints background-image OR logo and seller-information on every site.
     * @return bool
     */
    public function Header() {
        if ($this->Fields->Style->BackgroundPath) {
            $this->printBackground();
            $this->Ln(0);
            return true;
        } else {
            $this->printLogo();
            $this->printSellerContactHeader();
        }
    }

    /**
     * Prints the background-image
     */
    public function printBackground() {
        $this->Image($this->Fields->Style->BackgroundPath, 0, 0, 210, 0);
    }

    /**
     * Prints the logo if provided.
     */
    private function printLogo($align = "left", $printedHeight = 30) {
        if ($this->Fields->Style->LogoPath) {
            // get image dimensions in px
            $imageWidth = getimagesize($this->Fields->Style->LogoPath)[0];
            $imageHeight = getimagesize($this->Fields->Style->LogoPath)[1];

            // set printedHeight and calculate the printedWidth for centering
            $printedWidth = $printedHeight / ($imageHeight / $imageWidth);

            $align = $this->Fields->Style->LogoAlign;
            
            // place image
            switch ($align) {
                case "left":
                    $this->Image($this->Fields->Style->LogoPath, $this->DefaultMarginLeft - 10, 5, 0, $printedHeight);
                    break;
                case "center":
                    $this->Image($this->Fields->Style->LogoPath, $this->w / 2 - $printedWidth / 2, 5, 0, $printedHeight);
                    break;
                case "right":
                    $this->Image($this->Fields->Style->LogoPath, $this->DefaultMarginRight + 10, 5, 0, $printedHeight);
                    break;
            }
        }
    }

    /**
     * Prints seller-information for the header.
     */
    public function printSellerContactHeader() {
        $this->openContainer();

        $this->SetMargins(25, 0, 0);
        $this->x = 0;
        $this->y = 41;

        $this->SetFontSize($this->Fields->Style->FontSize - 1);
        $this->SetTextColor(255, 255, 255);
        $this->SetFillColor($this->DefaultStyleColor["r"], $this->DefaultStyleColor["g"], $this->DefaultStyleColor["b"]);

        $this->Cell(0, 8, utf8_decode(
                        $this->SellerContact->CompanyName . ", " .
                        " Inh. " . $this->SellerContact->FirstName . " " . $this->SellerContact->LastName . ", " .
                        $this->SellerContact->Street . " " . $this->SellerContact->HouseNumber . ", " .
                        $this->SellerContact->ZIP . " " . $this->SellerContact->City
                ), 0, 1, "C", 1);
        $this->Ln(11);


        $this->closeContainer();
    }

    /**
     * Prints the buyer-info (Company, Name, Address)
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printBuyerInfo($top = null, $x = null, $y = null) {
        $this->openContainer($top, $x, $y);

        $this->MultiCell(70, $this->LineHeightS, utf8_decode(
                        $this->Fields->Buyer->CompanyName . "\n" .
                        $this->Fields->Buyer->FirstName . " " . $this->Fields->Buyer->LastName . "\n" .
                        $this->Fields->Buyer->Street . " " . $this->Fields->Buyer->HouseNumber . "\n" .
                        $this->Fields->Buyer->ZIP . " " . $this->Fields->Buyer->City
                ), $this->Borders);

        $this->closeContainer();
    }

    /**
     * Prints the bill-info (bill-number, bill-date, performance-date)
     * @Warning: Does currently not work without parameters!
     * @param int $top Space left before this container in mm
     * @param int $width width of this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printBillInfo($top = null, $width = null, $x = null, $y = null) {
        $this->openContainer($top, $x, $y);

        $this->MultiCell($width, $this->LineHeightS, utf8_decode(
                        "Rechnungsnummer:\n" .
                        "Rechnungsdatum:\n" .
                        "Leistungsdatum:"
                ), $this->Borders);

        $this->openContainer($top, $x + $width, $y);

        $this->MultiCell(0, $this->LineHeightS, utf8_decode(
                        $this->Fields->BillNumber . "\n" .
                        $this->Fields->BillDate . "\n" .
                        $this->Fields->PerformanceDate
                ), $this->Borders, "R");

        $this->closeContainer();
    }

    /**
     * Prints City and current Date.
     * @param int $top Space left before this container in mm
     */
    public function printCityAndDate($top = null) {
        $this->openContainer($top);


        $this->Cell(0, 8, $this->SellerContact->City . ",  " . date("d.m.Y"), 0, 1, "R");

        $this->closeContainer();
    }

    /**
     * Prints the subject (bill-number), bold and as a headline
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printSubject($top = null, $x = null, $y = null) {
        $this->openContainer($top, $x, $y);

        $this->SetFont("", "B", $this->DefaultFontSize + 5);
        $this->MultiCell(0, $this->LineHeightS, utf8_decode(
                        "Rechnung Nr.: " . $this->Fields->BillNumber
                ), $this->Borders);

        $this->closeContainer();
    }

    /**
     * Prints the salutation
     * @param int $top Space left before this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printSalutation($top = null, $x = null, $y = null) {
        $this->openContainer($top, $x, $y);

        if ($this->Fields->Buyer->Salutation == "Herr") {
            $this->MultiCell(0, $this->LineHeightM, utf8_decode(
                            "Sehr geehrter " . $this->Fields->Buyer->Salutation . " " . $this->Fields->Buyer->LastName) . ",");
        } else if ($this->Fields->Buyer->Salutation == "Frau") {
            $this->MultiCell(0, $this->LineHeightM, utf8_decode(
                            "Sehr geehrte " . $this->Fields->Buyer->Salutation . " " . $this->Fields->Buyer->LastName) . ",");
        } else {
            $this->MultiCell(0, $this->LineHeightM, utf8_decode(
                            "Sehr geehrte Damen und Herren,"));
        }

        $this->closeContainer();
    }

    /**
     * Prints a text.
     * @param int $i Index of the text.
     * @param int $top Space left before this container in mm
     * @param int $width Width of this container in mm
     * @param int $x x-Position of this container in mm (absolute)
     * @param int $y y-Position of this container in mm (absolute)
     */
    public function printText($i = null, $top = null, $width = null, $x = null, $y = null) {
        $this->openContainer($top, $x, $y);

        $this->Fields->Text[$i] = str_replace("€", "EUR", $this->Fields->Text[$i]);
        $this->MultiCell($width, $this->LineHeightM, utf8_decode($this->Fields->Text[$i]), $this->Borders, "L");

        $this->closeContainer();
    }

    /**
     * Prints the bill-positions.
     * Includes: 
     * Printing table-headers, 
     * Printing each position on a new line,
     * Automatic page-breaks,
     * Printing subtotals at the end of each page,
     * Printing totals at the end of the table
     */
    public function printPositions() {
        $this->openContainer();

        // adjust container-style
        $this->SetLineWidth(.3);
        $this->SetFillColor(240, 240, 240);
        $fill = 0;

        $tableWidths = [10, 85, 15, 15, 20, 20];

        // print position header
        $this->printPositionsHeader($tableWidths, 10);

        // print data for every position 
        foreach ($this->Fields->Positions as $row) {

            $this->PositionIndex++;


            if ($this->GetStringWidth($row->Label) / $tableWidths[1] < 1) {
                $labelCellHeight = $this->LineHeightXXL;
                $this->Cell($tableWidths[0], $labelCellHeight, $this->PositionIndex, 'T', 0, 'C', $fill);
                $this->Cell($tableWidths[1], $labelCellHeight, utf8_decode($row->Label), 'T', 0, "L", $fill);
            } else {
                $labelCellHeight = $this->GetMultiCellHeight($tableWidths[1], $this->LineHeightM, $row->Label, 0, "L");

                $this->Cell($tableWidths[0], $labelCellHeight, $this->PositionIndex, 'T', 0, 'C', $fill);

                $tempX = $this->x;
                $tempY = $this->y;
                $this->MultiCell($tableWidths[1], $this->LineHeightM, utf8_decode($row->Label), "T", "L");
                $this->x = $tempX + $tableWidths[1];
                $this->y = $tempY;
            }


            $this->Cell($tableWidths[2], $labelCellHeight, $row->Tax . "%", 'T', 0, 'C', $fill);
            $this->Cell($tableWidths[3], $labelCellHeight, utf8_decode(number_format($row->Quantity, 1, ",", ".") . " " . $row->Unit), 'T', 0, 'C', $fill);
            $this->Cell($tableWidths[4], $labelCellHeight, number_format($row->UnitPrice, 2, ",", ".") . " " . EURO, 'T', 0, 'R', $fill);
            $this->Cell($tableWidths[5], $labelCellHeight, number_format($row->SumNet, 2, ",", ".") . " " . EURO, 'T', 0, 'R', $fill);
            $this->Ln();

            $this->addToSums($row);
            $fill = !$fill;
            $this->handlePageBreak($tableWidths);
        }

        $this->closeContainer();
    }

    /**
     * Prints header for the bill-positions.
     * @param array $tableWidths Widths of the individual columns.
     * @param int $top Space left before this container in mm
     */
    public function printPositionsHeader($tableWidths, $top = null) {
        $this->openContainer($top);

        //    $this->SetFont("", "B");

        $tableHeader = ["#", "Artikel/Leistung", "USt", "Menge", "Einzel", "Gesamt"];
        $tableAlign = ["C", "C", "C", "C", "R", "R"];
        for ($i = 0; $i < count($tableHeader); $i++) {
            $this->Cell($tableWidths[$i], 7, $tableHeader[$i], 'TB', 0, $tableAlign[$i], 1);
        }
        $this->Ln();

        $this->closeContainer();
    }

    /**
     * Handles the page break when printing positions.
     * Prints sums and table-header.
     * @param array $tableWidths Widths of the individual columns.
     */
    private function handlePageBreak($tableWidths) {
        // print sums before page-end and table-header after page-add 
        // (but not if the last element is reached anyways)
        if ($this->y > $this->h - 110 && $this->PositionIndex != $this->PositionsTotal) {
            $this->printSums($tableWidths, "Zwischensumme");
            $this->AddPage();
            $this->printPositionsHeader($tableWidths, 10);
        } else if ($this->PositionIndex == $this->PositionsTotal) {
            if ($this->y > $this->h / 2) {
                $this->printSums($tableWidths, "Zwischensumme");
                $this->AddPage();
                $this->Ln(20);
            }
            $this->printSums($tableWidths, "Rechnungsbetrag");
        }
    }

    /**
     * Builds sums over the bill-data.
     * @param array $row Data of the current bill-position.
     */
    private function addToSums($row) {
        $this->SumNet = $this->SumNet + $row->SumNet;

        switch ($row->Tax) {
            case 0:
                $this->SumGross = $this->SumGross + $row->SumNet;
                break;
            case 7:
                $this->SumTax7 = $this->SumTax7 + $row->SumNet * 0.07;
                $this->SumGross = $this->SumGross + $row->SumNet * 1.07;
                break;
            case 19:
                $this->SumTax19 = $this->SumTax19 + $row->SumNet * 0.19;
                $this->SumGross = $this->SumGross + $row->SumNet * 1.19;
                break;
        }
    }

    /**
     * Prints the bill-sums.
     * @param array $tableWidths Widths of the individual columns.
     * @param string $sumLabel Label for the sum (e.g. "Zwischensumme", "Rechnungsbetrag")
     */
    private function printSums($tableWidths, $sumLabel) {
        $width = array_sum($tableWidths) - $tableWidths[5];

        $this->SetLineWidth(.5);
        $this->Cell($width, $this->LineHeightL, $sumLabel . " Netto:", "T", 0, "R");
        $this->Cell($tableWidths[5], $this->LineHeightL, number_format($this->SumNet, 2, ",", ".") . " " . EURO, "T", 1, "R");

        $this->SetLineWidth(.3);
        if ($this->SumTax7) {
            $this->Cell($width, $this->LineHeightL, "MwSt. 7%:", "T", 0, "R");
            $this->Cell($tableWidths[5], $this->LineHeightL, number_format($this->SumTax7, 2, ",", ".") . " " . EURO, "T", 1, "R");
        }
        $this->Cell($width, $this->LineHeightL, "MwSt. 19%:", "T", 0, "R");
        $this->Cell($tableWidths[5], $this->LineHeightL, number_format($this->SumTax19, 2, ",", ".") . " " . EURO, "T", 1, "R");
        $this->SetFont("", "B");
        $this->Cell($width, $this->LineHeightL, $sumLabel . " Brutto:", "T", 0, "R");
        $this->Cell($tableWidths[5], $this->LineHeightL, number_format($this->SumGross, 2, ",", ".") . " " . EURO, "T", 1, "R");
        $this->SetFont("");
    }

    /**
     * Prints signature-container ("Besten Dank. Mit freundlichen Grüßen. [LEERZEILEN] Vorname Nachname")
     * @param int $top Space left before this container in mm
     */
    public function printSignature($top = null) {
        $this->openContainer($top);

        if ($this->y > $this->h - 80) {
            $this->AddPage();
        }
        $this->Cell(0, 8, utf8_decode("Besten Dank."), 0, 1);
        $this->Cell(0, 8, utf8_decode("Mit freundlichen Grüßen"), 0, 1);
        $this->Ln(15);
        $this->Cell(0, 8, $this->SellerContact->FirstName . " " . $this->SellerContact->LastName);

        $this->closeContainer();
    }

    /**
     * This is a fpdf-callback-function.
     * Prints page-number and - if no background-image is provided - seller- and tax-office-information on every site.
     * @return bool
     */
    public function Footer() {
        if ($this->Fields->Style->BackgroundPath) {
            $this->printPageNumber();
            return true;
        } else {
            $this->printPageNumber();
            $this->printSellerContactFooter();
            $this->printSellerBankAndTaxOffice();
        }
    }

    /**
     * Prints the current page-number.
     */
    private function printPageNumber() {
        $this->openContainer();

        $this->y = $this->h - 35;
        $this->Cell(0, 8, "Seite " . $this->PageNo(), 0, 1, "C");

        $this->closeContainer();
    }

    /**
     * Prints seller-information for the footer.
     */
    public function printSellerContactFooter() {
        $this->openContainer();

        $this->SetMargins(25, 0, 0);
        $this->x = 0;
        $this->y = $this->h - 24;

        $this->SetFontSize($this->Fields->Style->FontSize - 1);
        $this->SetTextColor(255, 255, 255);
        $this->SetFillColor($this->DefaultStyleColor["r"], $this->DefaultStyleColor["g"], $this->DefaultStyleColor["b"]);

        if ($this->SellerContact->Website) {
            $this->Cell(0, 8, utf8_decode(
                            $this->SellerContact->Phone . " | " .
                            $this->SellerContact->Mail . " | " .
                            $this->SellerContact->Website
                    ), 0, 1, "C", 1);
        } else {
            $this->Cell(0, 8, utf8_decode(
                            $this->SellerContact->Phone . " | " .
                            $this->SellerContact->Mail
                    ), 0, 1, "C", 1);
        }
        $this->closeContainer();
    }

    /**
     * Prints tax-offce-info for the footer.
     */
    public function printSellerBankAndTaxOffice() {
        $this->openContainer();

        $this->Ln(1);
        $this->SetFontSize($this->Fields->Style->FontSize - 1);
        $this->Cell(0, 8, utf8_decode(
                        "Bank: " . $this->SellerBank->Name . ", " .
                        "IBAN: " . $this->SellerBank->IBAN . ", " .
                        "Steuernummer: " . $this->SellerTaxOffice->TaxNumber
                ), 0, 1, "C", 1);

        $this->closeContainer();
    }

    /**
     * Sets style attributes to default values.
     * Sets the x- and y-property for the container.
     * @param int $top Space left before this container in mm
     * @param int $x x-position in mm (absolute)
     * @param int $y y-position in mm (absolute)
     */
    private function openContainer($top = null, $x = null, $y = null) {
        $this->applyDefaultStyle();

        if ($top !== null) {
            $this->Ln($top);
        }
        if ($x !== null) {
            $this->x = $x;
        }
        if ($y !== null) {
            $this->y = $y;
        }
    }

    /**
     * Does a CRLF (line-size: 0).
     * Sets style attributes to default values.
     */
    private function closeContainer() {
        $this->Ln(0);
        $this->applyDefaultStyle();
    }

    /**
     * Sets these attributes back to its default values: 
     * FontFamily, 
     * FontStyle, 
     * FontSize, 
     * TextColor,
     * DrawColor, 
     * FillColor, 
     * Margins (left, top, right)
     */
    private function applyDefaultStyle() {
        $this->SetFont($this->DefaultFontFamily, "", $this->DefaultFontSize);
        $this->SetTextColor($this->DefaultTextColor["r"], $this->DefaultTextColor["g"], $this->DefaultTextColor["b"]);

        $this->SetDrawColor($this->DefaultStyleColor["r"] - 50, $this->DefaultStyleColor["g"] - 50, $this->DefaultStyleColor["b"] - 50);
        $this->SetFillColor(255, 255, 255);

        $this->SetMargins($this->DefaultMarginLeft, $this->DefaultMarginTop, $this->DefaultMarginRight);
    }

    /**
     * 
     * @param type $w
     * @param type $h
     * @param type $txt
     * @param type $border
     * @param type $align
     * @return type
     */
    function GetMultiCellHeight($w, $h, $txt, $border = null, $align = 'J') {
        // Calculate MultiCell with automatic or explicit line breaks height
        // $border is un-used, but I kept it in the parameters to keep the call
        //   to this function consistent with MultiCell()
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0)
            $w = $this->w - $this->rMargin - $this->x;
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb - 1] == "\n")
            $nb--;
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $ns = 0;
        $height = 0;
        while ($i < $nb) {
            // Get next character
            $c = $s[$i];
            if ($c == "\n") {
                // Explicit line break
                if ($this->ws > 0) {
                    $this->ws = 0;
                    $this->_out('0 Tw');
                }
                //Increase Height
                $height += $h;
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $ns = 0;
                continue;
            }
            if ($c == ' ') {
                $sep = $i;
                $ls = $l;
                $ns++;
            }
            $l += $cw[$c];
            if ($l > $wmax) {
                // Automatic line break
                if ($sep == -1) {
                    if ($i == $j)
                        $i++;
                    if ($this->ws > 0) {
                        $this->ws = 0;
                        $this->_out('0 Tw');
                    }
                    //Increase Height
                    $height += $h;
                } else {
                    if ($align == 'J') {
                        $this->ws = ($ns > 1) ? ($wmax - $ls) / 1000 * $this->FontSize / ($ns - 1) : 0;
                        $this->_out(sprintf('%.3F Tw', $this->ws * $this->k));
                    }
                    //Increase Height
                    $height += $h;
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $ns = 0;
            } else
                $i++;
        }
        // Last chunk
        if ($this->ws > 0) {
            $this->ws = 0;
            $this->_out('0 Tw');
        }
        //Increase Height
        $height += $h;

        return $height;
    }

}
