<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Cache
{

    protected static $LifeTime = 90; // tage

    public function __construct()
    {
        
    }

    public function get($Key)
    {
        if ( !$Key )
            return false;
        $Timestamp = filemtime($Key) + ( self::$LifeTime * 86400 );
        if ( $Timestamp > mktime() ) // wenn älter als 90 tage dann weg
        {
            unlink($Key);
            return false;
        }
        return readfile($Key);
    }

    public function set($Key, $Data)
    {
        if(DEBUG_MODE) return false;
        if ( !$Key )
            return false;
        $Dir = dir($Key);
        if ( !mkdir($Dir, 0777, true) )
        {
            Logger::log("Cache Warning Cant Create Cache dir: " . $Key);
            //die('Erstellung der Verzeichnisse schlug fehl...');
        }
        return file_put_contents($Key, $Data);
    }

    public function clear($dir = "cache")
    {
        if ( is_dir($dir) )
        {
            $objects = scandir($dir);
            foreach ( $objects as $object )
            {
                if ( $object != "." && $object != ".." )
                {
                    if ( filetype($dir . "/" . $object) == "dir" )
                        $this->clear($dir . "/" . $object);
                    else
                        unlink($dir . "/" . $object);
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }

}



class EmptyCache extends Cache
{
    
    public  function get($Key)
    {
            return false;
    }

    public  function set($Key, $Data)
    {
        return false;
    }
    
}