<?php

class Utility
{

    /**
     * convertiert einen String zu einem Hex Color code 
     * @param string $str
     * @return string #00000
     */
    public static function stringToColorCode( $String ) 
    {
        $Code = dechex(crc32($String));
        $Code = "#" . substr($Code, 0, 6);
        return $Code;
    }
    
    
     public static  function floatvalue($val){
            $val = str_replace(",",".",$val);
            $val = preg_replace('/\.(?=.*\.)/', '', $val);
            return floatval($val);
    }
    
    public static function getPassword( $length = 8)
    {
        $password ="";
        $pool  = "qwertzupasdfghkyxcvbnm";
        $pool .= "WERTZUPLKJHGFDSAYXCVBNM";
        $pool .= "23456789";
        srand ( (double)microtime()*1000000 );
        for ( $index = 0; $index < $length; $index++ ) 
        { // Hier die länge des Passwortes eintragen
            $password .= substr( $pool,( rand() % ( strlen ($pool) ) ), 1 );
        }
        return $password;
    }
    
    
    /** ------------------------------------------------------------------------------------------------------
     * 	
     */
    public static function getBaseUrl()
    {
        $Protocol = stripos($_SERVER['SERVER_PROTOCOL'], 'https') === true ? 'https://' : 'http://';
        return $Protocol . $_SERVER['HTTP_HOST'];
    }

    /** ------------------------------------------------------------------------------------------------------
     * 	created by kps, 04.05.13
     * 	xml to array. Die Funkt. aus Typo3
     */
    public static function xml2array($string, $NSprefix = '', $reportDocTag = FALSE)
    {

        // Create parser:
        $parser = xml_parser_create();
        $vals = array();
        $index = array();
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 0);
        // Default output charset is UTF-8, only ASCII, ISO-8859-1 and UTF-8 are supported!!!
        $match = array();
        if (preg_match('/^[[:space:]]*<\\?xml[^>]*encoding[[:space:]]*=[[:space:]]*"([^"]*)"/', substr($string, 0, 200), $match))
        {
            $theCharset = !empty($match[1]) ? $match[1] : 'utf-8';
        } else
            $theCharset = 'utf-8';

        // us-ascii / utf-8 / iso-8859-1
        xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, $theCharset);
        // Parse content:
        // save false attributes names 
        $attr_renamed = array();
        if (preg_match_all('/<(\d+[^>]+?)/isU', $string, $match))
        {
            if (count($match[0]) > 0)
            {
                for ($i = 0; $i < count($match[0]); $i++)
                {
                    $key = 'saved_attr_' . strlen($match[1][$i]) . '_' . $match[1][$i];
                    $attr_renamed[$key] = $match[1][$i];
                    $string = str_replace($match[1][$i], $key, $string);
                }
            }
        }
        // parse:
        xml_parse_into_struct($parser, $string, $vals, $index);
        // If error, return error message:
        if (xml_get_error_code($parser))
        {
            return 'Line ' . xml_get_current_line_number($parser) . ': ' . xml_error_string(xml_get_error_code($parser));
        }
        xml_parser_free($parser);
        // Init vars:
        $stack = array(array());
        $stacktop = 0;
        $current = array();
        $tagName = '';
        $documentTag = '';
        // Traverse the parsed XML structure:
        foreach ($vals as $key => $val)
        {
            // if attributes name was renamed, set it back
            if (isset($attr_renamed[$val['tag']]))
                $val['tag'] = $attr_renamed[$val['tag']];
            // First, process the tag-name (which is used in both cases, whether "complete" or "close")
            $tagName = $val['tag'];
            if (!$documentTag)
            {
                $documentTag = $tagName;
            }
            // Test for name space:
            $tagName = $NSprefix && substr($tagName, 0, strlen($NSprefix)) == $NSprefix ? substr($tagName, strlen($NSprefix)) : $tagName;
            // Test for numeric tag, encoded on the form "nXXX":
            $testNtag = substr($tagName, 1);
            // Closing tag.
            $tagName = substr($tagName, 0, 1) == 'n' && !strcmp(intval($testNtag), $testNtag) ? intval($testNtag) : $tagName;
            // Test for alternative index value:
            if (array_key_exists('attributes', $val))
            {
                if (array_key_exists('index', $val['attributes']))
                    if (strlen($val['attributes']['index']))
                    {
                        $tagName = $val['attributes']['index'];
                    }
            }
            // Setting tag-values, manage stack:
            switch ($val['type'])
            {
                case 'open':
                    // If open tag it means there is an array stored in sub-elements. Therefore increase the stackpointer and reset the accumulation array:
                    // Setting blank place holder
                    $current[$tagName] = array();
                    $stack[$stacktop++] = $current;
                    $current = array();
                    break;
                case 'close':
                    // If the tag is "close" then it is an array which is closing and we decrease the stack pointer.
                    $oldCurrent = $current;
                    $current = $stack[--$stacktop];
                    // Going to the end of array to get placeholder key, key($current), and fill in array next:
                    end($current);
                    $current[key($current)] = $oldCurrent;
                    unset($oldCurrent);
                    break;
                case 'complete':
                    // If "complete", then it's a value. If the attribute "base64" is set, then decode the value, otherwise just set it.
                    if (!empty($val['attributes']['base64']))
                    {
                        $current[$tagName] = base64_decode($val['value']);
                    } else
                    {
                        // Had to cast it as a string - otherwise it would be evaluate FALSE if tested with isset()!!
                        $current[$tagName] = (string) $val['value'];
                        // Cast type:
                        $type = !empty($val['attributes']['type']) ? (string) $val['attributes']['type'] : 'string';
                        switch ($type)
                        {
                            case 'integer':
                                $current[$tagName] = (int) $current[$tagName];
                                break;
                            case 'double':
                                $current[$tagName] = (double) $current[$tagName];
                                break;
                            case 'boolean':
                                $current[$tagName] = (bool) $current[$tagName];
                                break;
                            case 'array':
                                // MUST be an empty array since it is processed as a value; Empty arrays would end up here because they would have no tags inside...
                                $current[$tagName] = array();
                                break;
                        }
                    }
                    break;
            }
        }
        if ($reportDocTag)
        {
            $current[$tagName]['_DOCUMENT_TAG'] = $documentTag;
        }
        // Finally return the content of the document tag.
        return $current[$tagName];
    }

    /** ------------------------------------------------------------------------------------------------------
     * 	created by kps, ??.??.?? 
     * 	array to xml
     */
    public static function array2xml($array, $sub = 0)
    {

        $xml = '';
        if (!is_array($array))
            return false;
        foreach ($array as $k => $v)
        {

            $xml .= str_repeat("\t", $sub + 1) . '<';
            if (is_numeric($k))
            {
                $tagName = 'numIndex';
                $xml .= $tagName . ' index="' . $k . '"';
            } else
            {
                //check spec. sybmols
                if (preg_match('#^[A-z0-9_-]+$#is', $k))
                {
                    $xml .= $tagName = $k;
                } else
                {
                    $tagName = 'node';
                    $xml .= $tagName . ' index="' . addslashes($k) . '"';
                }
            }

            if (is_array($v))
                $xml .= ' type="array">' . "\n" . self::array2xml($v, $sub + 1) . str_repeat("\t", $sub + 1);
            else
                $xml .= '>' . htmlspecialchars(trim($v));
            $xml .= '</' . $tagName . '>' . "\n";
        }
        if (!$sub)
            $xml = '<array>' . "\n" . $xml . '</array>' . "\n";
        return $xml;
    }

    /** ------------------------------------------------------------------------------------------------------
     * 	include und parsed json from file
     * 	array to xml
     */
    public static function includeJSON($filename, $as_array = 0)
    {
        if (!file_exists($filename))
            return false;

        $json = json_decode(file_get_contents($filename), $as_array);

        return $json;
    }

    /**
     * parset urls aus dem text und wandelt diese in links um
     * @param $Text
     * @return mixed
     */
    public static function parseLinks($Text)
    {
        $Text = preg_replace("/(^|[\n ])([\w]*?)([\w]*?:\/\/[\w]+[^ \,\"\n\r\t<]*)/is", "$1$2<a target=\"_blank\" class=\"Link\" href=\"$3\" >$3</a>", $Text);
        $Text = preg_replace("/(^|[\n ])([\w]*?)((www)\.[^ \,\"\t\n\r<]*)/is", "$1$2<a target=\"_blank\" class=\"Link\" href=\"http://$3\" >$3</a>", $Text);
        $Text = preg_replace("/(^|[\n ])([\w]*?)((ftp)\.[^ \,\"\t\n\r<]*)/is", "$1$2<a target=\"_blank\" class=\"Link\" href=\"ftp://$3\" >$3</a>", $Text);
        $Text = preg_replace("/(^|[\n ])([a-z0-9&\-_\.]+?)@([\w\-]+\.([\w\-\.]+)+)/i", "$1<a target=\"_blank\" class=\"Link\" href=\"mailto:$2@$3\">$2@$3</a>", $Text);
        return $Text;
    }


    /**
     * macht alle zeichen für eine datei oder ordner die nicht zulässig sind raus
     * @param type $Text
     * @return type
     */
    public static function sanitizName($FileOrFolderName)
    {
        $FileOrFolderName = str_replace( "/", "-", $FileOrFolderName );
        $FileOrFolderName = str_replace( "ß", "ss", $FileOrFolderName ); // ß weg machen
        
        //preg_match_all('/[a-zA-Z0-9 \-]*/', $FileOrFolderName, $Matches);

       
        //$FileOrFolderName = implode( "", $Matches[0] );
        
        $FileOrFolderName = preg_replace(
        '~
        [<>:"/\\|?*]|            # file system reserved https://en.wikipedia.org/wiki/Filename#Reserved_characters_and_words
        [\x00-\x1F]|             # control characters http://msdn.microsoft.com/en-us/library/windows/desktop/aa365247%28v=vs.85%29.aspx
        [\x7F\xA0\xAD]|          # non-printing characters DEL, NO-BREAK SPACE, SOFT HYPHEN
        [#\[\]@!$&\'()+,;=]|     # URI reserved https://tools.ietf.org/html/rfc3986#section-2.2
        [{}^\~`]                 # URL unsafe characters https://www.ietf.org/rfc/rfc1738.txt
        ~x',
        '-', $FileOrFolderName);
        $FileOrFolderName = str_replace(".","", $FileOrFolderName );
        $FileOrFolderName = trim( $FileOrFolderName );
        $FileOrFolderName = preg_replace('/[\x00-\x1F\x7F-\xFF]/', '', $FileOrFolderName);// nur n och asci zulassen
        return $FileOrFolderName;
    }
    
    
    /**
     * parsed neue zeilen aus dem text
     * @param $Text
     *
     * @return mixed
     */
    public static function parseNewLines($Text)
    {
        $Text = str_replace("\n", "<br />", $Text);
        return $Text;
    }

    /** ------------------------------------------------------------------------------------------------------
     * stellt eindeutige id bereit, nutzt unique()
     * @return mixed
     */
    public static function getHash()
    {
        return substr(uniqid(), 0, 10);
    }

    /**
     * Lädt eine datei die Komma separiert ist und gibt diese als array zurück
     * Die erste spalte wird der index des Arrays
     * @param String $FilePath
     * @param String $Separator
     * @return array
     */
    public static function parseFile($FilePath, $Separator = ',')
    {
        $txt_file = file_get_contents($FilePath);
        $Rows = explode("\n", $txt_file);

        $Temp = array();
        foreach ($Rows as $Key => $Data)
        {
            //get row data
            $RowData = explode($Separator, $Data);
            $Temp[$RowData[0]] = $RowData;
        }
        return $Temp;
    }

    public static function  hex2rgb($Hex) 
    {
        $color = str_replace('#','',$Hex);
        $rgb = array('r' => hexdec(substr($color,0,2)),
                     'g' => hexdec(substr($color,2,2)),
                     'b' => hexdec(substr($color,4,2)));
        return $rgb;
      }
    
    public static function rgb2cmyk($r, $g, $b) 
    {
        $c = (255 - $r) / 255.0 * 100;
        $m = (255 - $g) / 255.0 * 100;
        $y = (255 - $b) / 255.0 * 100;
        $b = min(array($c,$m,$y));
        $c = $c - $b; 
        $m = $m - $b; 
        $y = $y - $b;
        
        $cmyk = array( 'c' => $c, 'm' => $m, 'y' => $y, 'k' => $b);
        return $cmyk;
  }
      
      
      
    /**
     * Verarbeitet Farbangaben der Form "#123" oder "#123456".
     * @param string $hex Hex-String
     * @return array [string r, string g, string b, string rgb]
     */
    public static function hexToRgbAsArray($hex)
    {
        $Return = array(r => "", g => "", b => "", rgb => "");
        $hex = str_replace("#", "", $hex);

        switch (strlen($hex))
        {
            case 3:
                $hexSplit = str_split($hex);
                $Return["r"] = hexdec($hexSplit[0] . $hexSplit[0]);
                $Return["g"] = hexdec($hexSplit[1] . $hexSplit[1]);
                $Return["b"] = hexdec($hexSplit[2] . $hexSplit[2]);
                $Return["rgb"] = $Return["r"] . "," . $Return["g"] . "," . $Return["b"];
                break;

            case 6:
                $hexSplit = str_split($hex, 2);
                $Return["r"] = hexdec($hexSplit[0]);
                $Return["g"] = hexdec($hexSplit[1]);
                $Return["b"] = hexdec($hexSplit[2]);
                $Return["rgb"] = $Return["r"] . "," . $Return["g"] . "," . $Return["b"];
                break;

            default:
                $Return = "Error: Invalid color format!";
                break;
        }

        return $Return;
    }

    /**
     * Prüft, ob ein String gültiges JSON enthält.
     * @param string $jsonString JSON-String
     * @return bool
     */
    public static function jsonLint($jsonString)
    {
        json_decode($jsonString);
        if ((json_last_error() == JSON_ERROR_NONE))
        {
            return 1;
        } else
        {
            echo self::getJsonError(json_last_error());
            var_dump($jsonString);
            return false;
        }
    }

    public static function getJsonError($JsonCode)
    {
        switch ($JsonCode)
        {
            case JSON_ERROR_NONE:
                return ' - Keine Fehler';
                break;
            case JSON_ERROR_DEPTH:
                return ' - Maximale Stacktiefe überschritten';
                break;
            case JSON_ERROR_STATE_MISMATCH:
                return ' - Unterlauf oder Nichtübereinstimmung der Modi';
                break;
            case JSON_ERROR_CTRL_CHAR:
                return ' - Unerwartetes Steuerzeichen gefunden';
                break;
            case JSON_ERROR_SYNTAX:
                return ' - Syntaxfehler, ungültiges JSON';
                break;
            case JSON_ERROR_UTF8:
                return ' - Missgestaltete UTF-8 Zeichen, möglicherweise fehlerhaft kodiert';
                break;
            default:
                return ' - Unbekannter Fehler';
                break;
        }
    }
    
    
    /**
     * macht den Pfad sicher und entfernt alle Bösen zeichen aus dem String
     * @param type $Path
     */
    public static function makePathSave( $Path )
    {
        $Path = str_replace("%", "-", $Path );
        $Path = str_replace("&", "-", $Path );
        $Path = str_replace("§", "-", $Path );
        $Path = str_replace("(", "", $Path );
        $Path = str_replace(")", "", $Path );
        $Path = str_replace("=", "", $Path );
        $Path = str_replace("²", "", $Path );
        $Path = str_replace("³", "", $Path );
        $Path = str_replace("³", "", $Path );
        return $Path;
    }
    
    
    public static function getMonthName( $Index, $Lang = "Ger" )
    {
        
        $MonthArray = array("Januar", "Februar", "März", "April" , "Mai" , "Juni", "Juli", "August" , "September" , "Oktober" , "November" , "Dezember");
       
        return $MonthArray[$Index];
    }
    
    
    
    
    
    public static function scanAllDir($dir) 
    {
        $result = [];
        foreach(scandir($dir) as $filename) 
        {
            if ( $filename[0] === '.' ) continue;
                $filePath = $dir . '/' . $filename;
            if ( is_dir( $filePath ) ) 
            {
                foreach ( Utility::scanAllDir( $filePath ) as $childFilename ) 
                {
                    $result[] = $filename . '/' . $childFilename;
                }
            } else 
            {
                $result[] = $filename;
            }
        }
        return $result;
    }
    

}

?>