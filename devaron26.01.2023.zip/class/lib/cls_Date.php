<?php

/**
 * eine Datums convertifrungs Class
 * Class Date.
 */
class Date
{
    /**
     * Gibt den timestamp in deutschem Format aus.
     *
     * @param $DateString
     * @param $CompleteTime
     *
     * @return string
     */
    public static function getGermanDate($DateString, $WithTime = false, $CompleteTime = false)
    {
        if ($WithTime) {
            if($CompleteTime) {
                return date('d.m.Y H:i:s', strtotime($DateString));
            }
            return date('d.m.Y H:i', strtotime($DateString));
        }
        return date('d.m.Y', strtotime($DateString));
    }

    public static function toTimeStamp($EnglishDate)
    {
        return strtotime($EnglishDate);
    }

    public static function getGermanDateWithTime($TimeStamp)
    {
        return date('d.m.Y H:i:s', $TimeStamp);
    }

    
    /**
     * gibt den timestamp in Englischen Format aus.
     *
     * @param $TimeStamp
     *
     * @return string
     */
    public static function getEnglishDate($TimeStamp)
    {
        return date('m.d.Y H:i:s', $TimeStamp);
    }

    /**
     * convertirt den timestamp in das angegeben datum.
     *
     * @param $TimeStamp
     * @param $Language
     *
     * @return string
     */
    public static function convert($TimeStamp, $Language = null)
    {
        if ($Language == null) {
            $Language = SYSTEM_TIME_FORMAT;
        }

        switch ($Language) {
            case SYSTEM_TIME_GERMAN:
                return Date::getGermanDate($TimeStamp);
                break;

            case SYSTEM_TIME_GERMAN:
                return Date::getEnglishDate($TimeStamp);
                break;

            default:

                return Date::getGermanDate($TimeStamp);
        }
    }

    /**
     * convertiert das datum anhand der angegeben maske
     * Die maske kann unter http://php.net/manual/de/function.date.php nachgesvhlagen werden.
     *
     * @param        $TimeStamp
     * @param string $Mask
     *
     * @return bool|string
     */
    public static function convertByMask($TimeStamp, $Mask = 'd.m.Y H:i:s')
    {
        return date($Mask, $TimeStamp);
    }

    /**
     * Gibt Array mit Datumspaar auf Basis Jahr und Woche zurück. Endformat kann mit $Lang übergeben werden.
     *
     * @param type $week Kalenderwoche
     * @param type $year Jahr
     * @param type $Lang "en" oder "de"
     *
     * @return type
     */
    public static function getStartAndEndDateOfWeekAndYear($week, $year, $Lang = 'en')
    {
        $time = strtotime("1 January $year", time());
        $day = date('w', $time);
        $time += ((7 * $week) + 1 - $day) * 24 * 3600;

        switch ($Lang) {
            case 'en':
                $return[0] = date('Y-n-j', $time);
                $time += 6 * 24 * 3600;
                $return[1] = date('Y-n-j', $time);

                return $return;

            case 'de':

                $return[0] = date('d.m.Y', $time);
                $time += 6 * 24 * 3600;
                $return[1] = date('d.m.Y', $time);

                return $return;
        }
    }

    /**
     * gibt die anzahl der Kalenderwochen des Angegeben Jahres zurück.
     */
    public static function getWeeksFromYear($Year)
    {
        $date = DateTime::createFromFormat('Y-m-d', $Year.'-12-30');
        $Week = $date->format('W');

        if ($Week == '01') {
            $date = DateTime::createFromFormat('Y-m-d', $Year.'-12-30');
            $Week = $date->format('W');

            return $Week;
        }

        return $Week;
    }

    /**
     * gibt den Monat zurück.
     *
     * @param int $Year
     * @param int $Week
     *
     * @return int
     */
    public static function getMonthFromWeek($Year, $Week)
    {
        return (new DateTime())->setISODate($Year, $Week)->format('m');
    }

    public static function getMonthName($Month, $Lang = 'de')
    {
        $Name = array('Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember');

        /* var_dump($Month *1);
          var_dump($Name[(($Month * 1 ) - 1)]);
          exit(); */
        return $Name[(($Month * 1) - 1)];
    }

    /**
     * convertiert ein deutsches datum 24.03.2014 zu 2014-03-24.
     *
     * @param type $DateString
     *
     * @return type
     */
    public static function germanDateToEnglish($DateString)
    {
        $Temp = explode('.', $DateString);

        return $Temp[2].'-'.$Temp[1].'-'.$Temp[0];
    }

    /**
     * convertiert ein deutsches datum 24.03.2014 zu 2014-03-24.
     *
     * @param type $DateString
     *
     * @return type
     */
    public static function englishDateToGerman($DateString)
    {
        $Temp = explode('-', $DateString);

        return $Temp[2].'.'.$Temp[1].'.'.$Temp[0];
    }


    public static function isSaturday($Date)
    {
        if( date('l', strtotime($Date)) == "Saturday") return true;
    }

    public function isSunday($Date)
    {
        if( date('l', strtotime($Date)) == "Sunday") return true;
    }

    public static function englishDayNameToGerman( $Date, $Short=false )
    {
        $englishName = date('l', strtotime($Date));
        switch ( $englishName )
        {
            case "Monday":
                if($Short)return "Mo";
                return "Montag";
            case "Tuesday":
                if($Short)return "Di";
                return "Dienstag";
            case "Wednesday":
                if($Short)return "Mi";
                return "Mittwoch";
            case "Thursday":
                if($Short)return "Do";
                return "Donnerstag";
            case "Friday":
                if($Short)return "Fr";
                return "Freitag";
            case "Saturday":
                if($Short)return "Sa";
                return "Samstag";
            case "Sunday":
                if($Short)return "So";
                return "Sonntag";
        }

        return $englishName;
    }

    public static function integerToGermanWeekdayLong($weekDayInteger)
    {
        switch ($weekDayInteger) {
            case '1':
                return 'Montag';
            case '2':
                return 'Dienstag';
            case '3':
                return 'Mittwoch';
            case '4':
                return 'Donnerstag';
            case '5':
                return 'Freitag';
            case '6':
                return 'Samstag';
            case '7':
                return 'Sonntag';
        }

        return $weekDayInteger;
    }

    public static function integerToGermanWeekdayShort( $weekDayInteger )
    {
        switch ($weekDayInteger) {
            case '1':
                return 'Mo';
            case '2':
                return 'Di';
            case '3':
                return 'Mi';
            case '4':
                return 'Do';
            case '5':
                return 'Fr';
            case '6':
                return 'Sa';
            case '7':
                return 'So';
        }

        return $weekDayInteger;
    }

    /**
     * Gibt den Wochentag als Wort zu einem gegebenen Datum zurück.
     * Datumsformat kann deutsch, englisch oder als Timestamp sein.
     *
     * @param type $Date   "2018-01-01" oder "01.01.2018" oder "156451245"
     * @param type $Option "long" oder "short"
     *
     * @return string "Montag" oder "Mo"
     *
     * @author Simon Brandt
     */
    public static function getWeekdayFromDate($Date, $Option = 'long')
    {
        if (strpos($Date, '-') !== false || strpos($Date, '.') !== false) {
            $DateObject = new MyDateTime($Date);
        } else {
            $DateObject = new MyDateTime(date('Y-m-d', $Date));
        }

        if ($Option == 'long') {
            return Date::integerToGermanWeekdayLong($DateObject->weekday);
        } elseif ($Option == 'short') {
            return Date::integerToGermanWeekdayShort($DateObject->weekday);
        } else {
            return 'Error: unknown option!';
        }
    }

    /**
     * Gibt Date (nur Datum, keine Zeit) zu einem gegebenen Timestamp zurück.
     *
     * @param type $Timestamp
     * @param type $Format    "en" (default) oder "de"
     *
     * @return string "2018-01-01" oder "01.01.2018"
     *
     * @author Simon Brandt
     */
    public static function getDateFromTimestamp($Timestamp, $Format = 'en')
    {
        if ($Format == 'en') {
            $Date = date('Y-m-d', $Timestamp);
        } else {
            $Date = date('d.m.Y', $Timestamp);
        }

        return $Date;
    }

    public static function timeStampToDate($TimeStamp)
    {
        $datum = date('d.m.Y', $TimeStamp);
        $uhrzeit = date('H:i', $TimeStamp);

        return $datum.' - '.$uhrzeit.' Uhr';
    }
}
