<?php

class Request
{

    private $PostResponse = null;
    private $GetResponse = null;

    public function __construct()
    {
        $this->PostResponse = $_POST;
        $this->GetResponse = $_GET;
    }

    /**
     * setzt einen wert in die requestklasse rein
     *
     * @param string $Key 
     * @param string $Value der wert der gesetzt werden soll
     * @return bool 
     *
     */
    public function setPost($Key, $Value)
    {
        $this->PostResponse[$Key] = $Value;
        $_POST[$Key] = $Value;
    }

    private function get($Response)
    {
        //var_dump($this->PostResponse);
        //var_dump($this->PostResponse[ $Response ]);
        if (isset($this->PostResponse[$Response]))
        {
            return $this->PostResponse[$Response];
        }
        if (isset($this->GetResponse[$Response]))
        {
            return $this->GetResponse[$Response];
        }
        return false;
    }

    public function getParam()
    {
        return array_merge($this->PostResponse, $this->GetResponse);
    }

    public function convertToUTF8($Array)
    {
        foreach ($Array as $Key => $Row)
        {
            //var_dump($Array[$Key]);
            if(is_array($Array[$Key])) $Array[$Key] = json_encode ($Array[$Key]);
            $Array[$Key] = utf8_encode($Array[$Key]);
        }
        return $Array;
    }

    /**
     * parst schädliche zeichen aus der eingebe der benutzer
     *
     * @param string $String die benutzer eingabe
     * @return string die geparste benutzer eingabe
     *
     */
    public function parse($String)
    {
        $TempString = str_replace("%", "", $String);
        $TempString = str_replace("#", "", $TempString);
        $TempString = str_replace("'", "", $TempString);
        //$TempString=str_replace("?","",$TempString);
        //$TempString=str_replace("/","",$TempString);
        $TempString = str_replace("<", "&lt;", $TempString);
        $TempString = str_replace(">", "&gt;", $TempString);
        $TempString = str_replace('"', "&quot;", $TempString);
        $TempString = str_replace('\\', "", $TempString);
        return $TempString;
    }

    public function hasPost()
    {
        return count($this->postResponse);
    }

    public function getAsInt($Reguest, $RemovePrefix = false)
    {
        if (!$RemovePrefix)
        {
            $Reguest = $this->get($Reguest);
        } else
        {
            $Reguest = $this->get($this->removePrefix($Reguest));
        }
        settype($Reguest, "integer");
        return $Reguest;
    }

    public function getAsString($Reguest, $RemovePrefix = false)
    {
        $Reguest = $this->get($Reguest);
        settype($Reguest, "string");
        if (!$RemovePrefix)
        {
            return $this->parse($Reguest);
        }

        return $this->parse($this->removePrefix($Reguest));
    }

    public function getAsBool($Reguest)
    {
        $Reguest = $this->get($Reguest);
        settype($Reguest, "boolean");
        return $Reguest;
    }

    public function getAsFloat($Reguest)
    {
        $Reguest = $this->get($Reguest);
        $Reguest = Utility::floatvalue($Reguest);
        settype($Reguest, "float");
        return $Reguest;
    }

    public function getAsArray($Reguest)
    {
        return $this->get($Reguest);
    }

    public function getNoneParsed($Reguest)
    {
        return $this->get($Reguest);
    }

    public static function isAjax()
    {

        $headers = getallheaders();
        return array_key_exists('Ajax-Request', $headers);
    }

    public function removePrefix($TempString)
    {
        $Temp = explode("_", $TempString);
        if (strlen($Temp[1]) == 0)
            return $Temp[0];
        return $Temp[1];
        /* var_dump($TempString);
          $TempString=str_replace("tb_","",$TempString);
          var_dump($TempString);
          $TempString=str_replace("rtb_",'',$TempString);
          $TempString=str_replace("cb_","",$TempString);
          $TempString=str_replace("s_","",$TempString);
          $TempString=str_replace("ra_","",$TempString);
          return $TempString; */
    }

    /**
     * gibt alle Post daten zurück
     */
    public function getAllPost()
    {
        $Return = array();
        foreach ($this->PostResponse as $Key => $PostValue)
        {
            $Return[$this->removePrefix($Key)] = $this->parse($PostValue);
        }
        return $Return;
    }
    
    /**
     * gibt alles als Array zurück
     * @return array
     */
    public function getAllAsArray()
    {
        $Return = array();
        foreach ($this->PostResponse as $Key => $PostValue)
        {
            $Return[$this->removePrefix($Key)] = $this->parse($PostValue);
        }
        
        foreach ($this->GetResponse as $Key => $GetValue)
        {
            $Return[$this->removePrefix($Key)] = $this->parse($GetValue);
        }
        
        return $Return;
    }
    
    

    /**
     * gibt als array alle files zurück welche angehangen wurden
     * @return type
     */
    public function getAllFiles()
    {
        $Return = array();
        foreach ($this->PostResponse as $Key => $PostValue)
        {
            //var_dump($Key);
            if (strpos($Key, "f_") !== false)
            {
                $Return[$this->removePrefix($Key)] = $this->parse($PostValue);
            }
        }
        //exit;
        return $Return;
    }

    public function getUrl()
    {
        return $_SERVER[HTTP_HOST] . $_SERVER[REQUEST_URI];
    }

    
    public function saveAsFile( $Reguest , $PathWithFileName)
    { 
        //var_dump( $_REQUEST['tb_'.$Reguest] );
        $ImageData = $_REQUEST['tb_'.$Reguest];
        if(strlen($ImageData) == 0 )
        {
            $ImageData = $_REQUEST[ $Reguest ];
        }

        if(strpos($ImageData, ",") !== false) // wemm base 64 zeugs davorsteht
        {
            $FilteredData = substr($ImageData, strpos($ImageData, ",") + 1);
        } else 
        {
            $FilteredData = $ImageData;
        }

        // var_dump( $FilteredData ); 
        // var_dump( $PathWithFileName );
        
        if( strlen($FilteredData) == 0 ) return; // wenn nichts zum speichern da sit dann raus hier
        
        //var_dump( $FilteredData ); 
       // var_dump( $PathWithFileName );
        //exit();
        
        $UnencodedData = base64_decode( $FilteredData );
        file_put_contents( $PathWithFileName , $UnencodedData );
    }
    
    /**
     * gibt eine base64 datei als string zurück
     * @param string $Reguest
     * @return string
     */
    public function getBase64FileAsString( $Reguest )
    { 
        //var_dump( $_REQUEST['tb_'.$Reguest] );
        if( !isset( $_REQUEST['tb_' . $Reguest] ) )
        {
            $ImageData = $_REQUEST[ $Reguest];
        } else 
        {
            $ImageData = $_REQUEST['tb_' . $Reguest];
        }
       
        if(strpos($ImageData, ",") !== false) // wemm nase 64 zeugs davorsteht
        {
            $FilteredData = substr($ImageData, strpos($ImageData, ",") + 1);
        } else 
        {
            $FilteredData = $ImageData;
        }
        if( strlen($FilteredData) == 0 ) return; // wenn nichts zum speichern da sit dann raus hier
        return base64_decode($FilteredData);
    }
    
    
    
    
    
}

?>