<?php

class Translator
{
    /*
     * macht aus dem Openform string den Bild pfad
     */
    public static function translateOpenFormToPicture( $OpenFormString )
    {
        //var_dump($OpenFormString);
        return substr( $OpenFormString , 10) . ".png";
    }

    /*
     * macht aus dem form string den Bild pfad
     */
    public static function translateFormToPicture( $FormString )
    {
        $Temp = substr( $FormString , 5) . "_grundmodell.png";
        return $Temp;
    }
    
    /**
     * gibt die flügelanzahlzurück von der Form
     * @param type $FormString
     * @return string
     */
    public static function getWingCount( $FormString )
    {
        return substr( $FormString , 5,1) ;
    }
    
    public static function hasHeadLight( $FormString )
    {
        $Temp = substr( $FormString , 5) ;
        $Temp = explode("_", $Temp);
        if( is_numeric( $Temp[1] ))
        {
            return $Temp[1];
        }
        return 0;
    }
    
    /**
     * übersetzt die öffnungform zu einem string
     * OPEN_FORM_1_f > einteiliges fenster ohne öffnung
     * @param type $String
     */
    private static function translateOpenForm($String)
    {
        $Temp = substr( $String , 10);
        $Temp = explode("_", $Temp);
        $Return = '';
        $i= 0;

        $HasHeadLight = false;
        $HeadLightText = '';
        $Count = count( $Temp );
        //var_dump($Count);
        
        foreach($Temp as $Part)
        {
            
            //var_dump( $HasHeadLight );
            //var_dump( $i +1 );
            //var_dump( $Count == $i +1 );
            
            if( $HasHeadLight && $Count == $i +1)
            {
                $Return .= $HeadLightText;
            }
            
            
            switch( $Part )
            {
                case "1" : 
                    if($i == 0) 
                    {
                        $Return .= "Einteiliges Fenster ";
                    } else 
                    {
                        $HasHeadLight = true;
                        $HeadLightText = "mit Oberlicht ";

                        //$Return .= "mit Oberlicht ";
                    }
                    break;
                    
                    case "2" : 
                    if($i == 0) 
                    {
                        $Return .= "Zweiteiliges Fenster ";
                    } else 
                    {
                        $HasHeadLight = true;
                        $HeadLightText = "mit geteilten Oberlicht ";
                        // $Return .= "mit geteilten Oberlicht ";
                    }
                    break;
                    
                    case "3" : 
                       $Return .= "Dreiteiliges Fenster ";
                    break;
                    
                    case "k" : 
                       $Return .= "Kipp ";
                    break;
                
                    case "f" : 
                       $Return .= "Fest ";
                    break;
                
                    case "dkl" : 
                       $Return .= "Drehkipp links ";
                    break;
                
                    case "dkr" : 
                       $Return .= "Drehkipp rechts ";
                    break;
                    
            }
            $i++;
        }
        
        return $Return;
        
    }

    /**
     * übersetzt die Konstatnen im system zu text
     * @param type $String
     * @return string
     */
    public static function translate( $String )
    {
        if( strpos($String, "OPEN_FORM_") !== false )
        {
            return self::translateOpenForm( $String );
        }

        switch($String)
        {
            case TYPE_LUMBER:
                return "Holzfenster";
                break;
            
            case TYPE_PLASTIC:
                return "Kunststofffenster";
                break;
            
            case WINDOW_PROFILE_70:
                return "KBE Profil 70";
                break;
            
            case WINDOW_PROFILE_80:
                return "KBE Profil 80";
                break;
            
            case WINDOW_PROFILE_78:
                return "Profil 78 mm";
                break;
            
            case WINDOW_PROFILE_88:
                return "Profil 88 mm";
                break;
            
            case WINDOW_PROFILE_68:
                return "Profil 68 mm";
                break;
            
            case NO_DECORE:
                return "Standard Weiß";
                break;
            
            case DECOR_TYPE_SAME:
                return "Außen und Innendekor (Genarbt)";
                break;
            
            case DECOR_TYPE_DIFFERENT:
                return "Außendekor (Genarbt)";
                break;
            
            
            case DECOR_TYPE_DIFFERENT_LUMBER:
                return "Außendekor";
                break;
            
            case DECOR_TYPE_SAME_LUMBER:
                return "Außen und Innendekor";
                break;
            
            case TILLER_TYPE_NORMAL:
                return "Normale Sprossen";
                break;
            
            case TILLER_TYPE_GLAS_SPLIT:
                return "Glasteilende Sprossen";
                break;
            
             case TILLER_TYPE_WIENER:
                return "Wienersprossen";
                break;
            
            case WINDOW_KEY:
                return "Fenster schlüssel";
                break;
            
            case GLAS_TYPE_DOUBLE_GLAS:
                return "2 Fach Ug 1,1";
                break;
            
            case GLAS_TYPE_TRIPLE_GLAS:
                return "3 Fach Ug 0,6";
                break;
            
            case GLAS_TYPE_SUN_PROTECTION:
                return "Sonnenschutzglas";
                break;
            
            case GLAS_TYPE_SECURITY_GLAS_COMPLETE:
                return "Sicherheitsglas Außen und Innen";
                break;
            
            case GLAS_TYPE_SECURITY_GLAS:
                return "Sicherheitsglas Außen";
                break;
            
            case GLAS_TYPE_SOUND_ISOLATION:
                return "Schallschutzsglas 39 DB (Glas)";
                break;         
            
            case TAKE_SECIRITY_BINDER:
                return "Sicherheits Beschlag Winkhaus active Pilot";
                break;
            
            case TAKE_SECIRITY_BINDER_WK2:
                return "Sicherheits Beschlag nach WK2, Winkhaus active Pilot";
                break;
              
            case TAKE_BENCH:
                return "Fensterbankanschluss";
                break;
            
             case TAKE_SHUTTER:
                return "Rolladen Profile";
                break;
            
            case NO_BENCH:
                return "keinen Fensterbankanschluss";
                break;
            
            case NO_UTILS:
                return "kein Zubehör";
                break;       
            
            case NO_SHUTTER:
                return "keine Rollladen";
                break;
            
            case TAKE_BENCH_COMPLETE:
                return "Fensteranschlussbank Außen und Innen";
                break;
            
            case TAKE_BENCH_OUTER:
                return "Fensteranschlussbank Außen";
                break;
            
            case NO_BINDER:
                return "Standartbeschlag, Winkhaus active Pilot ";
                break;
             
            case NO_TILLER:
                return "keine Sprossen";
                break;
            
            
            case TILLER_TYPE_DEKOR:
                return "Dekor Sprossen";
                break;
            
            
            
            
            case PAYMENT_PRE_PAYMENT:
                return "Vorkasse";
                break;
            
            case PAYMENT_CASH_ON_DELIVERY:
                return "Nachnahme";
                break;
            
            case PAYMENT_PAYPAL:
                return "PayPal";
                break;
            
            case PAYMENT_BILL:
                return "Rechnung";
                break;
            
            
            
            case DELIVERY_OWN_TRANSPORT:
                return "Selbstabholung";
                break;
            
            
            case DELIVERY_ORDER:
                return "Lieferung";
                break;
            
            
            
            case DECOR_NAME_GOLDEN_OAK:
                return "Goldene Eiche";
                break;
            
            case GOLDEN_OAK:
                return "Goldene Eiche";
                break;
            
            
            
            case LUMBER_TYPE_PINE:
                return "Kiefer";
                break;
            
            
            case LUMBER_TYPE_OAK:
                return "Eiche";
                break;
            
            case LUMBER_TYPE_LARCH:
                return "Lärche";
                break;
            
            case LUMBER_TYPE_MERANTI:
                return "Meranti";
                break;
            
            case DECOR_FLAT:
                return "Lack";
                break;
            
            case DECOR_GLAZE:
                return "Lasur";
                break;
            
            
        }
        
        
        
        return $String;
    }
    
}


?>
