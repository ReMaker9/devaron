<?php

class Session
{

    protected $TypeDefinitions;
    protected $KeyArray;
    protected $Prefix;
    protected $PrefixArray;


    public function __construct( $Prefix = "global" )
    {
        $this->Prefix = $Prefix;

        if( !isset($_SESSION['PrefixArray']) ||  !is_array( $_SESSION['PrefixArray'] ) )
        {
            $this->PrefixArray = array();
        } else
        {
            $this->PrefixArray = $_SESSION['PrefixArray'];
        }

        if( !isset( $this->PrefixArray[$this->Prefix] ) || !is_array( $this->PrefixArray[$this->Prefix] ) )
        {
            $this->PrefixArray[ $this->Prefix ] = array();
        }


    }


    public function set($Key,$Value)
    {
        $Type = gettype ( $Value );
        if($Type == 'object') // wenn object ist dann die klasse abspeichern
        {
            $Type = get_class( $Value );
            $Value = serialize( $Value ); // den input wegschreiben
        } else
        {
            $Type = SYSTEM_VARIABLE;
        }
        $this->KeyArray[ $this->Prefix . "_" . $Key ] = $Type;
        if(isset($_SESSION[ $this->Prefix . "_" . $Key ]))
        {
            $NewElememnt = false;
        } else
        {
            $NewElememnt = true;
        }
        $_SESSION[ $this->Prefix . "_" . $Key ] = $Value;

        if(!isset( $_SESSION[ $this->Prefix . "_TypeDefinition" ] ))
        {
            $_SESSION[ $this->Prefix . "_TypeDefinition" ] =  array();
        }
        $_SESSION[ $this->Prefix . "_TypeDefinition" ][$Key] = $Type;
        $this->PrefixArray[$this->Prefix][$Key] = true;

    }



    public function get($Key,$NameSpace = false)
    {
        if(!$NameSpace)
        {
            $NameSpace = $this->Prefix;
        }

        if(! isset($_SESSION[ $NameSpace . "_TypeDefinition" ][$Key]) ) return null;
        if( $_SESSION[ $NameSpace . "_TypeDefinition" ][$Key] == SYSTEM_VARIABLE )
        {
            return $_SESSION[ $NameSpace . "_" . $Key ];
        }
        //  es ist ein object das geladen werden muss
        Includer::getInstance()->includeClass($_SESSION[ $NameSpace . "_TypeDefinition" ][$Key]);
        return unserialize( $_SESSION[ $NameSpace . "_" . $Key ] );
    }


    public function remove($Key,$NameSpace = false)
    {
        if(!$NameSpace)
        {
            $NameSpace = $this->Prefix;
        }
        unset( $this->KeyArray[ $NameSpace . "_" . $Key ] );
        unset( $_SESSION[ $NameSpace . "_" . $Key ] );

        $_SESSION[ $NameSpace . "_TypeDefinition" ] = $this->KeyArray[ $NameSpace . "_" . $Key ];
    }

    /**
     * entfernt alle einträge aus der session mit dem momentanen Prefix
     */
    public function clear()
    {
        $Keys = array_keys($this->PrefixArray[ $this->Prefix ]);

        foreach($Keys as $Key )
        {
            unset(  $_SESSION[ $this->Prefix . "_" . $Key ] );
        }

        unset( $this->PrefixArray[ $this->Prefix ] );
        $_SESSION['PrefixArray'] = $this->PrefixArray;
        unset( $_SESSION[ $this->Prefix . "_TypeDefinition" ] );

    }

    /**
     * löscht alle session variablen
     */
    public function clearAll()
    {
        session_unset();
    }

    public function getStoredClassNames()
    {
        return $_SESSION[ $this->Prefix . "_TypeDefinition" ];
    }


}

?>