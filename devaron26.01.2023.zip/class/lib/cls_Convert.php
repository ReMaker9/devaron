<?php

class Convert
{

    public static function timeStampToDate( $TimeStamp )
    {
        $datum = date("d.m.Y", $TimeStamp);
        $uhrzeit = date("H:i", $TimeStamp);
        return $datum . " - " . $uhrzeit . " Uhr";
    }

    /**
     * macht aus \u00DF => 'ß' 
     * @param type $String
     * @return type
     */
    public static function unicodeCharsetToText($String)
    {
        return strtr($String, array(
	'u00A0'    => ' ',
	'u0026'    => '&',
	'u003C'    => '<',
	'u003E'    => '>',
	'u00E4'    => 'ä',
	'u00C4'    => 'Ä',
	'u00F6'    => 'ö',
	'u00D6'    => 'Ö',
	'u00FC'    => 'ü',
	'u00DC'    => 'Ü',
	'u00DF'    => 'ß',
	'u20AC'    => '€',
	'u0024'    => '$',
	'u00A3'    => '£',
 
	'u00a0'    => ' ',
	'u003c'    => '<',
	'u003e'    => '>',
	'u00e4'    => 'ä',
	'u00c4'    => 'Ä',
	'u00f6'    => 'ö',
	'u00d6'    => 'Ö',
	'u00fc'    => 'ü',
	'u00dc'    => 'Ü',
	'u00df'    => 'ß',
	'u20ac'    => '€',
	'u00a3'    => '£',
        ));
    }
    
    

    /**
     * @param $Gigabytes
     * @return mixedmacht aus gigabyte bytes
     */
    public static function gigabyteToBytes( $Gigabytes )
    {
        return $Gigabytes * 1024 * 1024 * 1024;
    }



    public static function byteToString( $Bytes )
    {
        if ($Bytes < 1024)
            return $Bytes . " B";

        if ($Bytes < 1024 * 1024) // kb
            return number_format($Bytes / 1024, 1, ",", ".") . " KB";

        if ($Bytes < 1024 * 1024 * 1024) // mb
            return number_format($Bytes / 1024 / 1024, 1, ",", ".") . " MB";

        if ($Bytes < 1024 * 1024 * 1024 * 1024) // mb
            return number_format($Bytes / 1024 / 1024 / 1024, 1, ",", ".") . " GB";

        if ($Bytes < 1024 * 1024 * 1024 * 1024 * 1024) // tb
            return number_format($Bytes / 1024 / 1024 / 1024 / 1024, 1, ",", ".") . " TB";


        return "can't convert";
    }


    public static function truncate($string, $length, $dots = "")
    {
        return ( strlen( $string ) > $length ) ? substr( $string, 0, $length - strlen( $dots ) ) . $dots : $string;
    }


    /**
     * formatiert einen float zahl
     *
     * @param float $Float
     * @param int $Decimals gibt die nachkomma stellen an
     * @return string ein zahlen string
     *
     */
    public static function format($Float, $Decimals = 2)
    {
        return number_format($Float, $Decimals, ',', '.');
    }

    /**
     *  wandelt das englische datum in das deutsche Format um
     * @param type $DateString
     * @param type $CompleteTime
     * @return type
     */
    public static function getGermanDate($DateString, $CompleteTime = false)
    {
        if ($CompleteTime)
        {
            return date("d.m.Y G:i:s", strToTime($DateString));
        }
        return date("d.m.Y ", strToTime($DateString));
    }


    /**
     * convertiert ein deutsches datum 24.03.2014 zu 2014-03-24
     * @param type $DateString
     * @return type
     */
    public static function germanDateToEnglish( $DateString )
    {
        $Temp = explode(".", $DateString);

        return $Temp[2] . "-" . $Temp[1] . "-" . $Temp[0];
    }


    /**
     * convertiert ein deutsches datum 24.03.2014 zu 2014-03-24
     * @param type $DateString
     * @return type
     */
    public static function englishDateToGerman( $DateString )
    {
        
        if(strpos($DateString, " ") !== false)
        {
            $Temp = explode(" ", $DateString);
            $DateString = $Temp[0];
        }
        
        
        return date("d.m.Y", strtotime($DateString));
        $Temp = explode("-", $DateString);

        return $Temp[2] . "." . $Temp[1] . "." . $Temp[0];
    }

    /*
     * macht aus kommata einen punkt 2,9 => 2.9
     */
    public static function toFloat( $String )
    {
        return str_replace(",", ".", $String );
    }

    
    public static function arrayToCsv( $DataArray , $Separator = ";", $OutpuFile = null )
    {
        $Count = count( $DataArray );
        $Keys = array_keys( $DataArray[0] );
        $Output = "";
        $Output = implode( $Separator, $Keys ) ."\r\n";
        foreach( $DataArray as $Entry )
        {
            $Entry['Art'] = DorminoAdapter::getTypeName($Entry['Art']);
            //var_dump($Entry);
            //exit();
            $Output .=  implode( $Separator, $Entry ) ."\r\n" ;  
            
            foreach($Entry as $SubEntry)
            {
               
            }
        }
        
        if( strlen($OutpuFile) == 0 )
        {
            return $Output;
        }
        
        file_put_contents( $OutpuFile , $Output );

    }
    
    
    
}


?>
