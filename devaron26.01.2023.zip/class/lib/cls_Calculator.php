<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Calculator
{
    
    public function getEmptyPriceObject()
    {
        $Class = new stdClass();
        $Class->Height = 0;
        $Class->Width = 0;
        $Class->BasicPrice = 0;
        $Class->Qm = 0;
        $Class->GlasPrice = 0;
        $Class->ColorPrice = 0;
        $Class->SpecialGlassPrice = 0;
        $Class->TillerPrice = 0;
        $Class->BinderPrice = 0;
        $Class->EndPrice = 0;
        return $Class;
    }
    
    /**
     * gibt die anzahl der Produkte zurück
     */
    public static function getProductCount()
    {
        $Count = 0;
        foreach($_SESSION['Basket']['Products'] as $Product )
        {
            $Count += $Product['Count']; 
        }
        return $Count;
    }
    
    /**
     * brechnet die steuer von einem endpreis ((PE / 119) * 100 )
     */
    public static function getTaxFromPrice( $EndPrice )
    {
        if(!$EndPrice) return 0;
        return $EndPrice - (( $EndPrice / 119) * 100 );  
    }
    
    
    
    
    public function getPrice()
    {
        // daten aus sesison holen
        $Return = new stdClass();
        $_SESSION['Chois'];
        if(!$_SESSION['Chois']) return $this->getEmptyPriceObject();        
        if(!$_SESSION['Chois']['Width']) return $this->getEmptyPriceObject();
        if(!$_SESSION['Chois']['Height']) return $this->getEmptyPriceObject();
        if(!$_SESSION['Chois']['WindowType']) return $this->getEmptyPriceObject();
        if(!$_SESSION['Chois']['Profile']) return $this->getEmptyPriceObject();
         
        // ohne größe kann nix berechnet werden
        
        $WindowWidth = $_SESSION['Chois']['Width'];
        $Qm = ($_SESSION['Chois']['Height'] * $_SESSION['Chois']['Width']) / 1000 / 1000;
        $Name = substr( $_SESSION['Chois']['OpenForm'] , 10); //OPEN_FORM_1_f
        
        $Return->Qm = $Qm;
        
        
       
        
        $WindowContent = json_decode(file_get_contents("cfg/" . $Name . ".json") );
        
        $NameSplit = explode("_",$Name);
        $WingCount = 0; 
        foreach ($NameSplit as $Part)
        {
            if( !is_numeric($Part) ) continue;
            $WingCount+= $Part;
        }
        
        
        if( $_SESSION['Chois']['WindowType'] == TYPE_PLASTIC )
        {   // kunststoff fenster
            if( $_SESSION['Chois']['Profile'] == WINDOW_PROFILE_70)
            {
                $BasicPrice = $WindowContent->Price * $Qm;
            } else 
            {
                $BasicPrice = $WindowContent->Price * $Qm;
                $BasicPrice+= $BasicPrice * 0.1; // 10% aufschlag für Plastik fenster
            }
        } else 
        {
            // holzfenster 
            
            switch($_SESSION['Chois']['LumberType'])
            {
                case LUMBER_TYPE_OAK:
                    $BasicPrice = $WindowContent->OakPrice * $Qm;
                    break;
                
                 case LUMBER_TYPE_LARCH:
                    $BasicPrice = $WindowContent->LarchPrice * $Qm;
                    break;
                
                case LUMBER_TYPE_PINE:
                    $BasicPrice = $WindowContent->PinePrice * $Qm;
                    break;  
                
                
                case LUMBER_TYPE_MERANTI:
                    $BasicPrice = $WindowContent->MerantiPrice * $Qm;
                    break;  
            }          
        }
        
        $Return->BasicPrice = $BasicPrice;
        
        
        $GlasPrice = 0;
        if($_SESSION['Chois']['GlasType'] == GLAS_TYPE_TRIPLE_GLAS )
        {
            $GlasPrice = $Qm * TRIPLE_GLAS_PRICE ;// Glas aufschlag je QuadratMeter für tripple Glas   
        }
        $Return->GlasPrice = $GlasPrice;
        
        $EdgePrice = 0;
        if( $_SESSION['Chois']['EdgeType'] == TAKE_EDGE )
        {
            $EdgePrice = $Qm * PRICE_EDGE ;// Glas aufschlag je QuadratMeter für tripple Glas   
        }
        $Return->EdgePrice = $EdgePrice;
        
        
        
        
        $ColorPrice = 0;
        if($_SESSION['Chois']['DekorType'] != NO_DECORE)
        {
            $ColorPrice = ($BasicPrice *1) * COLOR_ADDITION_PERCENT;
        } 
        $Return->ColorPrice = $ColorPrice;
        
        $Return->DekorTypeColorPrice = 0;
        if( $_SESSION['Chois']['WindowType'] == TYPE_LUMBER ) // nur bei Holzfenstern
        {
            $DekorTypeColorPrice = 0;
            if($_SESSION['Chois']['DekorTypeColor'] == DECOR_TYPE_DIFFERENT_LUMBER) // wenn unterschiiedlich egewäht wurde dann aufschlag drauf
            {
                $DekorTypeColorPrice = COLOR_ADDITION_LUMBERONE_COLOR_PRICE;
            } 
            $Return->DekorTypeColorPrice = $DekorTypeColorPrice;
        }
        
        
        
        
        
        
        
        switch($_SESSION['Chois']['SpezicalType'])
        {
            case GLAS_TYPE_TRAV_GLAS:
                $SpecialGlassPrice = $Qm * GLAS_PRICE_SHUTTER; 
            break;
        
            case GLAS_TYPE_SECURITY_GLAS:
                $SpecialGlassPrice = $Qm * GLAS_PRICE_SECURITY; 
            break;
        
            case GLAS_TYPE_SECURITY_GLAS_COMPLETE:
                $SpecialGlassPrice = $Qm * GLAS_PRICE_SECURITY_GLAS_COMPLETE; 
            break;
        
        
            case GLAS_TYPE_SOUND_ISOLATION:
                $SpecialGlassPrice = $Qm * GLAS_PRICE_SOUND_ISOLATION; 
            break;
        
            case GLAS_TYPE_SOUND_ISOLATION:
                $SpecialGlassPrice = $Qm * GLAS_PRICE_SOUND_ISOLATION; 
            break;
        
            default:
               
                $SpecialGlassPrice = 0; 
            
        }
        
        $Return->SpecialGlassPrice = $SpecialGlassPrice;
        // Sprossen berechnung
        
        
        if(  $_SESSION['Chois']['TillerType'] != NO_TILLER )
        {
            // alle sprossen zusammen berechnen
            $Tillercount = $_SESSION['Chois']['HorizontalTiller'] + $_SESSION['Chois']['HorizontalTillerHead'] + $_SESSION['Chois']['VertiaklTiller'] + $_SESSION['Chois']['VertiaklTillerHead']; 
            
            
            if( $_SESSION['Chois']['TillerType'] == TILLER_TYPE_NORMAL )
            {
                 $TillerPrice = $WindowContent->NormalTillerPrice * $Tillercount;
            } else 
            {
                 $TillerPrice = $WindowContent->SplitTillerPrice * $Tillercount;
            }
        }
        $Return->TillerPrice = $TillerPrice;
        
        // beschlag berechnung
        // Flügel zählen XD und dann mal festpreis
        
        
        

        if( isset( $_SESSION['Chois']['Binder'] ) &&  $_SESSION['Chois']['Binder'] != NO_BINDER )
        {
            if( $_SESSION['Chois']['WindowType'] == TYPE_PLASTIC )
            {  // kunststoff
                if( $_SESSION['Chois']['Binder'] == TAKE_SECIRITY_BINDER )
                {
                    $BinderPrice = $WingCount * BINDER_PLASTIC_PRICE_NORMAL_SECURITY;
                }
                else 
                {
                    $BinderPrice = $WingCount * BINDER_PLASTIC_PRICE_HIGH_SECURITY;
                }
                
            } else 
            {  // holz
                $BinderPrice = $WingCount * BINDER_LUMBER_PRICE;
            }
        } else 
        {
            $BinderPrice = 0;
        }
        
        $Return->BinderPrice = $BinderPrice;

        
        if( isset( $_SESSION['Chois']['WindowKey'] ) &&  $_SESSION['Chois']['WindowKey'] != NO_UTILS )
        {
            $WindowKeyPrice = $WingCount * PRICE_WINDOW_KEY;
        } else 
        {
            $WindowKeyPrice = 0;
        }
        
        $Return->WindowKeyPrice = $WindowKeyPrice;
        
        
        // fensterbank anschluss preis
        if(  $_SESSION['Chois']['Bench'] != NO_BENCH )
        {
            $BenchPrice = ( $WindowWidth / 1000 ) * PRICE_BENCH;
        } else 
        {
            $BenchPrice = 0 ;
        }
        $Return->BenchPrice = $BenchPrice;
        
        
        
        
        $EndPrice = $TillerPrice + $SpecialGlassPrice + $ColorPrice + $GlasPrice + $BasicPrice + $BinderPrice + $WindowKeyPrice + $BenchPrice + $EdgePrice + $Return->DekorTypeColorPrice;
        
        $Return->EndPrice = $EndPrice;
        
        return $Return;

    }
    
    
    private function calculateForm1()
    {
        switch($_SESSION['Chois']['OpenForm'])
        {
            case OPEN_FORM_1_f:
                
                
                
                
                break;
            
            
            
            
            
            
        }
        
        
        return;
    }
    
    
}
