﻿<?php

/**
 * class cls_Controler_Click
 *
 * Description for class cls_Controler_Click
 *
 * @author:
 */
class Controler_Login extends Controler
{

    /**
     * cls_Controler_Click constructor
     *
     * @param 
     */
    function __construct()
    {
        parent::__construct();
        $this->TempLate = Template::getInstance();
    }

    public function start()
    {
        
        $Request = new Request();
        switch ( $Request->getAsString('Action') )
        {
            case "ShowRegister":
                {
                    $this->showRegister();
                } break;

            case "ShowAgb":
                {
                    $this->showAgb();
                } break;

            case "CreateUser":
                {
                    $this->createUser();
                } break;

            case "Register":
                {
                    $this->registerNewUser();
                } break;
				
            case "UserLogin":
                {
                    $this->userLogin();
                } break;
				
			case "UserLogout":
            case "Logout":
                {
                    $this->userLogout();
                } break;

            case "ShowStory":
                {
                    $this->showStory();
                } break;

            case "GetCaptcha":
                {
                    $this->getCaptcha();
                } break;

            case "ShowCreateSeller":
                {
                    $this->showCreateSeller();
                } break;


         
            case "ShowUserEdit":
                {
                    $this->showUserEdit();
                } break;

            case "ShowDownload":
                {
                    $this->showDownload();
                } break;
            
            case "EditUser":
                {
                    $this->editUser();
                }break;
            
            case "EditUserPass":
                {
                    $this->editUserPass();
                }break;
            
            case "ShowPasswortReset":
                {
                    $this->showPasswortReset();
                }break;
            
            case "SendPasswortReset":
                {
                    $this->sendPasswortReset();
                }break;
            
            case "ResetPass":
                {
                    $this->resetPass();
                }break;
            
            case "ShowHelp":
                {
                    $this->showHelp();
                }break;
            
            default:
                $this->showLogin();
        }   
    }

    public function showPrice( $ErrorString = "" )
    {
        $Request = new Request();
        $TempLate = Template::getInstance( "./tpl_Price.php" );
       
        $TempLate->render();      
    }
    
    
    
    public function showHelp( $ErrorString = "" )
    {

        $Request = new Request();
        $TempLate = Template::getInstance( "./tpl_Help.php" );
       
        $TempLate->render();      
    }
    

    
    
    public function resetPass( $ErrorString = "" )
    {
        //$this->checkLogin();
        $Request = new Request();
        
        $TempLate = Template::getInstance( "./login/tpl_Passwortreset.php" );
             
        $Request->getAsString("tb_Pass");
        
        if($Request->getAsString("tb_Pass") != $Request->getAsString("tb_Pass2"))
        {
            $TempLate->outputJSON( 0 , "Die Passwörter stimmen nicht überein." );
            return ;
        }
        
        $PassresetFinder= new PassresetFinder();
        $ResetData = $PassresetFinder->findByHash( $Request->getAsString("tb_Hash") )->getByIndex(0);
        $UserFinder = new UserFinder();

        $User = $UserFinder->findById( $ResetData->getUserId() );  
        
        
        if( !$User->getId())
        {
            $TempLate->outputJSON(0, "User nicht gefunden." );
            exit();
        }
           
        if( !$ResetData->getId())
        {
            $TempLate->outputJSON(0, "Bitte melden Sie sich bei Ihrem Administrator." );
            exit();
        }
       
        $User->setPass( $Request->getAsString("tb_Pass") );
        $User->cryptPass();

        $UserManager = new UserManager();
        $UserManager->updateUser($User);
        
        $PassresetManager = new PassresetManager();
        $PassresetManager->deletePassreset($ResetData);
        
        $TempLate->outputJSON( 1 , "Ihr Passwort wurde erfolgreich resettet. Bitte loggen Sie sich mit Ihrem neuen Passwort ein." );
    }
    
    
    
    /**
     * versendet eine Mail mit einem Link zum Passreseten
     * @param type $ErrorString
     */
    public function sendPasswortReset( $ErrorString = "" )
    {
        //$this->checkLogin();
        $Request = new Request();
        $TempLate = Template::getInstance( );
        $UserFinder = new UserFinder();
        
        $UserCollection = $UserFinder->findByMail( $Request->getAsString("tb_Mail") );
        
        $User = $UserCollection->getByIndex(0) ;
        
        if( !$User->getId())
        {
            $TempLate->outputJSON(0, "Mail nicht gefunden.");
            exit();
        }
        
        $Ip = $_SERVER['REMOTE_ADDR'];
        
        $Reset = new Passreset();
        $Reset->setIp( $Ip );
        $Reset->setUserId( $User->getId() );
        $Reset->setHash( md5($User->getId() . microtime() ) );
        $Reset->setMail( $User->getMail() );
        
        
        $PasswordResetManager = new PassresetManager();
        $PasswordResetManager->insertPassreset($Reset);
        
        
        // mail Versenden
        
        $TempLate->outputJSON( 1 , "Eine E-Mail wurde zu Ihnen gesendet." );
        
        
        
        $MailControler = new Controler_Mail();
        $MailControler->sendPasswortReset( $Reset );
        
     
    }
    
    public function showPasswortReset( $ErrorString = "" )
    {
        //$this->checkLogin();
        $Request = new Request();
        if( strlen( $Request->getAsString("Hash") ) > 0 )
        {
            
            $TempLate = Template::getInstance( "./login/tpl_Passwortreset.php" );
             
            $PassresetFinder= new PassresetFinder();
            $ResetData = $PassresetFinder->findByHash( $Request->getAsString("Hash") )->getByIndex(0);
            
            if( $ResetData->getId() == 0 )
            {
                $TempLate->renderError("Fehler", "Dieser link ist leider abgelaufen", $BackLink);
                exit();
            }
            
            $UserFinder = new UserFinder();
            $UserFinder->findById( $ResetData->getUserId() );
            $TempLate->assign( "Hash" , $Request->getAsString("Hash") );
            $TempLate->render(); 
            exit();
        }
        
        $TempLate = Template::getInstance( "./login/tpl_PasswortresetMail.php" );
        
        //$UserFinder = new UserFinder();
        //$User = $UserFinder->findById( Controler_Main::getInstance()->getUser()->getId() );
        //$TempLate->assign("User", $Value);//
        $TempLate->render();      
    }
    
    
    public function editUserPass($ErrorString = "")
    {
        $Request = new Request();
        $User = User::getEmptyInstance();
        
        
        $this->checkLogin();
        if($this->getUser()->getId() != $Request->getAsInt("Id") ) return;
        
        $UserFinder =  new UserFinder ();
        
        $User = $UserFinder->findbyId( $Request->getAsInt("Id") );
        $User->setPass( $Request->getAsString("Pass") );
        $User->cryptPass();
        $_SESSION[ 'UserPass' ] = $User->getPass();
        $UserManager = new UserManager();

        $Result =  $UserManager->updateUser($User);


        $TempLate = Template::getInstance("");

        // den User Einloggen

        $TempLate->outputJSON(0, $Result);

    }
    
    public function editUser($ErrorString = "")
    {
        $Request = new Request();
        $User = User::getEmptyInstance();

        $this->checkLogin();
        if($this->getUser()->getId() != $Request->getAsInt("Id") ) return;
        $UserFinder =  new UserFinder ();
        $User = $UserFinder->findbyId( $Request->getAsInt("Id") );
        $User->setValuesFromArray( $Request->getAllPost() );
        $UserManager = new UserManager();
        
        $Result =  $UserManager->updateUser($User);
        $TempLate = Template::getInstance("");
        $TempLate->outputJSON(0, $Result);
    }
    
    
    
   
    public function showDownload( $ErrorString = "" )
    {
        $this->checkLogin();
        $Request = new Request();
        $TempLate = Template::getInstance( "./login/tpl_Download.php" );
        $TempLate->assign( "Subnavi" , ADMIN_MENU_DOWNLOADS );
        $UserFinder = new UserFinder();
        $User = $UserFinder->findById( Controler_Main::getInstance()->getUser()->getId() );
        $TempLate->assign("User", $Value);
        $TempLate->render();      
    }
    
    
    
    
    public function showUserEdit( $ErrorString = "" )
    {
        $this->checkLogin();
        $Request = new Request();
        $TempLate = Template::getInstance( "tpl_EditUserSeller.php" );
        $TempLate->assign( "Subnavi" , ADMIN_MENU_ACCOUNT );
        
        //var_dump($this->getUser());
        /*$UserFinder = new UserFinder();
        $User = $UserFinder->findById( Controler_Main::getInstance()->getUser()->getId() ); // den user eingeben*/
        $TempLate->assign("User", $this->getUser() );
        $TempLate->render();      
    }
    
    
    public function getYearCalenderData()
    {
        $this->checkLogin();
        $Request = new Request();
        
        $Ids = $Request->getAsString("IdArray");
        $IdArray = array(); 
        if(  strlen($Ids) > 0)
        {
            $IdArray = explode(",", $Ids);
        }
        
        
        $OrderFinder = new OrderFinder();
        
        //var_dump($IdArray);
        
        if(count ( $IdArray ) == 0 )
        {
            $OrderCollection = $OrderFinder->findFromUserByUserId( Controler_Main::getInstance()->getUser() );
        } else 
        {
            $OrderCollection = $OrderFinder->findFromUserByUserIdAndRoomId( Controler_Main::getInstance()->getUser(), $IdArray );
        }
        
        $Return = array();
        foreach($OrderCollection as $Order )
        {
            $Temp = new stdClass();
            
            $Temp->id = $Order->getId();
            $Temp->name = $Order->getRoomName() . " - " . $Order->getName();
            $Temp->location = $Order->getAdress();
            $Temp->startDate = $Order->getStartDay();
            $Temp->endDate = $Order->getEndDay();
            $Return[] = $Temp;
        }
        
        $TempLate = Template::getInstance( "" );
        $TempLate->outputJSON( 0, $Return );
    }
    
    public function createUser($ErrorString = "")
    {
        $Request = new Request();
        $User = User::getEmptyInstance();
        $User->setValuesFromArray( $Request->getAllPost() );
        $UserManager = new UserManager();

        $User->cryptPass();
        $User->setCreateDate(time());
        $UserManager->insertUser($User);
        $UserId = $UserManager->getLastInsertId();

        $TempLate = Template::getInstance("");

        // den User Einloggen
        
        
        
        $Request->setPost("tb_Name", $User->getMail());
        $Request->setPost("tb_Pass", $Request->getAsString("tb_Pass"));
        //exit("Hallo");
        $this->userLogin();
        $TempLate->outputJSON(0, $UserId);
        // den User Einloggen 
    }

    public function showLogin()
    {
        $Request = new Request();
        $TempLate = Template::getInstance("tpl_Login.php");
		
		$UserFinder = new UserFinder();
		$UserCollection = $UserFinder->findAll();
		$TempLate->assign( "UserCollection" , $UserCollection );
		
		//var_dump( $UserCollection ); exit();
		
		
		
        $TempLate->render();
    }



    /**
     * prüft ob die eingegebene Mail im filter ist wenn ja wird false zurück gegeben
     *
     * @return bool This is the return value description
     *
     */
    public function isMailCorrect($Mail)
    {
        $MailArray = explode(",", EMAIL_FILTER);

        foreach ( $MailArray as $Filter )
        {
            if ( strpos($Mail, $Filter) > 0 || strpos($Mail, $Filter) === 0 )
            {
                return false;
            }
        }
        return true;
    }

    public function userLogin()
    {
        $Request = new Request();
        //$this->Template->addHeader("Access-Control-Allow-Origin", '*');
        $this->TempLate->addHeader("Access-Control-Allow-Headers:Content-Type");
        $this->TempLate->addHeader("Access-Control-Allow-Methods:POST, GET");
        
        $UserFinder = new UserFinder();
		$Ip = $_SERVER['REMOTE_ADDR'];
        $Browser = $_SERVER['HTTP_USER_AGENT'];
        
        /*$Temp =  trim( $Request->getAsString("tb_Pass"));
        var_dump( $Temp );
        var_dump( md5($Temp));*/
		
		$BruteForceAttack = $this->checkIfBruteForceAttack($Ip, $Browser);
        if($BruteForceAttack) {
            $AjaxResponse = "Sie haben die maximale Anzahl an Login-Versuchen überschritten. Bitte warten Sie 30 Minuten und versuchen Sie es danach erneut.";
            $this->TempLate->outputJSON(1, $AjaxResponse);
            return false;
        }
		
		
        
        $User = $UserFinder->findByNameAndPass($Request->getAsString("tb_Name"), md5($Request->getAsString("tb_Pass")));
        
        if ( $User->getId() == 0 )
        {
            //$this->showLogin();
            /*if ( !$_SESSION[ 'BadLogin' ] )
            {
                $_SESSION[ 'BadLogin' ] = 1;
            }
            else
            {
                $_SESSION[ 'BadLogin' ] ++;
            }*/
			$this->registerLoginAttempt( "" , 0 );
            $this->TempLate->outputJSON( 1, "Login fehler Benutzer wurde nicht gefunden");
            return false;
        }
        $_SESSION[ 'UserId' ] = $User->getId();
        $_SESSION[ 'UserName' ] = $Request->getAsString("tb_Name");
        $_SESSION[ 'UserPass' ] = md5($Request->getAsString("tb_Pass"));


/*
        if ( $User->getLocked() )
        {   // der User ist gesperrt und darf sich nicht einloggen
            $TempLate = Template::getInstance("tpl_Login.php");
            //$TempLate->renderError("Fehler",":T_LOGIN_ERROR1:","index.php");
            $this->TempLate->outputJSON(1, "Login fehler Ihr account wurde gesperrt!");
            return false;
        }*/

        Controler_Main::getInstance()->setUser( $User );
        $UserManager = new UserManager();

        $this->TempLate->outputJSON( 0, "Login erfolgreich", $User );
		$this->registerLoginAttempt( $User->getName() , 1 );
        return;
    }
	
	private function registerLoginAttempt($UserName, $LoginSuccess) {

        $UserFinder = new UserFinder();


        $User = $UserFinder->findByName($UserName)->getByIndex(0);
        

        // falls User
        if($User->getId() != 0) {
            $UserId = $User->getId();
            $UserTable = "tbl_user";
        }  else
        // falls nichts
        {
            $UserId = 0;
            $UserTable = "-";
        }

        $Login = Login::getEmptyInstance();

        $Login->setUserId($UserId);
        $Login->setUserTable($UserTable);
        $Login->setIp($_SERVER["REMOTE_ADDR"]);
        $Login->setBrowser($_SERVER["HTTP_USER_AGENT"]);
        $Login->setUserName($UserName);
        $Login->setLoginSuccess($LoginSuccess);
        
        $LoginManager = new LoginManager();
        $LoginManager->insertLogin($Login);

    }
	
	
	
	private function checkIfBruteForceAttack($Ip, $Browser){
        $LoginFinder = new LoginFinder();
        $RecentLoginAttempts = $LoginFinder->getRecentLoginAttempts($Ip, $Browser);

        if($RecentLoginAttempts->getCount() >= 10) {
            Controler_Mail::sendBruteForceNotice( $RecentLoginAttempts );
            return 1;
        }
        return 0;
    }
	

    public function userLogout()
    {
		//var_dump( $_SESSION );
        $UserManager = new UserManager();
        $User = Controler_Main::getInstance()->getUser();
        $_SESSION[ 'UserId' ] = "";
        unset($_SESSION[ 'DataBase' ]); // server vari entfernen
        unset($_SESSION[ 'UserId' ]);
        unset($_SESSION[ 'BadLogin' ]);
        unset($_SESSION[ 'UserName' ]);
        unset($_SESSION[ 'UserPass' ]);
        @session_destroy();
        $this->showLogin();
    }

}
?>