<?php

/**
 * class cls_Controler_Click.
 *
 * Description for class cls_Controler_Click
 *
 * @author:
 */
class Controler_Value extends Controler
{
    /**
     * cls_Controler_Click constructor.
     *
     * @param
     */
    public function __construct()
    {
        parent::__construct();
        $this->checkLogin();
        $this->TempLate = Template::getInstance();
    }

    public function start()
    {
        $Request = new Request();
        //var_dump($Request->getAsString('Action'));
        
        //var_dump( $Request->getAsString('Action') );
		//var_dump( $Request->getAsString('Table') );
        switch ($Request->getAsString('Action')) {
            case 'UpdateValues':

                    $this->updateTableValue();
                 break;

            case 'ShowCreate':

                    $this->showCreate();
                 break;

            case 'ShowUpdate':

                    $this->showUpdate();
                 break;

            case 'ShowObject':

                    $this->showObject();
                 break;

            case 'GetAll':

                    $this->getAll();
                 break;

            case 'DeleteElement':

                    $this->deleteElement();
                 break;

            case 'ShowManage':
                $this->showManage();
                break;
            
            
            case 'DownLoadCSV':
                $this->downLoadCSV();
                break;

            default:
                
                
              
            $Action  = $Request->getAsString('Action');

            if( strpos($Action, "Get") !== false && !method_exists( $this, $Request->getAsString('Action') ))
            {

                $this->getObject();   
            }
            
            if( strpos($Action, "Manage") !== false && !method_exists( $this, $Action ))
            {
                $this->manageObject();
                return;
            }
                
                
            if(method_exists( $this, $Action ))
            {
                $this->$Action();
            }
            
            
            
        }
    }

    
    public function manageObject()
    {
        //var_dump("jo");
        $Request = new Request();
        $Template = Template::getInstance("objects/tpl_Manage.php");
        $Action  = $Request->getAsString('Action');
        $IdSearch = $Request->getAsBool('IdSearch');
        $Action = strtolower($Action);
        $ObjectName = str_replace( "manage", "", $Action );
        $ObjectName = ucfirst( $ObjectName );
        $Template->assign("Entity", $ObjectName);
        $Template->assign("Object", $ObjectName::getEmptyInstance());
        $Template->render();
    }
    
    
    
    public function getHoliday()
    {
        $Request = new Request();
        $Template = Template::getInstance();
        $Action  = $Request->getAsString('Action');
        $IdSearch = $Request->getAsBool('IdSearch');
        
        $HolidayFinder = new HolidayFinder();
        
        $ObjectCollection = $HolidayFinder->findByValue( $Request->getAsString( 'Data' ) );

        $Template->outputJSON(1, 'ok', $ObjectCollection );
        
    }
    
    private function downLoadCSV()
    {
        $Request = new Request();
        $Template = Template::getInstance();
        $Action  = $Request->getAsString('Action');
        $ObjectName = $Request->getAsString('Table');
        $ClassName = $ObjectName.'Finder';
        try
        {
            $Finder = new $ClassName();
        } catch( Exception $e )
        {
             $Template->outputJSON( 0, 'No Object' );
             return;
        }
        
        $ElementCollection = $Finder->findAll();

        $Template->outPutArrayCsv( $ElementCollection->toArray(), $ObjectName . "-" . date("d.m.y") . ".csv");
    }
    
        /**
     * gibt ein Object aus dem System zurück
     * Diese Funktion muss zusätzlich abgesichert werden
     */
    private function getObject()
    {
        $Request = new Request();
        $Template = Template::getInstance();
        $Action  = $Request->getAsString('Action');
        $IdSearch = $Request->getAsBool('IdSearch');
        $ObjectName = str_replace("Get", "", $Action );
        
        $ClassName = $ObjectName.'Finder';
        try{
            $Finder = new $ClassName();
        } catch( Exception $e )
        {
             $Template->outputJSON(0, 'No Object');
             return;
        }

        if($IdSearch)
        {
            $ObjectCollection = $Finder->findByIdArray( $Request->getAsArray( 'Data' ) );
        } else 
        {
            $ObjectCollection = $Finder->findByValue( $Request->getAsString( 'Data' ) );
        }
        $Template->outputJSON(1, 'ok', $ObjectCollection );
    }
    
	
	public function getUser()
    {
		$Request = new Request();
        $Template = Template::getInstance();
        $Action  = $Request->getAsString('Action');
        $IdSearch = $Request->getAsBool('IdSearch');
        $ObjectName = str_replace("Get", "", $Action );
        
        $ClassName = $ObjectName.'Finder';
        try{
            $Finder = new $ClassName();
        } catch( Exception $e )
        {
             $Template->outputJSON(0, 'No Object');
             return;
        }

        if($IdSearch)
        {
            $ObjectCollection = $Finder->findByIdArray( $Request->getAsArray( 'Data' ) );
        } else 
        {
            $ObjectCollection = $Finder->findByValueSorted( $Request->getAsString( 'Data' ) );
        }
        $Template->outputJSON(1, 'ok', $ObjectCollection );
    }
	
	
    
    public function DeleteElement($ErrorString = '')
    {
        $Request = new Request();

        $Id = $Request->getAsInt('Id');
        $Table = $Request->getAsString('Table');

        // Abfrage, ob eingelogt ist!
        $ClassName = $Table.'Manager';
        $Manager = new $ClassName();
        $Object = $Table::getEmptyInstance();
        $Object->setId($Id);
        //var_dump($Table);
        //$Manager->deleteStudent($Object);

        $Manager->{'delete'.$Table}($Object);
        //var_dump($Object);
        // prüfen ob es den Datensatz gibt
        $TempLate = Template::getInstance('objects/tpl_'.$Table.'.php');
        $TempLate->outputJSON(0, 'Deleted');
        //echo "objects/tpl_" . $Table . ".php";
        //$TempLate->render();
        // wenn ID Gesetzt dann update ansonsten insert.
        //$TempLate->outputJSON(1,"");      // 1 wenn alles klar gegangen ist.
    }
	
	
	public function deactivateElement($ErrorString = '')
    {
        $Request = new Request();
        $Id = $Request->getAsInt('Id');
        $Table = $Request->getAsString('Table');
		if( $Table != "User") {
			$TempLate->outputJSON(1, 'Only User Can set deactiveted');
			return;
		}

        // Abfrage, ob eingelogt ist!
        $ClassName = $Table.'Manager';
        $Manager = new $ClassName();
        $Object = $Table::getEmptyInstance();
		
		$ClassName = $Table.'Finder';
		$Finder = new $ClassName();
		$Object = $Finder->findById( $Id );
		
        //$Object->setId($Id);
        //var_dump($Table);
        //$Manager->deleteStudent($Object);
		$Object->setActive(0);

        $Manager->{'update'.$Table}($Object);
		
		//var_dump( $Table  ); exit();
		
		if( $Table = "User") 
		{

			$TypeArray = array("","user", "packer", "drucker" , "einsteller" , "oberdrucker"  , "schichtleiter"  , "supervisor");	
			$LevelString = $TypeArray[ $Object->getType() ];
			// im esb deaktivieren
			$PdoDataBase = PdoDataBase::getInstance();
			$PdoDataBase->loadJsonConfig("cfg.esb.json"); // der macht auch gleich close und neu connect
			
			//var_dump( $Id ); exit();
			
			// über den usermanager den user aktualisieren
			if( $Id )
			{
				$UserManager = new userManager();
				return $UserManager->updateEsbUser( 
					$Id,
					$Object->getName(),
					"",
					$Object->getMail(),
					$Object->getMailCC(),
					$Object->getAdName(),
					$Object->getActive(),
					$LevelString,
					$Object->getErrorReporter()
				);
			}


		}
		
		
        //var_dump($Object);
        // prüfen ob es den Datensatz gibt
        $TempLate = Template::getInstance('objects/tpl_'.$Table.'.php');
        $TempLate->outputJSON(0, 'deactivated');
        //echo "objects/tpl_" . $Table . ".php";
        //$TempLate->render();
        // wenn ID Gesetzt dann update ansonsten insert.
        //$TempLate->outputJSON(1,"");      // 1 wenn alles klar gegangen ist.
    }
	
	
	

    public function showCreate($ErrorString = '')
    {
        $Request = new Request();
        $Table = $Request->getAsString('Table');
        // prüfen ob es den Datensatz gibt
		
		//var_dump("Test");
		
		
		/*$TempLate = Template::getInstance('tpl_HeaderStart.php');
		$TempLate->render();*/
		

		
		
        $Template = Template::getInstance('objects/tpl_'.$Table.'.php');
        // anhand von $Table die Collections für die Filter ins Template laden
        //echo "objects/tpl_" . $Table . ".php";
        $Template->render();
        // wenn ID Gesetzt dann update ansonsten insert.
        //$TempLate->outputJSON(1,"");      // 1 wenn alles klar gegangen ist.
    }

    public function showObject($ErrorString = '')
    {
        $Request = new Request();
//        $Table = $Request->getAsString("Table");
        $Id = $Request->getAsInt('Id');
        $Table = $Request->getAsString('Table');
        // prüfen ob es den Datensatz gibt
        $Template = Template::getInstance('objects/tpl_Show'.$Table.'.php');

        $ClassName = $Table.'Finder';
        $Finder = new $ClassName();
        $Object = $Finder->findById($Id);

        $Template->assign('Object', $Object);
	
		if($Table  == "User")
		{
			$PlanningentryFinder = new PlanningentryFinder();
			$PlanningentryCollection = $PlanningentryFinder->findByUserIdUpToDate( $Object->getId() );
			$Template->assign( "PlanningentryCollection" , $PlanningentryCollection );
			
					$PlaningtemplateFinder = new PlaningtemplateFinder();
		$PlaningtemplateCollection = $PlaningtemplateFinder->findAll();
		$Template->assign( "PlaningtemplateCollection" , $PlaningtemplateCollection );
		
		$PlaningtemplateentrytypeFinder = new PlaningtemplateentrytypeFinder();
		$PlaningtemplateentrytypeCollection = $PlaningtemplateentrytypeFinder->findAll();
		$Template->assign( "PlaningtemplateentrytypeCollection" , $PlaningtemplateentrytypeCollection );
			
			
		}
	
	
		
        //echo "objects/tpl_" . $Table . ".php";
        $Template->render();

        // wenn ID Gesetzt dann update ansonsten insert.
        //$TempLate->outputJSON(1,"");      // 1 wenn alles klar gegangen ist.
    }

    public function showUpdate($ErrorString = '')
    {
		
        $Request = new Request();
        $Id = $Request->getAsInt('Id');
        $Action = $Request->getAsString('Action');

        $Table = $Request->getAsString('Table');

        // prüfen ob es den Datensatz gibt
		
		
		$TempLate = Template::getInstance('tpl_HeaderStart.php');
		$TempLate->render();
		
        $TempLate = Template::getInstance('objects/tpl_'.$Table.'.php');

        //echo "objects/tpl_" . $Table . ".php";
        $ClassName = $Table.'Finder';
        $Finder = new $ClassName();
        $Object = $Finder->findById($Id);

        $TempLate->assign('JsonData', $Object->toJson());
        $TempLate->assign('Action', $Action);

        $TempLate->render();

        // wenn ID Gesetzt dann update ansonsten insert.
        //$TempLate->outputJSON(1,"");      // 1 wenn alles klar gegangen ist.
    }

    public function updateTableValue($ErrorString = '')
    {
        $Request = new Request();
        $TempLate = Template::getInstance();

        $Post = $Request->getAllPost();
        $Table = $Request->getAsString('Table');

        $Object = $Table::getEmptyInstance();
        $Object->setValuesFromArray($Post);
        $ElementId = $Request->getAsInt('tb_Id');
        if ( $ElementId ) 
        { // wenn ein element bearbeitet wird
            $ClassName = $Table.'Finder';
            $Finder = new $ClassName();
            $DataBaseElement = $Finder->findById( $ElementId );
        }
        // nach Files Gucken und Diese zurück geben

        $Files = $Request->getAllFiles();
        foreach ($Files as  $Key => $File) 
        {
            if (!$File) 
            {
                $Object->{'set'.$Key}('');
                if ($ElementId) 
                {
                    $Object->{'set'.$Key}($DataBaseElement->{'get'.$Key}());
                }
                continue;
            }
            // base64_decode( $File);
            $Path = USER_FILES.'/';
            //var_dump($Key);
            switch ($Key) 
            {
                case 'StudentPicture':
                    $Folder = $Path.$Key.'/'.substr($Post['LastName'], 0, 3);
                    if (!is_dir($Folder)) 
                    {
                        mkdir($Folder);
                    }

                    $Path .= $Key.'/'.substr($Post['LastName'], 0, 3).'/'.$Post['FirstName'].time().'.jpg';
                    // var_dump($Path);
                    break;
                default:
                    if (!is_dir($Path.$Key)) 
                    {
                        mkdir($Path.$Key);
                    }
                    $Path .= $Key.'/'.(count(scandir($Path.$Key)) - 2).'.jpg';
            }

            file_put_contents($Path, base64_decode($File));
            // den filepath in das Objekt setzen
            $Object->{'set'.$Key}($Path);
        }

        if ($Request->getAsString('tb_Pass', true)) 
        {
            $Object->{'setPass' }(md5($Request->getAsString('tb_Pass')));
        } else {
            if ($ElementId && method_exists($Object, 'setPass')) {
                $Object->setPass($DataBaseElement->getPass());
            }
        }

        $ClassName = $Table.'Manager';
        $Manager = new $ClassName();
        $LastId = 0;
        if ($ElementId) {
            $Manager->{'update'.$Table}($Object);
            $LastId = $Object->getId();
        } else {
            $Manager->{'insert'.$Table}($Object);
            $LastId = $Manager->getLastInsertId();
        }
		
		switch ($Table)
		{
			case "User":
			//$this->updateUser();
			break;
			
		}
		
		$Action = "update".$Table;
		$Result = "";
		if( method_exists( $this, $Action ))
        {
			$Result = $this->$Action();
        }

        // wenn ID Gesetzt dann update ansonsten insert.
        $TempLate->outputJSON( 1, $LastId, $Result );      // 1 wenn alles klar gegangen ist.
    }

	/*
	hier werden Anpassungen gemacht
	*/
	private function updateUser()
	{
		// var_dump( "Update der daten im ESB" );
		$Request = new Request();

        $Post = $Request->getAllPost();
		
		// var_dump( $Post ); exit();
		
		$TypeArray = array("","user", "packer", "drucker" , "einsteller" , "oberdrucker"  , "schichtleiter"  , "supervisor");	
		$LevelString = $TypeArray[ $Post["Type"] ];
		
		
		if( !$Post['Id'] )
		{
			$UserManager = new userManager();
			$NewId = $UserManager->getLastInsertId(); // die Id aus der db holen
			// var_dump( $NewId );  exit();
			
			$PdoDataBase = PdoDataBase::getInstance();
			$PdoDataBase->loadJsonConfig("cfg.esb.json");
			
			$UserManager = new userManager();
			
			
			return $UserManager->insertEsbUser( 
				$NewId,
				$Post["Name"],
				$Post["Pass"],
				$Post["Mail"],
				$Post["MailCC"],
				$Post["AdName"],
				$Post["Active"],
				$Post["Type"],
				$LevelString,
				$Post["ErrorReporter"]
			);
			return ;
			
		}
		
		
		
		
		//include "cfg/cfg.esb.php"; // die neue esb config laden
		
		$PdoDataBase = PdoDataBase::getInstance();
		$PdoDataBase->loadJsonConfig("cfg.esb.json"); // der macht auch gleich close und neu connect
		
		
		
		// über den usermanager den user aktualisieren
		if($Post['Id'])
		{
			$UserManager = new userManager();
			return $UserManager->updateEsbUser( 
				$Post["Id"],
				$Post["Name"],
				$Post["Pass"],
				$Post["Mail"],
				$Post["MailCC"],
				$Post["AdName"],
				$Post["Active"],
				$LevelString,
				$Post["ErrorReporter"]
			);
		} else 
		{
			// den neu  Angelegten nutzer suchen und  in die ESb db schicken	
				
				
		}
		
		
		
		
	}
	
	
	
	
	
    public function getAll()
    {
        $Request = new Request();
        $Template = Template::getInstance();

        $UniverasalCollection = new UniversalCollection();
        // hier mkönnen die enditäten zur universellen Collection hinzugefügt werden
        $Template->outputJSON(1, 'ok', $UniverasalCollection);
    }

    
}