<?php

function myAutoload( $Class )
{
    $BasicInclueConst = Basic_include_const::getInstance();
    if (isset( $BasicInclueConst->PathArray[ $Class ] ) && file_exists( $BasicInclueConst->PathArray[ $Class ] ) )
    {
        try
        {
            require_once $BasicInclueConst->PathArray[ $Class ];
        } catch (Exception $e)
        {
            echo 'Datei konnte nicht gefunden werden: ' . $Class . "<br />\n";
        }
    } else
    {
        echo 'Eine Include-Datei wurde nicht gefunden: ' . $Class . " Datei wurde ausgelassen!<br />\n";
    }
}


spl_autoload_register('myAutoload');

class Basic_include_const
{

    public $PathArray = null;
    private static $Instance = null;

    private function __construct()
    {
        $this->createPathArray();
		
		define("CLI_MODE", $this->isCommandLineInterface()); 
		
		
    }

    public static function getInstance()
    {
        {
            if ( self::$Instance === NULL )
            {
                self::$Instance = new Basic_include_const;
            }

            return self::$Instance;
        }
    }
	
	public function isCommandLineInterface()
	{
		if ( php_sapi_name() === 'cli' )
		{
			return true;
		}

		if ( array_key_exists('SHELL', $_ENV) ) {
			return true;
		}

		if ( empty($_SERVER['REMOTE_ADDR']) and !isset($_SERVER['HTTP_USER_AGENT']) and count($_SERVER['argv']) > 0) 
		{
			return true;
		} 

		if ( !array_key_exists('REQUEST_METHOD', $_SERVER) )
		{
			return true;
		}

		return false;
	}
	
	
	
	/**
	* lädt all import dateien
	*
	*/  
	public function loadAll( $FilePath )
	{
		echo "Lade System " . $FilePath . "\n";
		define("SYSTEM_PATH", $FilePath ) ; 
		chdir( $Path ); // damit alles geladen werden kann
		foreach($this->PathArray as $Path )
		{
			echo "Import >> " . $FilePath . "/" . $Path  . "\n";
			require_once( $FilePath . "/" . $Path );
		}
	}
	
	

    private function createPathArray()
    {
        $this->PathArray[ 'i_CollectionElement' ] = 'class/objects/i_CollectionElements.php';
        $this->PathArray[ 'Request' ] = 'class/logic/cls_Request.php';
		$this->PathArray[ 'AbstractDatabase' ] = 'class/db/cls_abstractDb.php';
        $this->PathArray[ 'PdoDataBase' ] = 'class/db/cls_dbPdo.php';
        
        $this->PathArray[ 'Logger' ] = 'class/lib/cls_Logger.php';
        $this->PathArray[ 'SqlLogger' ] = 'class/lib/cls_Logger.php';
        $this->PathArray[ 'ErrorLogger' ] = 'class/lib/cls_Logger.php';
        $this->PathArray[ 'DebugLogger' ] = 'class/lib/cls_Logger.php';
        $this->PathArray[ 'dbUpdateLogger' ] = 'class/lib/cls_Logger.php';
        $this->PathArray[ 'EmptyLogger' ] = 'class/lib/cls_Logger.php';
        #region Controler Objekte

        $this->PathArray[ 'Controler' ] = 'class/logic/cls_Controler.php';
        $this->PathArray[ 'Controler_Login' ] = 'class/logic/cls_Controler_Login.php';
        $this->PathArray[ 'Controler_Main' ] = 'class/logic/cls_Controler_Main.php';
        $this->PathArray[ 'Controler_Start' ] = 'class/logic/cls_Controler_Start.php';
        $this->PathArray[ 'Controler_Mail' ] = 'class/logic/cls_Controler_Mail.php';
		$this->PathArray[ 'Controler_Value' ] = 'class/logic/cls_Controler_Value.php';
		$this->PathArray[ 'Controler_Planing' ] = 'class/logic/cls_Controler_Planing.php';
		$this->PathArray[ 'Controler_Api' ] = 'class/logic/cls_Controler_Api.php';
		$this->PathArray[ 'Controler_Holiday' ] = 'class/logic/cls_Controler_Holiday.php';
		
		
		
		
        // $this->PathArray[ 'Logger' ] = 'class/objects/cls_Logger.php';
        // $this->PathArray[ 'Image' ] = 'class/objects/cls_Image.php';
        // $this->PathArray[ 'Dir' ] = 'class/objects/cls_Dir.php';
		$this->PathArray[ 'Essel' ] = 'class/lib/cls_Essel.php';
		
		
		
		
        #endregion

        $this->PathArray[ 'SystemFinder' ] = 'class/DatabaseObjects/cls_SystemFinder.php';

        $this->PathArray[ 'SystemManager' ] = 'class/DatabaseObjects/cls_SystemManager.php';
        $this->PathArray[ 'Collection' ] = 'class/objects/cls_AbstractCollection.php';
        //$this->PathArray[ 'ParseAbleObject' ] = 'class/objects/cls_ParseAbleObject.php'; //parse object

        $this->PathArray[ 'Template' ] = 'class/lib/cls_Template.php';
        $this->PathArray[ 'Date' ] = 'class/lib/cls_Date.php';
		$this->PathArray[ 'MyDateTime' ] = 'class/lib/cls_MyDateTime.php';
		
		
		

        $this->PathArray[ 'Convert' ] = 'class/objects/cls_Convert.php';
		$this->PathArray[ 'BaseUser' ] = 'class/objects/base/cls_BaseUser.php';
        $this->PathArray[ 'User' ] = 'class/objects/cls_User.php';
		$this->PathArray[ 'BaseUserCollection' ] = 'class/objects/base/cls_BaseUserCollection.php';
        $this->PathArray[ 'UserCollection' ] = 'class/objects/cls_UserCollection.php';
        
        
		
		$this->PathArray[ 'BaseUserFinder' ] = 'class/DatabaseObjects/base/cls_BaseUserFinder.php';
        $this->PathArray[ 'BaseUserManager' ] = 'class/DatabaseObjects/base/cls_BaseUserManager.php';
		
        $this->PathArray[ 'UserFinder' ] = 'class/DatabaseObjects/cls_UserFinder.php';
        $this->PathArray[ 'UserManager' ] = 'class/DatabaseObjects/cls_UserManager.php';



        
        $this->PathArray['Convert'] = 'class/lib/cls_Convert.php';
        $this->PathArray['Utility'] = 'class/lib/cls_Utility.php';
        //$this->PathArray['Minify'] = 'class/lib/cls_Minify.php';
        $this->PathArray['Cache'] = 'class/lib/cls_Cache.php';
        $this->PathArray['EmptyCache'] = 'class/lib/cls_Cache.php';
        $this->PathArray['Request'] = 'class/lib/cls_Request.php';
        // $this->PathArray['BillPdf'] = 'class/lib/cls_BillPdf.php';
        // $this->PathArray['FPDF'] = 'modules/fpdf/fpdf.php';
		
		$this->PathArray['PHPMailer']='modules/PHPMailer/class.phpmailer.php';
        $this->PathArray['smtp']='modules/PHPMailer/class.smtp.php';
        $this->PathArray['POP3']='modules/PHPMailer/class.pop3.php';
		
    }

    public function addPath($Name, $Path)
    {
        $this->PathArray[$Name] = $Path;
    }
}

Basic_include_const::getInstance()->addPath('SickdaysManager','class/DatabaseObjects/cls_SickdaysManager.php');
Basic_include_const::getInstance()->addPath('BaseSickdaysManager','class/DatabaseObjects/base/cls_BaseSickdaysManager.php');
Basic_include_const::getInstance()->addPath('SickdaysFinder','class/DatabaseObjects/cls_SickdaysFinder.php');
Basic_include_const::getInstance()->addPath('BaseSickdaysFinder','class/DatabaseObjects/base/cls_BaseSickdaysFinder.php');
Basic_include_const::getInstance()->addPath('SickdaysCollection','class/objects/cls_SickdaysCollection.php');
Basic_include_const::getInstance()->addPath('BaseSickdaysCollection','class/objects/base/cls_BaseSickdaysCollection.php');
Basic_include_const::getInstance()->addPath('Sickdays','class/objects/cls_Sickdays.php');
Basic_include_const::getInstance()->addPath('BaseSickdays','class/objects/base/cls_BaseSickdays.php');
Basic_include_const::getInstance()->addPath('HolidaysManager','class/DatabaseObjects/cls_HolidaysManager.php');
Basic_include_const::getInstance()->addPath('BaseHolidaysManager','class/DatabaseObjects/base/cls_BaseHolidaysManager.php');
Basic_include_const::getInstance()->addPath('HolidaysFinder','class/DatabaseObjects/cls_HolidaysFinder.php');
Basic_include_const::getInstance()->addPath('BaseHolidaysFinder','class/DatabaseObjects/base/cls_BaseHolidaysFinder.php');
Basic_include_const::getInstance()->addPath('HolidaysCollection','class/objects/cls_HolidaysCollection.php');
Basic_include_const::getInstance()->addPath('BaseHolidaysCollection','class/objects/base/cls_BaseHolidaysCollection.php');
Basic_include_const::getInstance()->addPath('Holidays','class/objects/cls_Holidays.php');
Basic_include_const::getInstance()->addPath('BaseHolidays','class/objects/base/cls_BaseHolidays.php');
Basic_include_const::getInstance()->addPath('MaschineManager','class/DatabaseObjects/cls_MaschineManager.php');
Basic_include_const::getInstance()->addPath('BaseMaschineManager','class/DatabaseObjects/base/cls_BaseMaschineManager.php');
Basic_include_const::getInstance()->addPath('MaschineFinder','class/DatabaseObjects/cls_MaschineFinder.php');
Basic_include_const::getInstance()->addPath('BaseMaschineFinder','class/DatabaseObjects/base/cls_BaseMaschineFinder.php');
Basic_include_const::getInstance()->addPath('MaschineCollection','class/objects/cls_MaschineCollection.php');
Basic_include_const::getInstance()->addPath('BaseMaschineCollection','class/objects/base/cls_BaseMaschineCollection.php');
Basic_include_const::getInstance()->addPath('Maschine','class/objects/cls_Maschine.php');
Basic_include_const::getInstance()->addPath('BaseMaschine','class/objects/base/cls_BaseMaschine.php');
Basic_include_const::getInstance()->addPath('PlaningManager','class/DatabaseObjects/cls_PlaningManager.php');
Basic_include_const::getInstance()->addPath('BasePlaningManager','class/DatabaseObjects/base/cls_BasePlaningManager.php');
Basic_include_const::getInstance()->addPath('PlaningFinder','class/DatabaseObjects/cls_PlaningFinder.php');
Basic_include_const::getInstance()->addPath('BasePlaningFinder','class/DatabaseObjects/base/cls_BasePlaningFinder.php');
Basic_include_const::getInstance()->addPath('PlaningCollection','class/objects/cls_PlaningCollection.php');
Basic_include_const::getInstance()->addPath('BasePlaningCollection','class/objects/base/cls_BasePlaningCollection.php');
Basic_include_const::getInstance()->addPath('Planing','class/objects/cls_Planing.php');
Basic_include_const::getInstance()->addPath('BasePlaning','class/objects/base/cls_BasePlaning.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateentryManager','class/DatabaseObjects/cls_PlaningtemplateentryManager.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentryManager','class/DatabaseObjects/base/cls_BasePlaningtemplateentryManager.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateentryFinder','class/DatabaseObjects/cls_PlaningtemplateentryFinder.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentryFinder','class/DatabaseObjects/base/cls_BasePlaningtemplateentryFinder.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateentryCollection','class/objects/cls_PlaningtemplateentryCollection.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentryCollection','class/objects/base/cls_BasePlaningtemplateentryCollection.php');
Basic_include_const::getInstance()->addPath('Planingtemplateentry','class/objects/cls_Planingtemplateentry.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentry','class/objects/base/cls_BasePlaningtemplateentry.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateentrytypeManager','class/DatabaseObjects/cls_PlaningtemplateentrytypeManager.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentrytypeManager','class/DatabaseObjects/base/cls_BasePlaningtemplateentrytypeManager.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateentrytypeFinder','class/DatabaseObjects/cls_PlaningtemplateentrytypeFinder.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentrytypeFinder','class/DatabaseObjects/base/cls_BasePlaningtemplateentrytypeFinder.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateentrytypeCollection','class/objects/cls_PlaningtemplateentrytypeCollection.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentrytypeCollection','class/objects/base/cls_BasePlaningtemplateentrytypeCollection.php');
Basic_include_const::getInstance()->addPath('Planingtemplateentrytype','class/objects/cls_Planingtemplateentrytype.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateentrytype','class/objects/base/cls_BasePlaningtemplateentrytype.php');
Basic_include_const::getInstance()->addPath('UserManager','class/DatabaseObjects/cls_UserManager.php');
Basic_include_const::getInstance()->addPath('BaseUserManager','class/DatabaseObjects/base/cls_BaseUserManager.php');
Basic_include_const::getInstance()->addPath('UserFinder','class/DatabaseObjects/cls_UserFinder.php');
Basic_include_const::getInstance()->addPath('BaseUserFinder','class/DatabaseObjects/base/cls_BaseUserFinder.php');
Basic_include_const::getInstance()->addPath('UserCollection','class/objects/cls_UserCollection.php');
Basic_include_const::getInstance()->addPath('BaseUserCollection','class/objects/base/cls_BaseUserCollection.php');
Basic_include_const::getInstance()->addPath('User','class/objects/cls_User.php');
Basic_include_const::getInstance()->addPath('BaseUser','class/objects/base/cls_BaseUser.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateManager','class/DatabaseObjects/cls_PlaningtemplateManager.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateManager','class/DatabaseObjects/base/cls_BasePlaningtemplateManager.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateFinder','class/DatabaseObjects/cls_PlaningtemplateFinder.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateFinder','class/DatabaseObjects/base/cls_BasePlaningtemplateFinder.php');
Basic_include_const::getInstance()->addPath('PlaningtemplateCollection','class/objects/cls_PlaningtemplateCollection.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplateCollection','class/objects/base/cls_BasePlaningtemplateCollection.php');
Basic_include_const::getInstance()->addPath('Planingtemplate','class/objects/cls_Planingtemplate.php');
Basic_include_const::getInstance()->addPath('BasePlaningtemplate','class/objects/base/cls_BasePlaningtemplate.php');
Basic_include_const::getInstance()->addPath('PlanningentryManager','class/DatabaseObjects/cls_PlanningentryManager.php');
Basic_include_const::getInstance()->addPath('BasePlanningentryManager','class/DatabaseObjects/base/cls_BasePlanningentryManager.php');
Basic_include_const::getInstance()->addPath('PlanningentryFinder','class/DatabaseObjects/cls_PlanningentryFinder.php');
Basic_include_const::getInstance()->addPath('BasePlanningentryFinder','class/DatabaseObjects/base/cls_BasePlanningentryFinder.php');
Basic_include_const::getInstance()->addPath('PlanningentryCollection','class/objects/cls_PlanningentryCollection.php');
Basic_include_const::getInstance()->addPath('BasePlanningentryCollection','class/objects/base/cls_BasePlanningentryCollection.php');
Basic_include_const::getInstance()->addPath('Planningentry','class/objects/cls_Planningentry.php');
Basic_include_const::getInstance()->addPath('BasePlanningentry','class/objects/base/cls_BasePlanningentry.php');
Basic_include_const::getInstance()->addPath('CommentManager','class/DatabaseObjects/cls_CommentManager.php');
Basic_include_const::getInstance()->addPath('BaseCommentManager','class/DatabaseObjects/base/cls_BaseCommentManager.php');
Basic_include_const::getInstance()->addPath('CommentFinder','class/DatabaseObjects/cls_CommentFinder.php');
Basic_include_const::getInstance()->addPath('BaseCommentFinder','class/DatabaseObjects/base/cls_BaseCommentFinder.php');
Basic_include_const::getInstance()->addPath('CommentCollection','class/objects/cls_CommentCollection.php');
Basic_include_const::getInstance()->addPath('BaseCommentCollection','class/objects/base/cls_BaseCommentCollection.php');
Basic_include_const::getInstance()->addPath('Comment','class/objects/cls_Comment.php');
Basic_include_const::getInstance()->addPath('BaseComment','class/objects/base/cls_BaseComment.php');
Basic_include_const::getInstance()->addPath('ColorManager','class/DatabaseObjects/cls_ColorManager.php');
Basic_include_const::getInstance()->addPath('BaseColorManager','class/DatabaseObjects/base/cls_BaseColorManager.php');
Basic_include_const::getInstance()->addPath('ColorFinder','class/DatabaseObjects/cls_ColorFinder.php');
Basic_include_const::getInstance()->addPath('BaseColorFinder','class/DatabaseObjects/base/cls_BaseColorFinder.php');
Basic_include_const::getInstance()->addPath('ColorCollection','class/objects/cls_ColorCollection.php');
Basic_include_const::getInstance()->addPath('BaseColorCollection','class/objects/base/cls_BaseColorCollection.php');
Basic_include_const::getInstance()->addPath('Color','class/objects/cls_Color.php');
Basic_include_const::getInstance()->addPath('BaseColor','class/objects/base/cls_BaseColor.php');
Basic_include_const::getInstance()->addPath('DowntimesManager','class/DatabaseObjects/cls_DowntimesManager.php');
Basic_include_const::getInstance()->addPath('BaseDowntimesManager','class/DatabaseObjects/base/cls_BaseDowntimesManager.php');
Basic_include_const::getInstance()->addPath('DowntimesFinder','class/DatabaseObjects/cls_DowntimesFinder.php');
Basic_include_const::getInstance()->addPath('BaseDowntimesFinder','class/DatabaseObjects/base/cls_BaseDowntimesFinder.php');
Basic_include_const::getInstance()->addPath('DowntimesCollection','class/objects/cls_DowntimesCollection.php');
Basic_include_const::getInstance()->addPath('BaseDowntimesCollection','class/objects/base/cls_BaseDowntimesCollection.php');
Basic_include_const::getInstance()->addPath('Downtimes','class/objects/cls_Downtimes.php');
Basic_include_const::getInstance()->addPath('BaseDowntimes','class/objects/base/cls_BaseDowntimes.php');
Basic_include_const::getInstance()->addPath('HolidayplaningManager','class/DatabaseObjects/cls_HolidayplaningManager.php');
Basic_include_const::getInstance()->addPath('BaseHolidayplaningManager','class/DatabaseObjects/base/cls_BaseHolidayplaningManager.php');
Basic_include_const::getInstance()->addPath('HolidayplaningFinder','class/DatabaseObjects/cls_HolidayplaningFinder.php');
Basic_include_const::getInstance()->addPath('BaseHolidayplaningFinder','class/DatabaseObjects/base/cls_BaseHolidayplaningFinder.php');
Basic_include_const::getInstance()->addPath('HolidayplaningCollection','class/objects/cls_HolidayplaningCollection.php');
Basic_include_const::getInstance()->addPath('BaseHolidayplaningCollection','class/objects/base/cls_BaseHolidayplaningCollection.php');
Basic_include_const::getInstance()->addPath('Holidayplaning','class/objects/cls_Holidayplaning.php');
Basic_include_const::getInstance()->addPath('BaseHolidayplaning','class/objects/base/cls_BaseHolidayplaning.php');
Basic_include_const::getInstance()->addPath('LoginManager','class/DatabaseObjects/cls_LoginManager.php');
Basic_include_const::getInstance()->addPath('BaseLoginManager','class/DatabaseObjects/base/cls_BaseLoginManager.php');
Basic_include_const::getInstance()->addPath('LoginFinder','class/DatabaseObjects/cls_LoginFinder.php');
Basic_include_const::getInstance()->addPath('BaseLoginFinder','class/DatabaseObjects/base/cls_BaseLoginFinder.php');
Basic_include_const::getInstance()->addPath('LoginCollection','class/objects/cls_LoginCollection.php');
Basic_include_const::getInstance()->addPath('BaseLoginCollection','class/objects/base/cls_BaseLoginCollection.php');
Basic_include_const::getInstance()->addPath('Login','class/objects/cls_Login.php');
Basic_include_const::getInstance()->addPath('BaseLogin','class/objects/base/cls_BaseLogin.php');

?>