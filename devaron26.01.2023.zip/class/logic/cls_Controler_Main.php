<?php

class Controler_Main extends Controller
{

    private static $Instance;
    private $StartTime;
    private $Date;
    private $Language;
    private $User;
    private $ModulString;

    /**
     * singelton
     *
     * @return Controler_Main 
     *
     */
    public static function getInstance()
    {
        if ( self::$Instance === null )
        {
            self::$Instance = new Controler_Main();
        }
        return self::$Instance;
    }

    /**
     * Gibt den Momentan eingeloggten Benutzer zurück
     * @return User
     */
    public function getUser()
    {
        return $this->User;
    }

    public function setUser( User $User )
    {
        $this->User = $User;
    }

    /**
     * der Contructor
     *
     * @return void 
     *
     */
    public function __construct()
    {
        parent::__construct();
        $this->StartTime = microtime(true);
        $this->loadConfig(); // config ins system laden		$this->addClick();
        $this->Date = date("d.m.Y H:i"); // start zeit holen
        $this->setLanguage();  // sprache setzen
        Template::getInstance()->assign("MainMenu", 0);        
    }

    private function setLanguage()
    {
        $Request = new Request();
        $TempLate = Template::getInstance();
        if ( $Request->getAsString("Lang") )
        {
            $_SESSION['Language'] = $Request->getAsString("Lang");
            $this->Language = $_SESSION['Language'];
            $TempLate->setLanguage($this->Language);
            return false;
        }
        if ( $_SESSION['Language'] && !$Request->getAsString("Lang") )
        {
            $this->Language = $_SESSION['Language'];
        }
        if ( !$_SESSION['Language'] && !$Request->getAsString("Lang") )
        {
            $this->Language = LANGUAGE_GER;
        }

        $TempLate->setLanguage($this->Language);
    }

    public function getEndTime()
    {
        return substr(microtime(true) - $this->StartTime, 0, 5);
    }

    /**
     * lädt die einstellungen für das system aus der config datei
     *
     * @return  
     *
     */
    private function loadConfig()
    {
        @include("cfg/cfg.php"); // normale einstellungen laden nicht die db einstellungen die werden direkt von der db schnittstelle geladen 
        @include("cfg/const.php");
    }

    private function userLogin()
    {
        $this->User = User::getEmptyInstance();
        $Request = new Request();
        $UserFinder = new UserFinder();
        
        if ( isset($_SESSION['UserName']) && isset($_SESSION['UserPass']) )
        {
            switch( $_SESSION['UserType'] )
            {
                case USER_TYPE_CONTACT:
                    $ContactsFinder = new ContactsFinder();
                    $this->User = $ContactsFinder->findByMailAndPass( $_SESSION['UserName'] , $_SESSION['UserPass'] );
                    //var_dump($this->User);
                    if($this->User->getId())
                    {
                        return true;
                    }
                    break;
                
                default:
                    
                $this->User = $UserFinder->findByNameAndPass( $_SESSION['UserName'] , $_SESSION['UserPass'] );
                if($this->User->getId())
                {
                    $PaymentUserId = $this->User->getId();
                    if( $this->User->getMasterUser() )
                    {
                        $PaymentUserId = $this->User->getMasterUser();
                    }
                    
                    $PackageType = $PaymentHistoryFinder->getPackageTypeByUserId( $PaymentUserId );
                    $Duration = $PaymentHistoryFinder->getDurationByUserId( $PaymentUserId );
                    
                    $this->Template->assign( 'Duration', $Duration );
                    $this->Template->assign( 'PackageType', $PackageType );
                    return true;
                }  
            }
            return true;
        }

        if ( strlen( $Request->getAsString('UserName') ) && strlen($Request->getAsString('UserPass') ) )
        {
            $this->User = $UserFinder->findByName($Request->getAsString('UserName'));
        }
        // nicht eingeloggt dann nochmal versuchen
        return false;
    }

    /**
     * fügt den permaneten aoutput zum template hinzu
     *
     * @return void 
     *
     */
    public function addPermanentOutPut()
    {
        $Template = Template::getInstance("");
        $Template->assign("User", $this->User);
        $Template->assign("Title", DOMAIN_NAME . " " . HEAD_TITLE);
    }

    public function isUserLoggedIn()
    {
        return $this->User->getId();
    }

    
    public function checkModulAccess( $ModulName )
    {
        if($_SESSION['UserType'] == USER_TYPE_USER && $this->User->getMasterUser() == 0) return true; // wenn der User ein MasterUser zugriff auf alle Module!
        
        if( $_SESSION['UserType'] == USER_TYPE_USER )
        {

            if( in_array( $ModulName , $_SESSION['ModulArray']) )
            {
                return true;
            }
        }
        return false;
    }
    
    
    // Diese Function startet das system
    public function start()
    {
        //var_dump($_SESSION['DataBase']);
        $this->userLogin();
        $this->addPermanentOutPut();
        $Request = new Request();

        if ( $this->User->getId() ) // hier alles hinter dem Login
        {
            switch ( $Request->getAsString('Section') )
            {

                
                case "Mail":
                        $Controler = new Controler_Mail();
                        $Controler->start();
                        return true;
                    break;
                
                case "Teams":
                        $Controler = new Controler_Contakts();
                        $Controler->start();
                        return true;
                    break;
               
                 case 'Values':
                case 'UpdateValues':
                    
                    $Controler = new Controler_Value();
                    $Controler->start();
                    return;
                break;

                case 'UpdateValue':
                    $this->UpdateValue();
                break;
                
            }
        }


        switch ( $Request->getAsString('Section') ) // alles ohne login möglich
        {
            case "Impressum":
                {
                    $this->showImpressum();
                }break;

            case "PrivacyPolicy":
                {
                    $this->showPrivacyPolicy();
                }break;


            case "AGB":
                {
                    $this->showAGB();
                }break;

            case "Login":
                {
                    $Controler = new Controler_Login();
                    $Controler->start();
                }break;

            case "Download":
                {
                    $this->showDownload();
                }break;

            default:
                $Controler = new Controler_Start();
                $Controler->start();
                break;
        }
    }

    public function showStart()
    {
        $Controler = new Controler_Start();
        $Controler->start();
    }

    public function checkUser()
    {
        // 
        $ReQuest = new Request();
        $UserFinder = new UserFinder();
        $User = $UserFinder->findByNameAndPass($ReQuest->getAsString("UserName"), $ReQuest->getAsString("UserPass"));
        if ( $User->getId() )
        {
            echo "true";
            return true;
        }
        echo "false";
        return false;
    }

    public function showDownload()
    {
        $Template = Template::getInstance("tpl_Download.php");
        $Template->assign("Title", "Download " . DOMAIN_NAME);
        $Template->assign("KeyWords", "");
        $Template->assign("Description", DOMAIN_NAME . " ");
        $Template->render();
    }

    public function showAGB()
    {
        $Template = Template::getInstance("tpl_AGB.php");
        $Template->assign("Title", "AGB " . DOMAIN_NAME);
        $Template->assign("KeyWords", "");
        $Template->assign("Description", DOMAIN_NAME . " ");

        $Template->render();
    }

    private function showImpressum()
    {
        $Template = Template::getInstance("tpl_Impressum.php");
        $Template->assign("Title", "Impressum " . DOMAIN_NAME);
        $Template->assign("KeyWords", "");
        $Template->assign("Description", DOMAIN_NAME . " ");
        $Template->render();
    }

    private function showPrivacyPolicy()
    {
        $Template = Template::getInstance("tpl_PrivacyPolicy.php");
        $Template->assign("Title", "Datenschutzerklärung " . DOMAIN_NAME);
        $Template->assign("KeyWords", "");
        $Template->assign("Description", DOMAIN_NAME . " ");
        $Template->render();
    }

}

?>