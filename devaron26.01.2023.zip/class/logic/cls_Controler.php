<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Controler
{
    protected $Template;
    protected $Request;
    protected $Cache;

    public function __construct()
    {
        $this->Template = Template::getInstance();
        $this->Request = new Request();

        if (WRITE_CACHE) {
            $this->Cache = new Cache();
        } else {
            $this->Cache = new EmptyCache();
        }

        if ($this->Request->getAsString('Section') == 'dUpdateValue') {
            exit($this->updateValue());
        }
    }

    /**
     * prüft ob der user eingelogt ist wenn er nicht eingelogt ist wird zu startseite verlinkt.
     */
    protected function checkLogin()
    {
		//var_dump( Controler_Main::getInstance()->getUser()->getId() );
        if (!Controler_Main::getInstance()->getUser()->getId()) { // wenn nicht eingelogt
            (new Controler_Login())->start();
            exit(1);
        }
		return true;
    }

    /**
     * gibt den Momentanen User zurück.
     */
    protected function getUser()
    {
        return Controler_Main::getInstance()->getUser();
    }

    protected function checkCache()
    {
        if ($this->Request->hasPost()) {
            return;
        }
        if (!WRITE_CACHE) {
            return;
        }
        $Result = $this->Cache->get($this->Request->getUrl());

        if (strlen($Result)) {
            echo $Result;
            exit();
        }
    }
    
    /**
     * ruf die function auf welche über den Parameter Request per post oder get übergeben wurde
     * @return boolean
     */
    protected function callFunction()
    {
        //var_dump($this->Request);
        
        if( method_exists( $this, $this->Request->getAsString('Action') ))
        {
            $FunctionName = $this->Request->getAsString('Action');
            $this->$FunctionName();
            return true;
        }
        return false;
    }
    
    
}
