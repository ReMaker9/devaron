<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of cls_Controler_Mail
 *
 * @author ReMaker
 */
class Controler_Mail
{


    
    
    
    public static function sendBruteForceNotice( LoginCollection $LastLogins )
    {
        $mail = new PHPMailer();
        //$mail->SMTPSecure = SMTP_CRYPT;               // Verschlüsselung
        //$mail->IsSMTP();
        $mail->Host = SMTP_SERVER;
        $mail->Port = SMTP_PORT;
        //$mail->Username = SMTP_USERNAME;              // SMTP username
        //$mail->Password = SMTP_PASS;   
        //$mail->SMTPAuth = true;  
        $mail->IsHTML( true );
        $mail->SetFrom( SMTP_USERNAME, "Essel Shiftplaner" );
        $mail->AddAddress( SYSTEM_MAIL_ADDRESS_TECHNICAL );
		$mail->AddAddress( "info@itservice-herzog.de" );

        $mail->CharSet = 'utf-8';
        $mail->SetLanguage ("de");

        $mail->Subject = 'Essel-Schiftplaner-Login: IP wurde blockiert (Brute-Force-Schutz) ' . $LastLogins->getByIndex(0)->getUserName() ;

        $Template= new Template( "mail/tpl_BruteForceNotice.php" );
        $Template->assign( "LastLogins", $LastLogins );
        $Template->assign( "MailTitle", "BruteForce Detection" );
        $View=$Template->renderWithoutSend();

        $mail->MsgHTML( $View );
        $mail->AltBody = 'Essel-Schiftplaner-Login: IP wurde blockiert (Brute-Force-Schutz)';
        if(!$mail->Send()) 
        {
          ErrorLogger::log( $mail->ErrorInfo );
        } else 
        {
          //echo "Message sent!";
        }      
    }

    public function sendIllMessage( $Illdata )
    {
        //var_dump("Mail erstellen");
        $mail = new PHPMailer();
        //$mail->SMTPSecure = SMTP_CRYPT;               // Verschlüsselung
        //$mail->IsSMTP();
        $mail->Host = SMTP_SERVER;
        $mail->Port = SMTP_PORT;
        // $mail->Username = SMTP_USERNAME;              // SMTP username
        // $mail->Password = SMTP_PASS;   
        // $mail->SMTPAuth = true;    
		$mail->IsHTML( true );		
		$mail->SMTPDebug  = 1;

        //Set who the message is to be sent from
        $mail->SetFrom( SYSTEM_ADMIN_MAIL, SMTP_USERNAME );
        $mail->AddAddress( ILL_MESSAGE_MAIL_RECIVER );
        
        //$mail->AddAddress( "info@itservice-herzog.de" ); 
        $mail->CharSet = 'utf-8';
        $mail->SetLanguage ("de");
        //Set who the message is to be sent to
        //$mail->AddAddress( $Basket['UserData']['tb_Mail'] );
        //Set the subject line
        $mail->Subject = 'Shiftplaner Krankmeldung';
        // Read an HTML message body from an external file, convert referenced images to embedded, convert HTML into a basic plain-text alternative body

        $Template= new Template( "mail/tpl_IllMessage.php" );
		$Template->assign( "Illdata" , $Illdata );
		
        $View=$Template->renderWithoutSend();

        $mail->MsgHTML( $View );

        //Replace the plain text body with one created manually
        $mail->AltBody = 'Shiftplanner Krankmeldung';
        
		//var_dump( $View );
		//exit();
		
		
		
		
        //Send the message, check for errors
        if(!$mail->Send()) 
        {
            ErrorLogger::log( $mail->ErrorInfo );
          //echo "Mailer Error: " . $mail->ErrorInfo;
        } else 
        {
          //echo "Message sent!";
        }      
        
    }



    
    public function sendPasswortReset( Passreset $ResetData )
    {
        //var_dump("Mail erstellen");
        $mail = new PHPMailer();
        $mail->SMTPSecure = SMTP_CRYPT;               // Verschlüsselung
        $mail->IsSMTP();
        $mail->Host = SMTP_SERVER;
        $mail->Port = SMTP_PORT;
        $mail->Username = SMTP_USERNAME;              // SMTP username
        $mail->Password = SMTP_PASS;   
        $mail->SMTPAuth = true;        
// SMTP 

        // Set PHPMailer to use the sendmail transport
        // $mail->IsSendmail();
        //$mail->IsMail();
        $mail->IsHTML( true );
        //Set who the message is to be sent from
        $mail->SetFrom( SYSTEM_MAIL_ADDRESS, SYSTEM_MAIL_NAME );
        $mail->AddAddress( $ResetData->getMail() );
        
        //$mail->AddAddress( "info@itservice-herzog.de" ); 
        $mail->CharSet = 'utf-8';
        $mail->SetLanguage ("de");
        //Set who the message is to be sent to
        //$mail->AddAddress( $Basket['UserData']['tb_Mail'] );
        //Set the subject line
        $mail->Subject = 'Shiftplaner Passwort zurücksetzen.';
        //Read an HTML message body from an external file, convert referenced images to embedded, convert HTML into a basic plain-text alternative body

        $Template= new Template("mail/tpl_PasswortReset.php");
        $Template->assign("Hash", $ResetData->getHash() );
        $View=$Template->renderWithoutSend();

        $mail->MsgHTML( $View );

        //Replace the plain text body with one created manually
        $mail->AltBody = 'Mea Passwort zurücksetzen.';
        
        //Send the message, check for errors
        if(!$mail->Send()) 
        {
            ErrorLogger::log( $mail->ErrorInfo );
          //echo "Mailer Error: " . $mail->ErrorInfo;
        } else 
        {
          //echo "Message sent!";
        }      
        
    }


}

?>