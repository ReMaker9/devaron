<?php

class Controler_Start extends Controler
{
    public function __construct()
    {
        parent::__construct();
        $this->TempLate = Template::getInstance();
		//$this->checkLogin();
    }

    public function start()
    {
        $Request = new Request();
        switch ($Request->getAsString('Action')) 
        {
            case 'ShowDashboard':
                    $this->showDashboard();
                break;

            /*case 'ShowManagment':
                    $this->showManagment();
                break;*/

			case 'ShowManagement':
                $this->showManagement();
                break;	
				
			case "ShowEditPlanTemplate":
				$this->showEditPlanTemplate();

			break;			
				
				
				
	

            default:
                $this->showStart();
        }
    }

	
	public function showEditPlanTemplate()
    {
		$this->checkLogin();
        $Request = new Request();
        $TempLate = Template::getInstance('tpl_EditPlans.php');
		
		// hier wird der aktuelle planung geladen und gemappt
		
		$PlaningtemplateFinder = new PlaningtemplateFinder();
		$PlanArrayData = $PlaningtemplateFinder->loadActivePlan();
		
		$this->TempLate->assign( "Data" , $PlanArrayData );
        $TempLate->render();
    }
	
	

    public function showManagement()
    {
		$this->checkLogin();
        $Request = new Request();
        $TempLate = Template::getInstance('tpl_Management.php');

        $TempLate->render();
    }

    public function showDashboard()
    {
		// prüfung auf admin
        $Template = $this->loadAdminTemplate();
		// echo $this->getUser()->getId();
		
		$PlanningentryFinder = new PlanningentryFinder();
		
		$PlanningentryCollection = $PlanningentryFinder->findByUserIdUpToDate( $this->getUser()->getId() );
		$Template->assign( "PlanningentryCollection" , $PlanningentryCollection );
		
		
		$PlaningtemplateFinder = new PlaningtemplateFinder();
		$PlaningtemplateCollection = $PlaningtemplateFinder->findAll();
		$Template->assign( "PlaningtemplateCollection" , $PlaningtemplateCollection );
		
		$PlaningtemplateentrytypeFinder = new PlaningtemplateentrytypeFinder();
		$PlaningtemplateentrytypeCollection = $PlaningtemplateentrytypeFinder->findAll();
		$Template->assign( "PlaningtemplateentrytypeCollection" , $PlaningtemplateentrytypeCollection );
		
		
		
		$CommentFinder = new CommentFinder();
		$CommentCollection = $CommentFinder->getByUserIdinFuture( $this->getUser()->getId() );
		$this->TempLate->assign( "CommentCollection" , $CommentCollection );
		
		// var_dump( $CommentCollection );
		
		
        $Template->render();
    }

    public function showStart()
    {
        $Request = new Request();
        $TempLate = Template::getInstance('tpl_Login.php');
		$UserFinder = new UserFinder();
		$UserCollection = $UserFinder->findAll();
		$TempLate->assign( "UserCollection" , $UserCollection );
		//var_dump( $UserCollection ); exit();
		
		
		
        $TempLate->render();
    }

    public function loadAdminTemplate()
    {
        $Template = Template::getInstance('tpl_Start.php');
        $Request = new Request();
        
        return $Template;
    }

}