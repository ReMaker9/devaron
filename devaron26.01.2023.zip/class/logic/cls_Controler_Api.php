<?php

/**
 * class cls_Controler_Click
 *
 * Description for class cls_Controler_Click
 *
 * @author:
 */
class Controler_Api extends Controler
{

    /**
     * cls_Controler_Click constructor
     *
     * @param
     */
    function __construct()
    {
        parent::__construct();
        $this->TempLate = Template::getInstance();
        
        //$this->checkLogin(); // wenn nicht eingeloggt dann raus hier
        
    }

    public function checkApiKey()
    {
        // check ob im Header der api key mit drin steckt
        var_dump( getallheaders ( ) );
        
        
        // Error Output machen
        if( $this->Request->getAsString("ApiKey") != API_KEY )
        {
            $TempLate = Template::getInstance();
            $Result = new stdClass();
            $Result->message = "Wrong ApiKey!";
            $TempLate->outputJSON(1, $Result);
            exit();
            
        }
  
        
        
    }
    
    
    public function start()
    {
        $Request = new Request();
        // api Key Check!
        
        $this->checkApiKey();

        switch ( $Request->getAsString('Action') ) 
        {
            case "GetData":
                {
                    $this->getData();
                }
                break;

			
            default:
                $this->showDefault();
        }
    }




    public function showDefault()
    {
        // ist nutzer eingelogt ?
        $TempLate = Template::getInstance();
        $Result = new stdClass();
        $Result->message = "No Way!";
        $TempLate->outputJSON(1, $Result);
        return;
    }

    
}

?>