<?php    
error_reporting( E_ALL );
session_start();
include('class/logic/cls_Include.php');
error_reporting( E_ALL & ~( E_STRICT|E_NOTICE|E_WARNING ) );
$Controler_Api= new Controler_Api();
$Controler_Api->start();
?>