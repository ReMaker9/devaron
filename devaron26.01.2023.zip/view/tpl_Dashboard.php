<?php
$TodayDate = date('d.m.Y', time());
$TodayWeekday = Date::getWeekdayFromDate($TodayDate);
$this->renderSnipet('tpl_HeaderNavi.php', array('Active' => BACKEND_PAGE_DASHBOARD));
?>

<div class="row mt-3">
    <div class="col-1">
        <h1>Dashboard</h1>
    </div>
</div>

<!-- CARD-->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title mb-0">
                    <span class="font-weight-bold"><i class="far fa-chart-bar mr-2"></i> Kurzstatistik Heute (<?php echo $TodayDate; ?>)</span>
                </div>
            </div>
            <div class="card-body">
            </div>
        </div>
    </div>
</div>

<!-- CARD-->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title mb-0">
                    <span class="font-weight-bold"><i class="far fa-chart-bar mr-2"></i> Kurzstatistik Gesamt </span>
                </div>
            </div>
            <div class="card-body">
            </div>
        </div>
    </div>
</div>

<!-- CARD-->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title mb-0">
                    <span class="font-weight-bold"><i class="fas fa-check-square mr-2"></i> Schnellstart Funktionen </span>
                </div>
            </div>
            <div class="card-body">
                <div class="col-6">
                    <a class="btn btn-primary" href="index.php?Section=Database#PrinterTable">
                        <i class="fas fa-print mr-2"></i>Drucker bearbeiten
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CARD-->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title mb-0">
                    <span class="font-weight-bold"><i class="fas fa-search mr-2"></i> Schnellsuche </span>
                </div>
            </div>
            <div class="card-body">

            </div>
        </div>
    </div>
</div>

<script>
    $(function () {
        // Engine.ManagementController.initAdminDashboard();
    });
</script>