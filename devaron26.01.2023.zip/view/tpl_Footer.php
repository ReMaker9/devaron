</div> 
</div>

<!-- Footer -->
<footer class="page-footer font-small blue pt-4">

  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <hr class="clearfix w-100 d-md-none pb-3">

      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3">

        <!-- Links -->
        <h5 class="text-uppercase">Intern</h5>

        <ul class="list-unstyled">
          <li>
            <a class="Link link" target="_blank" href="http://192.168.11.197/shiftreport2/login.php">ESB</a>
          </li>
          <li>
            <a class="Link link" target="_blank" href="http://192.168.11.52:8080/">Jira</a>
          </li>
          
        </ul>

      </div>
      <!-- Grid column -->

      <!-- Grid column 
      <div class="col-md-3 mb-md-0 mb-3">

        
        <h5 class="text-uppercase">Links</h5>

        <ul class="list-unstyled">
          <li>
            <a href="#!">Link 1</a>
          </li>
          <li>
            <a href="#!">Link 2</a>
          </li>
          <li>
            <a href="#!">Link 3</a>
          </li>
          <li>
            <a href="#!">Link 4</a>
          </li>
        </ul>

      </div>-->
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">
  Powered by <a style="text-decoration: none; font-weight: normal;" target="_blank" href="https://itservice-herzog.de">IT Service Herzog</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->






<script src="js/ext/bootbox.min.js"></script>
<script src="js/ext/jquery-ui.min.js" ></script>
<script src="js/ext/jquery.serialize-object.min.js"></script>
<script src="js/ext/jFormValid.js"></script>
<script src="js/ext/jquery.mask.min.js"></script>
<script src="js/ext/bootstrap-datepicker.min.js"></script>
<script src="js/ext/bootstrap-datepicker.de.min.js"></script>


<script src="js/lib/class.utils.js"></script>
<script src="js/ext/jquery-confirm.min.js"></script>




<script src="js/lib/class.storage.js"></script>
<script src="js/lib/TableSearch.js"></script>

<script src="js/lib/class.notify.js"></script>
<script src="js/logic/constants.js"></script>
<script src="js/lib/class.template.js"></script>
<script src="js/logic/class.engine.js"></script>
<script src="js/logic/class.AuthController.js"></script>
<script src="js/logic/class.PlaningController.js"></script>

<script src="js/ext/select2.js"></script>
<link href="css/select2.min.css" rel="stylesheet" type="text/css"  />

<script src="js/ext/chosen.min.js"></script>

<link href="css/jquery-confirm.min.css" rel="stylesheet" type="text/css"  />
<link href="css/chosen.min.css" rel="stylesheet" type="text/css"  />
<link href="css/jquery.colorpicker.css" rel="stylesheet" type="text/css"  />
<link href="css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css"  />
<script src="js/ext/moment.min.js"></script>

<script src="js/ext/jquery-ui.min.js" ></script>
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css"  />
</body>
</html>