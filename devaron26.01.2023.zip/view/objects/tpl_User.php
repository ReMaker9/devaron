

        <div id="main" class="container">
        
<!-- Start tpl -->

            <form id="GeneratatedForm" 
                  class="form-horizontal" 
                  data-tablename="User"
                  enctype="multipart/form-data">
                <fieldset>

                <!-- Form Name -->
                <legend><h1>Mitarbeiter</h1></legend>

                    <input id = "hidden_TableName" name = "hidden_TableName" type = "hidden" value = "User" >
                     
            <!-- Input-Field -->
                <div class="form-group row"  style="display:none;" >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Id">Id</label>
                  <div class="col-md-6">
                  <input id="tb_Id" 
                         name="tb_Id" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md Id"
                         >
                  </div>
                </div>
                     
            <!-- Input-Field -->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Name">Name</label>
                  <div class="col-md-6">
                  <input id="tb_Name"
                         name="tb_Name" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md Name "
                         >
                  </div>
                </div>
            
            <!-- Password input-->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Pass">Passwort</label>
                  <div class="col-md-6">
                    <input id="tb_Pass" 
                           name="tb_Pass" 
                           data-type="s" 
                           type="text" 
                           placeholder="" 
                           class="form-control 
                           input-md Pass"
                         >
                  </div>
                </div>
                
            <!-- Password input-->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="tb_Pass2">Passwort wiederholen</label>
                  <div class="col-md-6">
                    <input id="tb_Pass2" 
                           name="tb_Pass2" 
                           data-type="s" 
                           type="text" 
                           placeholder=" wiederholen" 
                           class="form-control 
                           input-md Pass"
                         >
                  </div>
                </div>
            

                    
            <!-- Password input-->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Mail">Mail:</label>
                  <div class="col-md-6">
                    <input id="tb_Mail" 
                           name="tb_Mail" 
                           data-type="s" 
                           type="text" 
                           placeholder="" 
                           class="form-control input-md Mail"
                           type="email" 
                                                                                                
                         >
                  </div>
                </div>
            
            <!-- Password input-->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Mail">MailCC:</label>
                  <div class="col-md-6">
                    <input id="tb_MailCC" 
                           name="tb_MailCC" 
                           data-type="s" 
                           type="text" 
                           placeholder="" 
                           class="form-control input-md MailCC"
                           type="email" 
                                                                                                
                         >
                  </div>
                </div>

			
            <!-- Input-Field -->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Type">Nuterlevel</label>
                  <div class="col-md-6">
				  <select id="tb_Type" 
                         name="tb_Type" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md Type">
						<option value="7">Supervisor</option>
						<option value="6">Schichtleiter</option>
						<option value="5">Oberdrucker</option>
						<option value="4">Einsteller</option>
						<option value="3">Drucker</option>
						<option value="2">Packer</option>
						<option value="1">User</option>
						
				  
				  </select>
				 
                  </div>
                </div>
				
				
				<!-- adName input-->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="AdName">adName:</label>
                  <div class="col-md-6">
                    <input id="tb_AdName" 
                           name="tb_AdName" 
                           data-type="s" 
                           type="text" 
                           placeholder="" 
                           class="form-control input-md AdName"
                           type="text" 
                                                                                                
                         >
                  </div>
                </div>
				
				<div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Department">Abteilung</label>
                  <div class="col-md-6">
				  <select id="tb_Department" 
                         name="tb_Department" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md Department">
						<option value="Verwaltung">Verwaltung</option>
						<option value="Produktion">Produktion</option>
						<option value="Druck">Druck</option>
						<option value="Lager">Lager</option>
						<option value="QS">QS</option>
				  </select>
				 
                  </div>
                </div>
				
				
				<!-- adName input-->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="Active">Aktive:</label>
                  <div class="col-md-6">
                    <input id="tb_Active" 
                           name="tb_Active" 
                           data-type="s" 
                           type="number" 
                           placeholder="" 
						   min="0"
						   max="1"
                           class="form-control input-md Active"
                           type="text" 
						   value="1"
                                                                                                
                         >
                  </div>
                </div>
				
				<div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="EntryIds">Kann: <a class="btn btn-success btn_TakeAll">Alles auswählen</a></label>
                  <div class="col-md-6">
                    <select id="tb_EntryIds" multiple 
                         name="tb_EntryIds" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md EntryIds">
						<?php echo $this->getOptionHTMLElements("Planingtemplateentrytype", "Name");?>
				  </select>
                  </div>
                </div>
				
				
				            <!-- Input-Field -->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="LeasedEmployee">Mitarbeiter Art</label>
                  <div class="col-md-6">
				  <select id="tb_LeasedEmployee" 
                         name="tb_LeasedEmployee" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md LeasedEmployee">
						<option value="0">Interner Mitarbeiter</option>
						<option value="1">Externer Mitarbeiter (Leiharbeiter)</option>
				  </select>
				 
                  </div>
                </div>
				
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="ErrorReporter">kann der Benutzer im ESB Fehlernachrichten bekommen?</label>
                  <div class="col-md-6">
				  <select id="tb_ErrorReporter" 
                         name="tb_ErrorReporter" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md ErrorReporter">
						<option value="0">Kein Fehlernachricht empfänger</option>
						<option value="1">Fehlernachricht empfänger</option>
				  </select>
				 
                  </div>
                </div>
				
								<!-- adName input-->
                <div class="form-group row"   >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="CanPlan">Planungs User:</label>
                  <div class="col-md-6">
				  	<select id="tb_CanPlan" 
                         name="tb_CanPlan" 
                         data-type="s"
                         type="text" 
                         placeholder="" 
                         class="form-control input-md CanPlan">
						<option value="0">kann nicht planen</option>
						<option value="1">kann planen</option>
					</select>
				  
                    
                  </div>
                </div>
				
				
				
            <!-- Button (Double) -->
                    <div class="form-group row">
                        <br />
                        <div class="col-md-2"></div>
                        <div class="col-md-8 row">      
                            <div class="col-md-6">
                                <input type="submit" id="btn_Controls0" name="btn_Controls0" class="btn btn-success btn-block" value="Speichern" />
                                <br />
                            </div>
                            <div class="col-md-6">
                                <a href="index.php?Section=">
                                    <button id="btn_Controls1" name="btn_Controls1" class="btn btn-danger btn-block"> verwerfen </button>
                                </a>
                            </div>
                      </div>
                    </div>
                        
                <script>

                    $(function ()
                    {
                        Engine.setFormEvents(<?php echo $this->JsonData; ?>);
						
						$('.btn_TakeAll').click(function(){
							$('#tb_EntryIds option').prop('selected', true)
							$('#tb_EntryIds').trigger('chosen:updated');
						});
						
						
						
                    });
                </script>
            <!-- end tpl -->
            </fieldset>
        </form>
    </div>