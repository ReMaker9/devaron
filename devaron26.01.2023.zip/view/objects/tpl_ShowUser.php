     
    <fieldset>

        <!-- Form Name -->

        <legend><h1 class="text-center">Mitarbeiter anzeigen</h1></legend>
        
        <div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Id">Id</span>
            <span class = "col-6 text-left" for = "Id"> <?php if($this->Object->getId()) echo $this->Object->getId(); else echo "-"; ?> </span>
        </div>     
        <div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Name">Name</span>
            <span class = "col-6 text-left" for = "Name"> <?php if($this->Object->getName()) echo $this->Object->getName(); else echo "-"; ?> </span>
        </div>

        <div class="row">
            <span class="col-md-6 col-md-2 text-right" for="LastLogin">Letzter Login</span>
            <span class="col-6 text-left" for="LastLogin"> <?php echo $this->formatDate($this->Object->getLastLogin()); ?> </span>
        </div>
        <div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Mail">Mail:</span>
            <span class = "col-6 text-left" for = "Mail"> <?php if($this->Object->getMail()) echo $this->Object->getMail(); else echo "-"; ?> </span>
        </div>
		<div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Mail">MailCC:</span>
            <span class = "col-6 text-left" for = "Mail"> <?php if( $this->Object->getMailCC() ) echo $this->Object->getMailCC(); else echo "-"; ?> </span>
        </div>
        <div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Type">Type</span>
            <span class = "col-6 text-left" for = "Type"> <?php if($this->Object->getType()) echo Essel::getUserLevel($this->Object->getType()); else echo "-"; ?> </span>
        </div>
		
		<div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Type">adName</span>
            <span class = "col-6 text-left" for = "Type"> <?php if($this->Object->getadName()) echo $this->Object->getadName(); else echo "-"; ?> </span>
        </div>
		
		<div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Abteilung">Abteilung</span>
            <span class = "col-6 text-left" for = "Type"> <?php if($this->Object->getDepartment()) echo $this->Object->getDepartment(); else echo "-"; ?> </span>
        </div>
		
		<div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Type">Aktiv</span>
            <span class = "col-6 text-left" for = "Type"> <?php if($this->Object->getActive()) echo $this->Object->getActive(); else echo "-"; ?> </span>
        </div>
		
		<div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Type">Mitarbeiter Art</span>
            <span class = "col-6 text-left" for = "Type"> <?php if(!$this->Object->getLeasedEmployee()) echo "Interner Mitarbeiter"; else echo "Externer Mitarbeiter (Leiharbeiter)"; ?> </span>
        </div>
		
		<div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = "Type">Planungsuser</span>
            <span class = "col-6 text-left" for = "Type"> <?php if($this->Object->getCanPlan()) echo "Kann planen"; else echo "kann nicht planen"; ?> </span>
        </div>
		
		
		
		
		
		<?php
		$Tage = array("Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag");
		
		// var_dump( $this->PlanningentryCollection);
		
		foreach( $this->PlanningentryCollection as $Planningentry )
		{
			$PlaningTemplate = $this->PlaningtemplateCollection->getById( $Planningentry->getPlaningTemplateId() ) ;
			
			//echo $Planningentry->getPlaningTemplateEntryId();
			
			$PlaningTemplateEntryType = $this->PlaningtemplateentrytypeCollection->getById( $Planningentry->getPlaningTemplateEntryId() ) ;
			
			
			$TimeStamp = strtotime($Planningentry->getDate());
			echo "<div class='row pb-2 striped'>
			<div class='col-2'> " . $Tage[ date( "w", $TimeStamp ) ] . " " . Date::getGermanDate( $Planningentry->getDate() )  . "</div>
			<div class='col'>" . $PlaningTemplateEntryType->getName() . "</div>
			<div class='col'>" . $PlaningTemplate->getName() . "</div>
			</div>";
			
		}
		
		?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
        <script>
            $(function ()
            {
                Engine.setFormEvents(<?php echo $this->JsonData; ?>);
            });
        </script>
    <!-- end tpl -->
    </fieldset>