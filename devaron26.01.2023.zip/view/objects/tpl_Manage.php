

    <?php
		$this->renderSnipet("tpl_HeaderStart.php");
	
        //include("../tpl_HeaderStart.php");
    ?>


<div class="row ml-1">
    <h1><?php echo $this->Entity ?></h1>
</div>


<div class="row">
    <div class="col-sm-12 col-md-6 col-xl-4">
        <a class="btn btn-primary" href="index.php?Section=UpdateValues&Action=ShowCreate&Table=<?php echo $this->Entity; ?>"><?php echo $this->Entity ?> anlegen </a>
    </div>
</div>                   

<div class="row">
    <div class="col-12">
        <form>
            <div class="form-group" >
                <input id="TableSearch" filter-name="Filter<?php echo $this->Entity; ?>" class="form-control" placeholder="Sucheingabe">
            </div>
        </form> 
    </div>
</div>

 <?php
 
    $Count = count($Member) / 12;
    if($Count < 2)
    {
        $Count = 2;
    }
    
    foreach($Member as $Key => $Variable)
    {
        if($Key == "Id")
        {
            echo '<div class="SearchResultEntryValue col-sm-1 text-truncate ' . $Key . '"  title="' . $Key . '">' . $Key . '</div>';
            continue;
        }
        if( strpos($Key, "Id") !== false )
        {
            echo '<div class="SearchResultEntryValue col-sm-1 text-truncate ' . $Key . '" title="' . $Key . '">' . $Key . '</div>';
            continue;
        }
        echo '<div class="SearchResultEntryValue col-sm-'.$Count.' text-truncate ' . $Key . '" title="' . $Key . '">' . $Key . '</div>';
        
        
    }
  ?>

<div class="row">
    <div class="col-12">
        <div id="l_SearchResultContainerHeader" class="l_SearchResultContainerHeader">
            <div class="SearchResultEntryButtonGroup col-sm-9">
<?php
    $Member = $this->Object->getMembersForTemplate();
    $Count = count($Member) / 12;
    if($Count < 2)
    {
        $Count = 2;
    }
    
	if( !$this->templateExsist( "snippet/tpl_" . $this->Entity . ".php" ) )
	{
	
		foreach($Member as $Key => $Variable)
		{
			if( $Key == "Icon" )
			{
				continue;
			}
			
			if( strpos($Key, "Id") !== false )
			{
				echo '<div class="SearchResultEntryValue col-sm-1 text-truncate ' . $Key . '" title=":' . $Key . ':">:' . $Key . ':</div>';
				continue;
			}
			
			if( $Key == "Id" )
			{
				echo '<div class="SearchResultEntryValue col-sm-1 text-truncate "  title="' . $Key . '">' . $Key . '</div>';
				continue;
			}
			
			echo '<div class="SearchResultEntryValue col-sm-'.$Count.' text-truncate " title="' . $Key . '">' . $Key . '</div>';
		}
	}
  ?>
             </div>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-12">
        <div id="l_SearchResultContainer" class="l_SearchResultContainer">
            <div class="SearchElementContainer">
            </div>
        </div>
    </div>
</div>
<div class="tpl">
    <?php

	
	if( $this->templateExsist( "snippet/tpl_" . $this->Entity . ".php" ) )
	{
		$this->renderSnipet( "snippet/tpl_" . $this->Entity . ".php" ,  array() );
	} else 
	{
		$this->renderSnipet( "snippet/tpl_SearchEntrys.php" , array());
		
		
		    echo '    <div id="tpl_SearchResultRow">
    <div class="SearchResultEntry row " data-type=":ClassType:">
        <div class="SearchResultEntryButtonGroup col-sm-9">';
    
    $Count = count($Member) / 12;
    if($Count < 2)
    {
        $Count = 2;
    }
    
    if(isset($Member['Icon']))
    {
         echo  '<div class="SearchResultEntryValue" data-id=":Id:">'.$Member['Icon'].'</div>' ;
    }
    
    
    foreach($Member as $Key => $Variable)
    {
        if($Key == "Icon")
        {
            continue;
        }
        if($Key == "Id")
        {
            echo '<div class="SearchResultEntryValue col-sm-1 text-truncate ' . $Key . '"  title=":' . $Key . ':">:' . $Key . ':</div>';
            continue;
        }
        echo '<div class="SearchResultEntryValue col-sm-'.$Count.' text-truncate ' . $Key . '" title=":' . $Key . ':">:' . $Key . ':</div>';
        
        
    }
    echo '
		</div>
        <div class="SearchResultEntryButtonGroup row">
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchShow">
                    <i class="fas fa-search-plus"></i>
                </button>
            </div>
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchEdit">
                    <i class="fas fa-edit"></i>
                </button>
            </div>
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchRemove">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        </div>
    </div>';
		
		
	}
	
	
    
    
    


    
    ?>
    
    



</div>
    
    
    
    
    
    
    
    
    
</div>


<script>

    $(function ()
    {
        Engine.initTableSearch("index.php?Section=UpdateValues&Action=Get<?php echo $this->Entity ?>" );
    });
</script>