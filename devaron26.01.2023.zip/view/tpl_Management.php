<div id="Content">
    
    <?php
        include("tpl_HeaderStart.php");
    ?>
    
    <div class="containerWidth row">
	
		<h1 class='col-md-12'>Schiftplaner Verwaltung</h1>
	
		<div class='col-4'>
            <a href="index.php?Section=Value&Action=ManageUser"><button class="btn btn-primary btn-block">Mitarbeiter bearbeiten</button></a>
        </div>
	
	
        <div class='col-4'>
			<a href="index.php?Section=Start&Action=ShowEditPlanTemplate">
				<button class="btn btn-primary btn-block">Planung erstellen</button>
			</a>
        </div> 
		
		<!--<div class='col-4'>
            <button class="btn btn-primary btn-block">planingtemplateentry</button>
        </div>-->
		
		<div class='col-4'>
            <a href="index.php?Section=Value&Action=Manageplaningtemplateentrytype"><button class="btn btn-primary btn-block">Planungs Zeile anlegen (Springer, Anlage, Urlaub usw.)</button></a>
        </div>
		

		
		<div class='col-4 d-none'>
            <a href="index.php?Section=Value&Action=ManageMaschine"><button class="btn btn-primary btn-block">Maschinen</button></a>
        </div>

		<div class='col-4 d-none'>
            <a href="index.php?Section=Value&Action=Manageplaningtemplateentry"><button class="btn btn-primary btn-block">Eintrags Vorlage</button></a>
        </div>
		
    </div>
</div>
<script>
    $(function ()
    {
       // Hier events über die Engine setzten
       // Engine.Controler.initWas();
    });
</script>