 <?php
$this->renderSnipet("tpl_HeaderAdmin.php", array());
?>
<div class="SystemContainer Content container">
    <?php
    if ($this->ErrorString)
    {
        echo "<p>" . $this->ErrorString . "</p>";
    }
    ?>


    <form class="form-horizontal" id="f_LoginForm">
        <fieldset>

            <!-- Form Name -->
            <legend><?php echo SYSTEM_NAME; ?> Passwort zurück setzen</legend>

            <!-- Text input-->
            <div class="form-group">
                <label class="col-md-4 control-label" for="tb_Name">E-Mail</label>  
                <div class="col-md-4">
                    <input id="tb_Mail" name="tb_Mail" type="text" placeholder="info@dormino.de" class="form-control input-md tb_Mail" required="">
                </div>
            </div>

            <!-- Button -->
            <div class="form-group">
                <label class="col-md-4 control-label" for="btn_Login"></label>
                <div class="col-md-4">
                    <a id="btn_Login" name="btn_Login" class="btn btn_Order">Passwort zusenden</a>
                </div>
                
            </div>

        </fieldset>
    </form>



</div>

<script>

$(function()
{
   Engine.AuthControler.showPasswortReset();
});

</script>
    