<?php
$this->renderSnipet("tpl_HeaderAdmin.php", array());
?>
<div class="SystemContainer Content container">
    <?php
    if ( $this->ErrorString )
    {
        echo "<p>" . $this->ErrorString . "</p>";
    }
    ?>


    <form class="form-horizontal" id="f_LoginForm">
        <fieldset>

            <!-- Form Name -->
            <legend><?php echo SYSTEM_NAME; ?> Passwort zurück setzen.</legend>

            <!-- Text input-->
            <div class="form-group">
                <label class="col-md-4 control-label" for="tb_Name">Neues Passwort</label>  
                <div class="col-md-4">
                    <input id="tb_Pass" name="tb_Pass" type="password"  class="form-control input-md tb_Pass" required="">
                    <input id="tb_Hash" name="tb_Hash" type="hidden" value="<?php echo $this->Hash; ?>"  class="form-control input-md tb_Hash" >
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="tb_Name">Wiederholen</label>  
                <div class="col-md-4">
                    <input id="tb_Pass2" name="tb_Pass2" type="password"  class="form-control input-md tb_Pass2" required="">
                </div>
            </div>
            
            
            <!-- Button -->
            <div class="form-group">
                <label class="col-md-4 control-label" for="btn_Login"></label>
                <div class="col-md-4">
                    <a id="btn_ChangePass" name="btn_ChangePass" class="btn btn-block btn-primary Link">Passwort Ändern.</a>
                </div>
                
            </div>

        </fieldset>
    </form>



</div>

<script>

$(function()
{
   Engine.AuthControler.showPasswortResetSend();
});

</script>
    