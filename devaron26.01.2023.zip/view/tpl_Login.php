 
<?php
//include("tpl_Header.php");
?>

<div class="SystemContainer Content containerWidth">


<div class="row m-0">
	<div class="col-12"><img class="animated infinite pulse slow LoginLogo"  src="img/essel-logo.jpg" class="img-fluid"></div>
	
</div>


    <?php
    if ( $this->ErrorString )
    {
        echo "<p>" . $this->ErrorString . "</p>";
    }
    ?>


    <form class="form-horizontal" id="f_LoginForm">
        <fieldset>

            <!-- Form Name -->
            <legend><?php echo SYSTEM_NAME; ?> Login</legend>
            <p></p>

            <div class="col-sm-12 col-offset-sm-3 row">
                <!-- Text input-->
                <div class="col-sm-12 col-xs-12">
                    <label class="control-label" for="tb_Name">Benutzer (ESB)</label>  
                    <input id="tb_Name" name="tb_Name" type="text" placeholder="Vorname Nachname" class="form-control input-md" required=""  list="Users">
					
					<!-- <select id="tb_Name" name="tb_Name" class="form-control select2" >
					<?php

					foreach( $this->UserCollection as $User )
					{
						echo " <option value='" . $User->getName() . "'>" . $User->getName() . "</option>";
					}

					?>
					</select> -->
					
					
					
                </div>
				
				
				
                
                <!-- Password input-->
                <div class=" col-sm-12 col-xs-12">
                    <label class="control-label" for="tb_Pass">Passwort (ESB Passwort)</label>
                    <input id="tb_Pass" name="tb_Pass" type="password" placeholder="Passwort" class="form-control input-md">
                </div>
                
                <!-- Button -->
                <div class="col-sm-12 col-xs-12 mt-3">
                    <button id="btn_Login" name="btn_Login" class="btn btn-block btn-primary">Login</button>
                </div>
                
                <!--<div class="col-sm-6 col-xs-12">
                    <a id="btn_Passwordreset" href="passwort-reset.html" class="btn btn-block btn-warning">Passwort vergessen ?</a>
                </div>		-->		
            </div>           
        </fieldset>
    </form>

</div>






<script>

    $(function ()
    {
        Engine.AuthControler.showLogin();
    });

</script>
