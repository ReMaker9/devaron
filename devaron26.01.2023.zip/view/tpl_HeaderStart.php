<!--Navbar-->
<nav class="navbar navbar-expand-lg primary-color">

  <!-- Navbar brand -->
  <a class="navbar-brand" href="index.php?Section=Start&Action=ShowDashboard"><img src="img/80x80.png" alt="" class="SystemLogo" />Schichtplanner</a>

  <!-- Collapse button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
    aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon">
		<i class="fas fa-bars"></i>
	</span>
	
  </button>

  <!-- Collapsible content -->
  <div class="collapse navbar-collapse" id="basicExampleNav">
    <!-- Links -->
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php?Section=Start&Action=ShowDashboard">Mein Plan
          <span class="sr-only">(current)</span>
        </a>
      </li>
      
	  
	  <?php
	  
	  if( $this->IsAdmin )
	  {
		 echo '
			<li class="nav-item">
				<a class="nav-link" href="index.php?Section=Planing&Action=ShowEditPlans">Planen</a>
			</li>

		 <!--<li class="nav-item">
			<a class="nav-link" href="index.php?Section=Start&Action=ShowEditPlanTemplate">Vorlage bearbeiten</a>
		  </li>-->
		  

		  
		  
		  <li class="nav-item">
			<a class="nav-link" href="index.php?Section=Planing&Action=ShowCreateIllMessage">Mitarbeiter krank melden</a>
		  </li>
		  
		  	<li class="nav-item">
			<a class="nav-link" href="index.php?Section=Start&Action=ShowManagement">Stammdaten bearbeiten</a>
		  </li>
		  
		  
		  
		  
		  ';
		  
		  
	  } else 
	  {
		  echo '
			<li class="nav-item">
				<a class="nav-link" href="index.php?Section=Planing&Action=ShowEditPlans">Wochenplan</a>
			</li>';  
	  }
	  ?>
	  
		<!-- <li class="nav-item">
			<a class="nav-link" href="index.php?Section=Holiday&Action=ShowPlan">Urlaub Planen</a>
		</li> -->
	  
	  
	  <li class="nav-item">
        <a class="nav-link link Link" href="index.php?Section=Login&Action=UserLogout">Logout (<?php echo $this->User->getName() ;?>)</a>
      </li>
	  

      <!-- Dropdown 
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false">Dropdown</a>
        <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>-->

    </ul>
    <!-- Links -->

    <!--<form class="form-inline">
      <div class="md-form my-0">
        <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
      </div>
    </form>-->
  </div>
  <!-- Collapsible content -->

</nav>
<!--/.Navbar-->