<?php
// include 'tpl_MailHeader.php';
?>

<body>
    <div class="container " style="width:100%">
        <h1 class="MainHeader" style="width:100%">Shiftplaner-Krankmeldung</h1>

        Der nachfolgende Mitarbeiter hat sich krank gemeldet.

        <table class="table" style="width:100%">

                <?php 
				
				echo $this->arrayToHtml( $this->Illdata , true );
				// exit();
                ?>
        </table>
    </div>
</body>

</html>