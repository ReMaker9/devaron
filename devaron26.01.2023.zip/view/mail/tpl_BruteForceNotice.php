<?php
include 'tpl_MailHeader.php';
?>

<body>
    <div class="container " style="width:100%">
        <h1 class="MainHeader" style="width:100%">Shiftplaner-Login: IP wurde blockiert (Brute-Force-Schutz)</h1>

        Durch folgende Login-Versuche kam es zu einer IP-Blockierung:

        <table class="table" style="width:100%">

                <tr>
                    <td>Id</td>
                    <td>CreateDate</td>
                    <td>UserId, Table</td>
                    <td>IP</td>
                    <td>UserName</td>
                </tr>

                <?php 
                foreach( $this->LastLogins as $Login) 
                {
                    echo "
                    <tr>
                        <td>{$Login->getId()}</td>
                        <td>{$Login->getCreateDate()}</td>
                        <td>{$Login->getUserId()}, {{$Login->getUserTable()}}</td>
                        <td>{$Login->getIp()}</td>
                        <td>{$Login->getUserName()}</td>
                    </tr>
                    ";
                } 
                ?>
        </table>
    </div>
</body>

</html>