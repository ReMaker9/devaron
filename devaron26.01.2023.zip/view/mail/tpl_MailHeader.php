<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="utf-8">
    <title><?php echo $this->MailTitle;?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="IT Servie Herzog">
    <link href="<?php echo BASE_URL;?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo BASE_URL;?>css/screen.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo BASE_URL;?>css/main.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo BASE_URL;?>css/mail.css" rel="stylesheet" type="text/css" />
</head>