    <?php
        include("tpl_HeaderStart.php");
    ?><div class="container">
    <div class='col-md-12 col-xs-12 content'>
        <div class="ContentLayer">
            <div class="row Options">
                <div class="col-xs-12 MainTeaser">
                    <h1>Hilfe</h1>
                    <h3 class="section-heading " id="FormMessage"></h3>
                    <div class="col-xs-12">
                        
                        
                        <ul>
                            <li>Allgemeine Hilfe</li>
                                
                        </ul>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




