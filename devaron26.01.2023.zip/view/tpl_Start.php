<div >
    
    <?php
        include("tpl_HeaderStart.php");
    ?>
    
    <div class="containerWidth">
        <div class='col-md-12 col-xs-12 nopadding content'>
            <div class="row header">
                <div class='col-md-12 mt-3 mb-1'><h1>Mein Schichtplan<h1></div>
            </div>

            
        </div> 

    </div>
    
    <div class="containerWidth">
        <div class='col-md-12 col-xs-12 nopadding content'>
           
		   
		   	<div class='row mb-1 Header'>
			<div class='col-3'>Tag </div>
			<div class='col'>Anlage</div>
			<div class='col'>Schicht</div>
			<div class='col'>Schicht Komentar</div>
			</div>
		   
		   
		<?php
		$Tage = array("Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag");
		
		foreach($this->PlanningentryCollection as $Planningentry )
		{
			$PlaningTemplate = $this->PlaningtemplateCollection->getById( $Planningentry->getPlaningTemplateId() ) ;
			$TimeStamp = strtotime($Planningentry->getDate());
			//echo $Planningentry->getPlaningTemplateEntryId();
			
			$PlaningTemplateEntryType = $this->PlaningtemplateentrytypeCollection->getById( $Planningentry->getPlaningTemplateEntryId() ) ;
			$Comment = $this->CommentCollection[ date( "W", $TimeStamp ) ];
			
			
			//var_dump( $Comment );
			
			
			
			echo "<div class='row pb-2 striped'>
			<div class='col-3'> " . $Tage[ date( "w", $TimeStamp ) ] . " " . Date::getGermanDate( $Planningentry->getDate() )  . "</div>
			<div class='col'>" . $PlaningTemplateEntryType->getName() . "</div>
			<div class='col'>" . $PlaningTemplate->getName() . "</div>
			<div class='col'>" . $Comment['s_Value'] . "</div>
			</div>";
			
		}
		
		
		
		
		
		
		?>




		   
        </div> 

    </div>
    
    
    
</div>
<script>
    $(function ()
    {
       // Hier events über die Engine setzten
       // Engine.Controler.initWas();
    });
</script>