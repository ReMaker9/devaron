<?php
        include("tpl_HeaderSmall.php");
    ?><div id="" class="SystemContainer container"> 
    <div class="container">

        <div class='col-md-12 col-xs-12 content'>

            <div class="ContentLayer">

                <div role="navigation" class="navbar navbar-fixed-top MobileNavi">
                    <div class="navbar-header">
                        <a class="PanelMenuToggle" href="#PanelMenu"><i class="fa fa-bars"></i></a>
                    </div>
                </div>

                <div class="row Options">

                    <div class="col-xs-12 MainTeaser">
                        <h1>Seite nicht gefunden!</h1>
                        <p>Die ausgewählte Seite wurde leider nicht gefunden. </p>
                    </div>

                </div>

                </div>
</div>


            </div>

