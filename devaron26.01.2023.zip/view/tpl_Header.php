<!DOCTYPE html>
<html lang="en">
	<head>
        <base href="<?php echo $this->BaseUrl; ?>">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $this->Title ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="Content-Language" content="de" />
        <meta name="author" content="IT Service Herzog" />
        <meta name="KeyWords" content="<?php echo $this->KeyWords ?>" />
        <meta name="Description" content="<?php echo $this->MetaDescription ?>" />
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/fontawesome-all.min.css" rel="stylesheet">
        <link href="css/print.css" rel="stylesheet" type="text/css" media="print" />
		<link href="css/screen.css" rel="stylesheet" type="text/css" />
        <link href="css/main.css" rel="stylesheet" type="text/css"  />
		<link href="css/mobile.css" rel="stylesheet" type="text/css" />
        <link href="css/jquery-confirm.min.css" rel="stylesheet" type="text/css"  />
        <link href="css/animate.css" rel="stylesheet" type="text/css"  />
        
      
        <script src="./js/ext/jquery-3.4.1.min.js"></script>
        <script src="js/ext/bootstrap.min.js"></script>
		<link rel="icon" type="image/png" href="favicon.png" />
		
		<link rel="apple-touch-startup-image" href="img/640x1136.png" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2) and (orientation: landscape)">
		<link rel="apple-touch-startup-image" href="img/750x1294.png" media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2) and (orientation: landscape)">
		<link rel="apple-touch-startup-image" href="img/1242x2148.png" media="(device-width: 414px) and (device-height: 736px) and (-webkit-device-pixel-ratio: 3) and (orientation: landscape)">
		<link rel="apple-touch-startup-image" href="img/1125x2436.png" media="(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) and (orientation: landscape)">
		<link rel="apple-touch-startup-image" href="img/1536x2048.png" media="(min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: landscape)">
		<link rel="apple-touch-startup-image" href="img/1668x2224.png" media="(min-device-width: 834px) and (max-device-width: 834px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: landscape)">
		<link rel="apple-touch-startup-image" href="img/2048x2732.png" media="(min-device-width: 1024px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: landscape)">
		
		
		<link rel="apple-touch-icon" href="img/80x80.png">
		<link rel="apple-touch-icon" sizes="152x152" href="img/152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="img/180x180.png">
		<link rel="apple-touch-icon" sizes="167x167" href="img/167x167.png">
		
		<link rel="manifest" href="schichtplan.webmanifest">
		
		
    </head>
    <body style="">
        <div class="ContentLayer container width" id="Content">
    
	 
	 







