
<!-- User -->
<div id="tpl_SearchResultRowUser">
    <div class="SearchResultEntry row " data-type=":ClassType:">
        <div class="SearchResultEntryButtonGroup col-sm-9">
            <div class="SearchResultEntryValue">
                <i class="fas fa-building"></i>
            </div>
            <div class="SearchResultEntryValue col-sm-7 text-truncate" title=":Name:">:Name:</div>
            <div class="SearchResultEntryValue col-sm-3 text-truncate" title=":Town:">:Town:</div>
        </div>
        <div class="SearchResultEntryButtonGroup row">
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchShow">
                    <i class="fas fa-search-plus"></i>
                </button>
            </div>
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchEdit">
                    <i class="fas fa-edit"></i>
                </button>
            </div>
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button onclick="" data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchDeaktivate">
                    <i class="fas fa-times-circle"></i>
                </button>
            </div>
        </div>
    </div>
</div>

