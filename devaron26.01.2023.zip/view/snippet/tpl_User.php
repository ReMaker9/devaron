<div id="tpl_SearchResultRow">
    <div class="SearchResultEntry row deactivated:Active:" data-type=":ClassType:">
        <div class="SearchResultEntryButtonGroup col-sm-9">
            <div class="SearchResultEntryValue">
                <i class="fas fa-user-ninja"></i>
            </div>
            <div class="SearchResultEntryValue col-sm-5 text-truncate" title=":Name:">:Name:</div>
            <div class="SearchResultEntryValue col-sm-5 text-truncate" title=":Town:">:Mail:</div>
        </div>
        <div class="SearchResultEntryButtonGroup row">
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchShow">
                    <i class="fas fa-search-plus"></i>
                </button>
            </div>
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchEdit">
                    <i class="fas fa-edit"></i>
                </button>
            </div>
            <div class="SearchResultEntryButtonDiv col-sm-3">
                <button onclick="" data-type=":ClassType:" data-id=":Id:" class="btn SearchResultEntryButton btn_SearchDeaktivate">
                    <i class="fas fa-times-circle"></i>
                </button>
            </div>
        </div>
    </div>
</div>