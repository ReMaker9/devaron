<div class="PlaningContainer col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-4 <?php echo $PlaningTemplate['Id'];?>">
    
	<div class="">
		<div class="col-12 PlaningName "><?php echo $PlaningTemplate['Name']; ?></div>
		

		<table class="table table-hover table-bordered table-striped">
		
		<th>
			<td>Mo <?php echo date("d.m", strtotime($Year."W".$Week."1"));?></td>
			<td>Di <?php echo date("d.m", strtotime($Year."W".$Week."2"));?></td>
			<td>Mi <?php echo date("d.m", strtotime($Year."W".$Week."3"));?></td>
			<td>Do <?php echo date("d.m", strtotime($Year."W".$Week."4"));?></td>
			<td>Fr <?php echo date("d.m", strtotime($Year."W".$Week."5"));?></td>
			<td>Sa <?php echo date("d.m", strtotime($Year."W".$Week."6"));?></td>
			<td>Kom.</td>
		</th>

		<?php
		
		$SelectedUserIdArray = array();
		
		
		$PlaningEntryCollection = $PlaningEntryCollection->getByPlaningTemplateId( $PlaningTemplate['Id'] );
		
		$DowntimesShift = $DowntimesCollection->getByShift( $Shift );
		
		$PlanElements = $PlaningTemplate['Elements'];
		// var_dump( $DowntimesShift ); exit();
		

		/*var_dump( $PlaningTemplate['Id'] );
			 
		var_dump( $PlaningEntryCollection );
			
		exit();*/
		
		
		
		$DayCounter = 0;
		foreach( $PlanElements as $Element )
		{
			$PlaningTemplateEntryType = $PlaningTemplateEntryTypeCollection->getById( $Element['PlaningTemplateEntryType'] );
			$LinesNeeded = $Element['Lines'];
			
			$DowntimesPlanningType = $DowntimesShift->getByPlaningTemplateEntryTypeId( $Element['PlaningTemplateEntryType'] );
			
			
			$PlaningEntryTempCollection = $PlaningEntryCollection->getByPlaningTemplateEntryId( $PlaningTemplateEntryType->getId() ); // filtern nach den Type
			
			$TempColorCollection = $ColorCollection->getByDay( 1 )->getByDataId( $PlaningTemplateEntryType->getId() ) ;
			
			// var_dump( $TempColorCollection ); exit();
			
			echo '<tr class="PlaningTemplateEntryType'.$PlaningTemplateEntryType->getId() . ' PlaningTemplateEntryType" style="background-color:#' . $PlaningTemplateEntryType->getColor() . ';color:'.  Utility::colorInverse( $PlaningTemplateEntryType->getColor() ) .'" >
			<td class="font-weight-bold TableLable">' . $PlaningTemplateEntryType->getName() . ' </td>
			<td class="p-0">';
			
			$NowDate = date("Y-m-d", strtotime($Year."W".$Week."1"));
			
			
			$DowntimeNow = $DowntimesPlanningType->getByDownDate( $NowDate );

			$Planing1 = $PlaningEntryTempCollection->getByDate( $NowDate ) ;
			for( $i = 0; $i< $LinesNeeded; $i++ )
			{
				$Planing1Temp = $Planing1->getBysort( $i );
				$TempColorCollection1 = $TempColorCollection->getBySort($i)->getByIndex(0) ;
				$BgColor = "";
				if($TempColorCollection1->getId())
				{
					$BgColor = $TempColorCollection1->getValue();
				}
				
				if( $DowntimeNow->getByIndex(0)->getId() ) 
				{
					$BgColor = "98f5ff";
				}
				
				$ActiveUser = $UserCollection->getById( $Planing1Temp->getByIndex(0)->getUserId() );
				$SelectedUserIdArray [$Planing1Temp->getByIndex(0)->getUserId()] = 1 ;
				echo '<div style="background-color:#' . $BgColor .'" data-planing-template-entry-id="' . $PlaningTemplateEntryType->getId() . '" data-planing-template-id="' . $PlaningTemplate['Id'] . '" data-id="' . $Element['Id'] . '" data-day="1" data-index="' . $i . '"  class="NamePanel ' . $ActiveUser->getLeasedClass() . ' " title="' . $ActiveUser->getName() . '" data-user-id="' . $ActiveUser->getId() . '" >' . $ActiveUser->getName() . '</div>';
			
			}
			

			echo '</td>
			<td class="p-0">';
			
			$NowDate = date("Y-m-d", strtotime($Year."W".$Week."2"));
			$DowntimeNow = $DowntimesPlanningType->getByDownDate( $NowDate);
			$TempColorCollection = $ColorCollection->getByDay( 2 )->getByDataId( $PlaningTemplateEntryType->getId() ) ;
			$Planing = $PlaningEntryTempCollection->getByDate( $NowDate ) ;
			
			/*if($PlaningTemplateEntryType->getId() == 12 &&  $PlaningTemplate['Name'] == "Nacht Schichtleiter / Einsteller / Krank/ Urlaub")	
				{			
					//var_dump(  $Planing  );
					var_dump( $Planing->getBysort( 0 ) ); 
					var_dump( $Planing->getBysort( 1 ) ); 
					
					
					
					/* var_dump( $ActiveUser->getName() );
					var_dump( $Planing1Temp );
					var_dump( $PlaningTemplateEntryType->getId()  ); 
					exit();
				}*/
			
			for( $i = 0; $i< $LinesNeeded; $i++ )
			{
				$PlaningTemp = $Planing->getBysort( $i );
				$TempColorCollection1 = $TempColorCollection->getBySort($i)->getByIndex(0) ;
				$ActiveUser = $UserCollection->getById( $PlaningTemp->getByIndex(0)->getUserId() );
				$BgColor = "";
				if($TempColorCollection1->getId())
				{
					$BgColor = $TempColorCollection1->getValue();
				}
				
				if( $DowntimeNow->getByIndex(0)->getId() ) 
				{
					$BgColor = "98f5ff";
				}
				
				
				
				/*if($PlaningTemplateEntryType->getId() == 12 && $i == 1 && $PlaningTemplate['Name'] == "Nacht Schichtleiter / Einsteller / Krank/ Urlaub")	
				{			
					//var_dump(  $PlaningTemp  );
					
					
					var_dump( $ActiveUser );
					//var_dump( $PlaningTemp ); 
					// var_dump( $ActiveUser->getName() );
					var_dump( $Planing1Temp );
					var_dump( $PlaningTemplateEntryType->getId()  ); 
					exit();
				}*/
				
				
				
				//$ActiveUser = $UserCollection->getById( $PlaningTemp->getByIndex(0)->getUserId() );
				echo '<div style="background-color:#' . $BgColor .'"  data-planing-template-entry-id="' . $PlaningTemplateEntryType->getId() . '"  data-planing-template-id="' . $PlaningTemplate['Id'] . '"  data-id="' . $Element['Id'] . '"  data-day="2"  data-index="' . $i . '"  class="NamePanel ' . $ActiveUser->getLeasedClass() . '" title="' . $ActiveUser->getName() . '" data-user-id="' . $ActiveUser->getId() . '" >' . $ActiveUser->getName() . '</div>';
			}
			
			echo '</td>
			<td class="p-0">';
			
			$NowDate = date("Y-m-d", strtotime($Year."W".$Week."3"));
			$DowntimeNow = $DowntimesPlanningType->getByDownDate( $NowDate);
			$TempColorCollection = $ColorCollection->getByDay( 3 )->getByDataId( $PlaningTemplateEntryType->getId() ) ;
			$Planing = $PlaningEntryTempCollection->getByDate( $NowDate ) ;
			for( $i = 0; $i< $LinesNeeded; $i++ )
			{
				$PlaningTemp = $Planing->getBysort( $i );
				$TempColorCollection1 = $TempColorCollection->getBySort($i)->getByIndex(0) ;
				$ActiveUser = $UserCollection->getById( $PlaningTemp->getByIndex(0)->getUserId() );
				$BgColor = "";
				if($TempColorCollection1->getId())
				{
					$BgColor = $TempColorCollection1->getValue();
				}
				if( $DowntimeNow->getByIndex(0)->getId() ) 
				{
					$BgColor = "98f5ff";
				}
				echo '<div style="background-color:#' . $BgColor .'"  data-planing-template-entry-id="' . $PlaningTemplateEntryType->getId() . '"  data-planing-template-id="' . $PlaningTemplate['Id'] . '"  data-id="' . $Element['Id'] . '"  data-day="3"  data-index="' . $i . '"  class="NamePanel ' . $ActiveUser->getLeasedClass() . '" title="' . $ActiveUser->getName() . '" data-user-id="' . $ActiveUser->getId() . '" >' . $ActiveUser->getName() . '</div>';
			}
			echo '</td>
			<td class="p-0">';
			
			$NowDate = date("Y-m-d", strtotime($Year."W".$Week."4"));
			$DowntimeNow = $DowntimesPlanningType->getByDownDate( $NowDate);
			$TempColorCollection = $ColorCollection->getByDay( 4 )->getByDataId( $PlaningTemplateEntryType->getId() ) ;
			$Planing = $PlaningEntryTempCollection->getByDate( $NowDate ) ;
			for( $i = 0; $i< $LinesNeeded; $i++ )
			{
				$PlaningTemp = $Planing->getBysort( $i );
				$TempColorCollection1 = $TempColorCollection->getBySort($i)->getByIndex(0) ;
				$ActiveUser = $UserCollection->getById( $PlaningTemp->getByIndex(0)->getUserId() );
				$BgColor = "";
				if($TempColorCollection1->getId())
				{
					$BgColor = $TempColorCollection1->getValue();
				}
				
				if( $DowntimeNow->getByIndex(0)->getId() ) 
				{
					$BgColor = "98f5ff";
				}
				echo '<div style="background-color:#' . $BgColor .'"  data-planing-template-entry-id="' . $PlaningTemplateEntryType->getId() . '"  data-planing-template-id="' . $PlaningTemplate['Id'] . '"  data-id="' . $Element['Id'] . '"  data-day="4"  data-index="' . $i . '"  class="NamePanel ' . $ActiveUser->getLeasedClass() . '" title="' . $ActiveUser->getName() . '" data-user-id="' . $ActiveUser->getId() . '" >' . $ActiveUser->getName() . '</div>';
			}
			echo '</td>
			<td class="p-0">';
			
			$NowDate = date("Y-m-d", strtotime($Year."W".$Week."5"));
			$DowntimeNow = $DowntimesPlanningType->getByDownDate( $NowDate);
			$TempColorCollection = $ColorCollection->getByDay( 5 )->getByDataId( $PlaningTemplateEntryType->getId() ) ;
			$Planing = $PlaningEntryTempCollection->getByDate( $NowDate ) ;
			for( $i = 0; $i< $LinesNeeded; $i++ )
			{
				$PlaningTemp = $Planing->getBysort( $i );
				$TempColorCollection1 = $TempColorCollection->getBySort($i)->getByIndex(0) ;
				$ActiveUser = $UserCollection->getById( $PlaningTemp->getByIndex(0)->getUserId() );
				$BgColor = "";
				if($TempColorCollection1->getId())
				{
					$BgColor = $TempColorCollection1->getValue();
				}
				if( $DowntimeNow->getByIndex(0)->getId() ) 
				{
					$BgColor = "98f5ff";
				}
				echo '<div style="background-color:#' . $BgColor .'"   data-planing-template-entry-id="' . $PlaningTemplateEntryType->getId() . '"  data-planing-template-id="' . $PlaningTemplate['Id'] . '"  data-id="' . $Element['Id'] . '"  data-day="5"  data-index="' . $i . '"  class="NamePanel ' . $ActiveUser->getLeasedClass() . '" title="' . $ActiveUser->getName() . '" data-user-id="' . $ActiveUser->getId() . '" >' . $ActiveUser->getName() . '</div>';
			}
			echo '</td>
			<td class="p-0">';
			
			$NowDate = date("Y-m-d", strtotime($Year."W".$Week."6"));
			$DowntimeNow = $DowntimesPlanningType->getByDownDate( $NowDate);
			$TempColorCollection = $ColorCollection->getByDay( 6 )->getByDataId( $PlaningTemplateEntryType->getId() ) ;
			$Planing = $PlaningEntryTempCollection->getByDate( $NowDate ) ;
			for( $i = 0; $i< $LinesNeeded; $i++ )
			{
				$PlaningTemp = $Planing->getBysort( $i );
				$TempColorCollection1 = $TempColorCollection->getBySort($i)->getByIndex(0) ;
				$ActiveUser = $UserCollection->getById( $PlaningTemp->getByIndex(0)->getUserId() );
				$BgColor = "";
				if($TempColorCollection1->getId())
				{
					$BgColor = $TempColorCollection1->getValue();
				}

				if( $DowntimeNow->getByIndex(0)->getId() ) 
				{
					$BgColor = "98f5ff";
				}

				echo '<div style="background-color:#' . $BgColor .'"  data-planing-template-entry-id="' . $PlaningTemplateEntryType->getId() . '"  data-planing-template-id="' . $PlaningTemplate['Id'] . '"  data-id="' . $Element['Id'] . '"  data-day="6"  data-index="' . $i . '"  class="NamePanel ' . $ActiveUser->getLeasedClass() . '" title="' . $ActiveUser->getName() . '" data-user-id="' . $ActiveUser->getId() . '" >' . $ActiveUser->getName() . '</div>';
			}
			echo '</td>';
			
			$CommentValue = "";
			$CommentElement = $CommentCollection->getByDataId( $Element['Id'] )->getByIndex( 0 );
			
			if( $CommentElement->getId() ) 
			{
				$CommentValue = $CommentElement->getValue();
				/*var_dump( $CommentElement ); //exit();
				var_dump( $Element );
				exit();*/
				
				
			}
				
			
			
			echo '<td class="p-1"><input title="' . $CommentValue . '" value="' . $CommentValue . '" data-planing-template-id="' . $PlaningTemplate['Id'] . '"  data-id="'.$Element['Id'] .'" type="text" class="PlanningComment '.$Element['Id'] .'"></td>
			
			</tr>';
		}

			
		?>
		
		</table> 
	</div>
	
<?php 
 // var_dump( $UserCollection ); 
?>
	
	
	
	
	
</div>