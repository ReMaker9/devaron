<?php
include("tpl_HeaderMap.php");
?>
<div class=" Content"> 



    <div class="container">

        <div class='col-md-12 col-xs-12 content'>

            <div class="ContentLayer">

                <div role="navigation" class="navbar navbar-fixed-top MobileNavi">

                    <div class="navbar-header">
                        <a class="PanelMenuToggle" href="#PanelMenu"><i class="fa fa-bars"></i></a>

                    </div>
                    
                </div>





                <div class="row Options">

                    <div class="col-xs-12 MainTeaser">
                        <h2>Fehler</h2>
                        <p><?php echo $this->ErrorString; ?></p>

                    </div>



                </div>

                <?php
                //include("tpl_SubNavi.php");
                ?>


                


                </div>
</div>







            </div>

