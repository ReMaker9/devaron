<?php

class OrmCreator
{

    private $DatabaseConection;
    private $Agruments;

    public function start( $argv )
    {
        $this->Agruments = $argv;
//        printf(__FILE__);

        if ( in_array($argv[1], array('--help', '-help', '-h', '-?')) )
        {
            $this->showHelp();
            return;
        }
        switch ( $argv[1] )
        {
            case "-i":
                {
                    $this->installFramework();
                } break;

            case "-ug":
                {
                    $this->updateGenerator();
                } break;

            case "-v":
                {
                    $this->getVersion();
                } break;

            case "-tn":
                {
                    $this->showTableNames();
                } break;

            case "-c":
                {
                    $this->createClass();
                    die("");
                } break;

            case "-o":
                {
                    if ( isset($argv[2]) )
                    {
                        $this->createORM4Table($argv[2]);
                    } else
                    {
                        $this->createORM4Table();
                    }
                } break;

            case "-k":
                {
                    $this->compressFile();
                } break;

            case "-kj":
                {
                    $this->compressJs();
                } break;

            case "-q":
                {
                    printf("Programm beendet");
                    die("");
                } break;

            case "-cdb":
                {
                    $this->checkDataBaseConnection();
                } break;
            
            case "-compdb":
                {
                    $this->compaireDatabase();
                } break;
            

            case "-cdborm": // create database 
                {
                    $this->generateORMFromDatabase();
                } break;

            case "-t": // create form from tbl 
                {
                    $this->generateTemplates($argv[2]);
                } break;

            case "-dt": // create deviceconfig Templates form from Userinput 
                {
                    $this->generateDeviceTemplates($argv[2]);
                } break;

            
            
            case "-fdb": // create form from db 
                {
                    $this->generateTemplatesDB($argv[2]);
                } break;

            default:
                $this->showHelp();
                die("");
        }
    }

    public function showHelp()
    {
        printf("\n*** Hilfe des Devaron-Generators ***\n\n");
        printf("Parameter:\n\n");

        printf("  System:\n");
        printf("    -i       Installiert das Devaron-Framework.\n");
        printf("    -ug      Aktualisiert den Generator auf die neueste Version.\n");
        printf("    -v       Gibt die Version des Generators zurück.\n");
        printf("    -cdb     Prüft die Datenbank-Verbindung.\n");
        printf("    -tn       Gibt alle Tabellennamen der aktuellen Datenbank aus.\n");
        printf("\n");
        printf("  ORM:\n");
        printf("    -o       Erstellt ORM-Klassen von der angegeben Tabelle.\n");
        printf("    -cdborm  Erstellt alle ORM-Klassen der aktuellen Datenbank.\n");
        printf("    -compdb  vergleicht 2 Datenbanken.\n");
        printf("\n");
        printf("  Template:\n");
        printf("    -t       Erstellt Templates für Form und Data-Show von der angegeben Tabelle.\n");
        printf("             Kann in der Syntax '-t tbl_name -p' genutzt werden für Ausgabe mit HTML-Frame und CSS-Links.\n");
        printf("    -dt      Erstellt Templates für devices.\n");
        printf("    -tdb     Erstellt Templates für alle Forms und Data-Shows der aktuellen Datenbank.\n");
        printf("\n");
        printf("  Anderes:\n");
        printf("    -c       Erstellt eine neue Klasse PHP, JS.\n");
        printf("    -k       Komprimiert JS- oder CSS-Datei.\n");
        printf("    -kj      Durchsucht die index.html,komprimiert alle JS- und CSS-Dateien und legt diese in die main.js und main.css.\n");
    }

    public function compaireDatabase()
    {
        // erste db laden
        
        define("LOG_SQL", true);
        
        require_once ("../cfg/cfg.php");
        require_once ("../class/db/cls_abstractDb.php");
        require_once ("../class/db/cls_dbPdo.php");
        require_once ("../class/lib/cls_Logger.php");

        $this->DatabaseConection = PdoDataBase::getInstance();
        
        $DB1Json = json_decode( file_get_contents("../cfg/db1.json") );
        
        var_dump($DB1Json);
        $this->DatabaseConection->close();
        $this->DatabaseConection->setDataBase($DB1Json->DATABASE);
        $this->DatabaseConection->setPassWord($DB1Json->PASS);
        $this->DatabaseConection->setUser($DB1Json->USER);
        $this->DatabaseConection->setIP($DB1Json->SERVER);
         $this->DatabaseConection->setPort($DB1Json->PORT );
        $State = $this->DatabaseConection->connect();
        //var_dump( $State );
        printf("Db wird gelesen\n");
        //exit();

        $TableArray = $this->DatabaseConection->executeQuery("SHOW TABLES;");
        //var_dump($TableArray);
        $ResultSet = array();
        
        foreach( $TableArray as $Table )
        {
            $Table = $Table["Tables_in_" . $DB1Json->DATABASE];
            $TableData = array();
            $TableData = $this->DatabaseConection->executeQuery("DESCRIBE " . $Table . ";");
            $ResultSet[$Table] = $TableData;
        }
        
        //var_dump( $ResultSet );
        printf("Datenbank 1 gelesen");
        
        
        $DB2Json = json_decode( file_get_contents("../cfg/db2.json") );
        
        var_dump($DB2Json);
        $this->DatabaseConection->close(); // heir die alte verbindung  zu machen
        $this->DatabaseConection->setDataBase($DB2Json->DATABASE);
        $this->DatabaseConection->setPassWord($DB2Json->PASS);
        $this->DatabaseConection->setUser($DB2Json->USER);
        $this->DatabaseConection->setIP($DB2Json->SERVER);
        $this->DatabaseConection->setPort($DB2Json->PORT );
        $State = $this->DatabaseConection->connect();
        //var_dump($State);
        if ( !$this->DatabaseConection->isConnected() )
        {
            printf("zu db 2 kann keine verbindung hergestellt werden\n");
            return False;
        }
        
        
        printf("Db wird gelesen\n");

        $TableArray = $this->DatabaseConection->executeQuery("SHOW TABLES;");
        //var_dump($TableArray);
        $ResultSet2 = array();
        
        foreach( $TableArray as $Table )
        {
            $Table = $Table["Tables_in_" . $DB2Json->DATABASE];
            $TableData = array();
            $TableData = $this->DatabaseConection->executeQuery("DESCRIBE " . $Table . ";");
            $ResultSet2[$Table] = $TableData;
        }
        
        
        foreach($ResultSet as $Key => $Row)
        {
            if(isset($ResultSet2[$Key]))
            {
                printf(  $Key . " Prüfung \n");
            }else
            {
                printf( "Error: Tabelle " . $Key . " exsistiert nicht in der zweiten db \n");
            }
            
            printf(  $Key . " Col- Prüfung\n");
            foreach($ResultSet[$Key] as $ColKey => $Col)
            {
                
                if( @$ResultSet[$Key][$ColKey]['Field'] != @$ResultSet2[$Key][$ColKey]['Field'])
                {
                    printf( "Error: Tabelle " . $Key . " Spalte " . $ResultSet[$Key][$ColKey]['Field'] .  " exsistiert\n");
                }
                
                if( @$ResultSet[$Key][$ColKey]['Type'] != @$ResultSet2[$Key][$ColKey]['Type'])
                {
                    printf( "Error: Tabelle " . $Key . " Spalte " . $ResultSet[$Key][$ColKey]['Field'] .  " Type Stimmt nicht\n");
                }
                
                if( isset($ResultSet[$Key][$ColKey]['Key']) &&  @$ResultSet[$Key][$ColKey]['Key'] != @$ResultSet2[$Key][$ColKey]['Key'])
                {
                    printf( "Error: Tabelle " . $Key . " Spalte " . $ResultSet[$Key][$ColKey]['Field'] .  " Key Stimmt nicht\n");
                }
                
                /*if( $ResultSet[$Key][$ColKey]['Null'] != $ResultSet2[$Key][$ColKey]['Null'])
                {
                    printf( "color 0C\nError: Tabelle " . $Key . " Spalte " . $ResultSet[$Key][$ColKey]['Field'] .  " Null Stimmt nicht\n");
                }*/
                
                if( @$ResultSet[$Key][$ColKey]['Default'] != @$ResultSet2[$Key][$ColKey]['Default'])
                {
                    printf( "Error: Tabelle " . $Key . " Spalte " . $ResultSet[$Key][$ColKey]['Field'] .  " Null Stimmt nicht\n");
                }
                
                // if( isset($ResultSet2[$Key][0]['Field'] )
                
                
            }
            
            
            
            
            
            
            
        }
        
        
        
        
        
        
        
        printf("Vergleich abgeschlossen");
        
        
        
        
        
        
        
    }
    
    
    public function installFramework()
    {
        echo "\n*** INSTALLATION DEVARON-FRAMEWORK ***\n\n";

        echo " Soll das Devaron-Framework installiert werden? \n Bestehende Dateien können dabei verloren gehen! (y/n)\n";
        $Input = $this->getInput();

        if ( $Input === "yes" || $Input === "y" )
        {
            echo " Verbindungsaufbau mit https://entwickler.tools/devaron...\n";
            echo " Lade aktuelle Framework-Version herunter...\n";

            $file = file_get_contents("https://entwickler.tools/devaron/devaron.zip");
            file_put_contents("devaron.zip", $file);

            echo " Aktuelle Framework-Version erfolgreich herunter geladen.\n\n";

            $zip = new ZipArchive();
            $devaronZip = $zip->open("devaron.zip");

            if ( $devaronZip === TRUE )
            {
                $path = pathinfo(realpath("devaron.zip"), PATHINFO_DIRNAME);
                echo " Entpacke Framework...\n";
                $zip->extractTo($path);
                $zip->close();
                echo " Framework erfolgreich entpackt.\n";
            } else
            {
                echo " Framework konnte nicht geöffnet werden.\n";
                return;
            }

            unlink("devaron.zip");
            copy("generator.php", "utils/generator.php");
            unlink("generator.php");
            echo(" Diese generator.php wurde nach /utils verschoben und kann von dort aus mit 'php generator.php -ug' aktualisiert werden.\n\n");
            echo(" Devaron-Framework wurde erfolgreich installiert!\n");
        }
    }

    public function updateGenerator()
    {
        echo "\n\nGenerator jetzt aktualisieren? (y/n)\n";
        $Input = $this->getInput();

        if ( $Input == "yes" || $Input == "y" )
        {
            $fileTimeServer = file_get_contents("https://entwickler.tools/devaron/generator/checkGeneratorFileTime.php");
            $fileTimeLocal = filemtime("generator.php");

// Pr�fung, ob lokae Datei neuer ist
            if ( $fileTimeServer < $fileTimeLocal )
            {
                echo "\n\nLokale Datei neuer als Server-Datei!\nTrotzdem aktualisieren? (y/n)\n";
                $Input = $this->getInput();

                if ( $Input == "yes" || $Input == "y" )
                {
                    $this->performGeneratorUpdate();
                } else
                {
                    echo "Aktualisierung abgebrochen...\n";
                }
            } else
            {
                $this->performGeneratorUpdate();
            }
        }
    }

    public function performGeneratorUpdate()
    {
        echo "\n\nVerbindungsaufbau mit https://entwickler.tools/devaron... \n";
        $generator = file_get_contents("https://entwickler.tools/devaron/generator/generator.php.txt");
        echo "Erfolg!\n";
        file_put_contents("generator.php", $generator);
        echo "\nGenerator wurde aktualisiert!\n";
        $this->getVersion();
    }

    public function getVersion()
    {
        Printf("Version: 1.4.31\n");
        Printf("Last Edit: 24.07.2021 MH");
    }

    /**
     * zeigt die TABELLEN namen an und gibt die Tabellen als array zurück
     * @return type
     */
    public function showTableNames()
    {
        if ( !$this->DatabaseConection )
        {
            $this->checkDataBaseConnection(); // open database Connection
        }

        //var_dump(PDO_DRIVER); exit();
        
        switch(PDO_DRIVER)
        {
            case PDO_MYSQL:
                $Sql = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = '" . DB_DATABASE . "'";
                $IndexName = "tables_in_".DB_DATABASE;
                
                echo "\n " . $Sql . "\n\n";
                break;
            case PDO_PSQL:
                $Sql = "SELECT table_name as \"TABLE_NAME\" FROM information_schema.tables WHERE table_schema = '" . DB_SCHEME . "'";
                echo "\n " . $Sql . ":\n\n";
                $IndexName = "tables_in_".DB_SCHEME;
                break;
        }
        $Result = $this->DatabaseConection->executeQuery( $Sql );


        echo "\n Alle Tabellen von " . DB_DATABASE . ":\n\n";

        
        
        
        
        $Return = array ();
        
        foreach ( $Result as $TableName )
        {
            $Return[] = $TableName["TABLE_NAME"];
            echo " " . $TableName["TABLE_NAME"] . "\n";
        }
        echo "\n";
        
        return $Return;
    }

    public function checkDataBaseConnection()
    {
        require_once ("../cfg/cfg.php");
        require_once ("../class/db/cls_abstractDb.php");
        require_once ("../class/db/cls_dbPdo.php");
        require_once ("../class/lib/cls_Logger.php");

        $this->DatabaseConection = PdoDataBase::getInstance();

        
        
        
        $this->DatabaseConection->connect(); // zu datenbank verbinden
        
        //var_dump($this->DatabaseConection);
        
        if ( !$this->DatabaseConection->connect() )
        {
            printf("Es konnte keine Verbindung zum Datenbank-Server aufgebaut werden!\n");
            printf("Bitte prüfen Sie die Datenbank einstellungen.\n");
            printf("PDO_DRIVER " . PDO_DRIVER ."\n");
            printf("DB_SERVER " . DB_SERVER ."\n");
            printf("DB_Port " . DB_PORT ."\n");
            printf("DB_DATABASE " . DB_DATABASE ."\n");
            printf("DB_USER " . DB_USER ."\n");
            
            return false;
        }
        printf("\nDatenbank-Verbindung wurde aufgebaut!\n\n");
        return true;
    }

    public function compressJs()
    {
        $Index = file_get_contents("../index.hmtl");

        printf("not implemented!\n");
    }

    public function compressFile()
    {
        printf("\ngeben Sie den absoluten Pfad zur Datei an, die komprimiert werden soll\n");
        $Path = $this->getInput();
        $StartSize = filesize($Path);
        $Data = file_get_contents($Path); // datei laden
// bei js datein alle var xx sichern
        $Data = str_replace("var ", "/*var*/", $Data);
        $Data = str_replace(" ", "", $Data);
        $Data = str_replace("\r\n", "", $Data);
        $Data = str_replace("\n", "", $Data);
        $Data = str_replace("/*var*/", "var ", $Data);
        file_put_contents($Path, $Data); // datei schreiben
        $EndSize = filesize($Path);
        $Percent = $EndSize / $StartSize;
        printf("die datei wurde Komprimiert um " . $Percent . " %\n");
    }

    public function generateORMFromDatabase()
    {
        if ( !$this->checkDataBaseConnection() )
        {
            return;
        }

        $Result = $this->showTableNames();
        foreach ( $Result as $Table )
        {
            print_r($Table );
            //continue;
            $this->createORM4Table($Table);
        }
    }

    
    protected function getColumsFromTable($TableName)
    {
        $Fields = array();
        
        switch(PDO_DRIVER)
        {
            case PDO_MYSQL:
                        $Sql = "SHOW COLUMNS FROM " . $TableName;
                $Result = $this->DatabaseConection->executeQuery($Sql);
                
                foreach ( $Result as $Column )
                {
                    $Fields[] = $Column['Field'];
                    echo "\n" . $Column['Field'] . "\n";
                }
                
            break;
            
            case PDO_PSQL:
                $Sql ="SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = '" . DB_SCHEME . "'
                      AND table_name   = '" . $TableName . "'";
                
                echo "\n" .  $Sql . "\n";
                $Result = $this->DatabaseConection->executeQuery($Sql);
                foreach ( $Result as $Column )
                {
                    $Fields[] = $Column['column_name'];
                    echo  $Column['column_name'] . "\n";
                }
                
                break;
        }
        
        
        return $Fields;
    }
    
    
    
    /**
      erzeugt aus der angegeben mysql tabele eine php, js klasse + Finder und manager
     */
    public function createORM4Table( $TableName = "" )
    {
        if ( !$this->DatabaseConection )
        {
            $this->checkDataBaseConnection(); // open database Connection
        }

        if ( strlen($TableName) == 0 )
        {
//            echo getcwd() . "\n";
            printf("Geben Sie den Tabellennamen an der gemappt werden soll\n");
            $TableName = $this->getInput();
        }
        
        
        
        $Fields = $this->getColumsFromTable( $TableName );
        
        //exit("Jo");
        

        $ClearTableName = $this->clearDatabaseNames( $TableName );
        $this->createPHPClass($ClearTableName, $Fields);
        $this->createPHPCollectionClass($ClearTableName, $Fields);
        $this->createJSClass($ClearTableName, $Fields);

        
        
        switch(PDO_DRIVER)
        {
            case PDO_MYSQL:
                $this->createManager($TableName, $Fields);
                $this->createFinder($TableName, $Fields);
            break;
            
            case PDO_PSQL:
                $this->createManagerPostgres($TableName, $Fields);
                $this->createFinderPostgres($TableName, $Fields);
            break;
        
        }
        // erstelle finder und manager

        $this->registerORMGeneratedClasses($TableName);
        // klassen im autolod registrieren
        //$this->MySql->close();
    }

    private function getPrefix( $Name )
    {
        $Split = explode("_", $Name);
        return $Split[0];
    }

    /*
     * removed all Prefexes from table names
     */

    private function clearDatabaseNames( $Name )
    {
        $Replacment = array(
            "i_",
            "d_",
            "b_",
            "t_",
            "tbl_",
            "Tbl_",
            "v_",
            "s_",
            "t_",
            "f_"
        );
        $Name = str_replace($Replacment, "", $Name);
        return $Name;
    }

    private function registerORMGeneratedClasses( $TableName )
    {
        $TableName = ucfirst($this->clearDatabaseNames($TableName));
        $Path = pathinfo($this->Agruments[0]);
        $IncludeData = file_get_contents($Path['dirname'] . "/../class/logic/cls_Include.php");

// die letzte zeile entfernen
        $file = explode("\n", $IncludeData);
        $number = Count($file) - 1;
        unset($file[$number]);
        unset($file[$number + 1]);
        $IncludeData = implode("\n", $file);
// include lesen
// datein anfügen
        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('" . $TableName . "Manager','class/DatabaseObjects/cls_" . $TableName . "Manager.php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('" . $TableName . "Manager','class/DatabaseObjects/cls_" . $TableName . "Manager.php');\n";
        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('Base" . $TableName . "Manager','class/DatabaseObjects/base/cls_Base" . $TableName . "Manager.php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('Base" . $TableName . "Manager','class/DatabaseObjects/base/cls_Base" . $TableName . "Manager.php');\n";

        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('" . $TableName . "Finder','class/DatabaseObjects/cls_" . $TableName . "Finder.php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('" . $TableName . "Finder','class/DatabaseObjects/cls_" . $TableName . "Finder.php');\n";
        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('Base" . $TableName . "Finder','class/DatabaseObjects/base/cls_Base" . $TableName . "Finder.php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('Base" . $TableName . "Finder','class/DatabaseObjects/base/cls_Base" . $TableName . "Finder.php');\n";



        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('" . $TableName . "Collection','class/objects/cls_" . $TableName . "Collection.php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('" . $TableName . "Collection','class/objects/cls_" . $TableName . "Collection.php');\n";
        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('Base" . $TableName . "Collection','class/objects/base/cls_Base" . $TableName . "Collection.php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('Base" . $TableName . "Collection','class/objects/base/cls_Base" . $TableName . "Collection.php');\n";

        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('" . $TableName . "','class/objects/cls_" . $TableName . ".php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('" . $TableName . "','class/objects/cls_" . $TableName . ".php');\n";
        if ( strpos($IncludeData, "Basic_include_const::getInstance()->addPath('Base" . $TableName . "','class/objects/base/cls_Base" . $TableName . ".php');") === false )
            $IncludeData .= "Basic_include_const::getInstance()->addPath('Base" . $TableName . "','class/objects/base/cls_Base" . $TableName . ".php');\n";


//datei schreiben

        $IncludeData .= "\n?>";
        file_put_contents($Path['dirname'] . "/../class/logic/cls_Include.php", $IncludeData); // includ datei schreiben
        printf("Komponenten wurden registriert\n");
    }

    
    private function removeSystemFields( $FieldsArray )
    {
        $Keys = array();
        $Keys[] = array_search("i_Id", $FieldsArray);
        $Keys[] = array_search("d_CreateDate", $FieldsArray);
        //var_dump($Keys);
        foreach($Keys as $Key )
        {      
            if ( $Key ===false )
            {
                unset($FieldsArray[$Key]);
            }
        }
        //var_dump($FieldsArray);
        //exit();
        return $FieldsArray;
        
    }
    private function removeCreateDate( $FieldsArray )
    {
        $Key = array_search("d_CreateDate", $FieldsArray);
        if ( $Key )
        {
            unset($FieldsArray[$Key]);
        }
        return $FieldsArray;
    }

    private function createManager( $ClassName, $Fields )
    {
        $ClearName = ucfirst($this->clearDatabaseNames($ClassName));
        $Fields = $this->removeCreateDate($Fields); // wentfernt das createdate
        $CleanFields = $this->removeSystemFields($Fields);
        $SmallClassName = strtolower($ClassName);
        $Class = "<?php\n";
        $Class .= "class Base" . $ClearName . "Manager extends SystemManager\n{\n";

// Konstruktor anfang
        $Class .= "\n\tfunction __construct(";
        $Class .= ")\n\t{\n";
        $Class .= "\t\tparent::__construct();\n";
        $Class .= "\t}\n\n";
        
        $Class .= "\tprotected %Fields = array(" ;
         
        $i=1;
        foreach($Fields as $MyField )
        {
            $Class .= "'". $MyField ."'";
            if($i < count($Fields) )
            {
                $Class .= ",";
            }
            $i++;
        }        
        $Class .= ");\n\n";
        
        
        
// konstruktor ende	
// insert fkt
        $Class .= "\tpublic function insert" . $ClearName . "(" . $ClearName . " %" . $ClearName . ")\n";
        $Class .= "\t{\n";
        $Class .= "\t	%Sql=\"INSERT INTO `" . $SmallClassName . "`\n ";

        $Class .= "\t\t(" . implode(",", $CleanFields) . ")\n";


        $Class .= "\t	VALUES \n";
        $Class .= "\t	(\n";
        $i = 0;
        foreach ( $CleanFields as $Field )
        {
            /*if($Field == "i_Id") continue;
            if($Field == "d_CreateDate") continue;*/
            
            if ( 0 != $i && $i != count($Fields) )
            {
                $Class .= ",\n";
            }
            $i++;
            
            $Prefix = $this->getPrefix($Field);
            //var_dump( $Field );
            if( $Prefix == "i" || $Prefix == "f" || $Prefix == "d")
            {
                $Class .= "\t\t'\".%" . $ClearName . "->get" . $this->clearDatabaseNames( $Field ) . "OrNull().\"'";
            } else 
            {
                $Class .= "\t\t'\".%" . $ClearName . "->get" . $this->clearDatabaseNames( $Field ) . "().\"'";
            }

        }
        $Class .= "\t\t)\";\n";
        $Class .= "\t	return %this->MySql->executeNoneQuery(%Sql);\n";
        $Class .= "\t}\n";

// update fk

        $Class .= "\tpublic function update" . $ClearName . "(Base" . $ClearName . " %" . $ClearName . ")\n";
        $Class .= "\t{\n";
        $Class .= "\t	%Sql=\"UPDATE `" . $SmallClassName . "` SET 	\n";
        $i = 0;
        foreach ( $CleanFields as $Field )
        {
            if($Field == "i_Id") continue;
            if($Field == "d_CreateDate") continue;
            if ( 0 != $i && $i != count($Fields) )
            {
                $Class .= ",\n";
            }
            $i++;
            $Prefix = $this->getPrefix($Field);
            //var_dump( $Field );
            if( $Prefix == "i" || $Prefix == "f" || $Prefix == "d")
            {
                $Class .= "\t\t" . $Field . "='\".%" . $ClearName . "->get" . $this->clearDatabaseNames($Field) . "OrNull().\"'";
            }else 
            {
                $Class .= "\t\t" . $Field . "='\".%" . $ClearName . "->get" . $this->clearDatabaseNames($Field) . "().\"'";
            }
            
        }
        $Class .= "\t WHERE `i_Id` =\".%" . $ClearName . "->getId();\n";
        $Class .= "\t\treturn %this->MySql->executeNoneQuery(%Sql);\n";
        $Class .= "\t}\n";
// delete fkt	
        $Class .= "\tpublic function delete" . $ClearName . "(base" . $ClearName . " %" . $ClearName . ")\n";
        $Class .= "\t{\n";
        $Class .= "\t	%Sql=\"DELETE FROM `" . $SmallClassName . "` WHERE `i_Id` =\".%" . $ClearName . "->getId();\n";
        $Class .= "\t\treturn %this->MySql->executeNoneQuery(%Sql);\n";
        $Class .= "\t}\n";

            

        $Class .= "\tpublic function updateValue(%ValueName ,%Value, %ElementId )\n";
        $Class .= "\t{\n";
        $Class .= "\t	%Sql=\"UPDATE `" . $SmallClassName . "` SET `\".%ValueName.\"` = '\".%Value.\"' WHERE `i_Id` =\" . %ElementId;\n";
        $Class .= "\t\treturn %this->MySql->executeNoneQuery(%Sql);\n";
        $Class .= "\t}\n";
        $Class .= "}



?>";
// klasse zu ende
        $Class = str_replace("%", "$", $Class);

        $Path = pathinfo($this->Agruments[0]);
        if ( !is_dir($Path['dirname'] . "/../class/DatabaseObjects/base") )
        {
            mkdir($Path['dirname'] . "/../class/DatabaseObjects/base");
        }
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/base/cls_Base" . $ClearName . "Manager.php", $Class);
        printf("PHP Class created >> " . $Path['dirname'] . "/../class/DatabaseObjects/base/cls_" . $ClearName . "Manager.php\n");

        if ( file_exists($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Manager.php") )
            return;
// create the file for user edit
        $Class = "<?php\n";
        $Class .= "class " . $ClearName . "Manager extends Base" . $ClearName . "Manager\n{\n\n";
        $Class .= "}\n";
        $Class .= "?>";
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Manager.php", $Class);
        printf("PHP Class created >> cls_" . $ClearName . "Manager.php\n");
    }

    private function createManagerPostgres( $ClassName, $Fields )
    {
        $ClearName = ucfirst($this->clearDatabaseNames($ClassName));
        $Fields = $this->removeCreateDate($Fields); // wentfernt das createdate
        $CleanFields = $this->removeSystemFields($Fields);
        $SmallClassName = strtolower($ClassName);
        $Class = "<?php\n";
        $Class .= "class Base" . $ClearName . "Manager extends SystemManager\n{\n";

// Konstruktor anfang
        $Class .= "\n\tfunction __construct(";
        $Class .= ")\n\t{\n";
        $Class .= "\t\tparent::__construct();\n";
        $Class .= "\t}\n\n";
        
        $Class .= "\tprotected %Fields = array(" ;
         
        $i=1;
        foreach($Fields as $MyField )
        {
            $Class .= "'". $MyField ."'";
            if($i < count($Fields) )
            {
                $Class .= ",";
            }
            $i++;
        }        
        $Class .= ");\n\n";

        $Class .= "\tpublic function insert" . $ClearName . "(" . $ClearName . " %" . $ClearName . ")\n";
        $Class .= "\t{\n";
        $Class .= "\t	%Sql='INSERT INTO \"" . $ClassName . "\"\n ";

        $Class .= "\t\t(\"" . implode("\",\"", $CleanFields) . "\")\n";


        $Class .= "\t VALUES \n";
        $Class .= "\t	(\n";
        $i = 0;
        foreach ( $CleanFields as $Field )
        {
            if ( 0 != $i && $i != count($Fields) )
            {
                $Class .= ",\n";
            }
            $i++;
            if($Field == "i_Id")
            {
                $Class .= "\t\tDefault";
                continue;
            }
            if($Field == "d_CreateDate")
            {
                $Class .= "\t\tNow()";
                continue;
            }
            if($Field == "d_LastEdit")
            {
                $Class .= "\t\tNow()";
                continue;
            }
            $Class .= "\t\t\\''.%" . $ClearName . "->get" . $this->clearDatabaseNames( $Field ) . "().'\'";
        }
        $Class .= "\t\t)';\n";
        $Class .= "\t	return %this->MySql->executeNoneQuery(%Sql);\n";
        $Class .= "\t}\n";

// update fk

        $Class .= "\tpublic function update" . $ClearName . "(Base" . $ClearName . " %" . $ClearName . ")\n";
        $Class .= "\t{\n";
        $Class .= "\t	%Sql='UPDATE \"" . $ClassName . "\" SET \n";
        $i = 0;
        foreach ( $CleanFields as $Field )
        {
            if($Field == "i_Id") continue;
            if($Field == "d_CreateDate") continue;
            if ( 0 != $i && $i != count($Fields) )
            {
                $Class .= ",\n";
            }
            
            if( $this->isDBColInt($Field))
            {
                $Class .= "\t\t\"" . $Field . "\"='.%" . $ClearName . "->get" . $this->clearDatabaseNames($Field) . "().'";
            }else
            {
                $Class .= "\t\t\"" . $Field . "\"=\''.%" . $ClearName . "->get" . $this->clearDatabaseNames($Field) . "().'\'";
                    //$Class .= "\"" . $Field . "\" like \"^'. %StringValue .'\"\n";
            }
            
            $i++;
            
        }
        $Class .= "\t WHERE \"i_Id\" ='.%" . $ClearName . "->getId();\n";
        $Class .= "\t\treturn %this->MySql->executeNoneQuery(%Sql);\n";
        $Class .= "\t}\n";
// delete fkt	
        $Class .= "\tpublic function delete" . $ClearName . "(base" . $ClearName . " %" . $ClearName . ")\n";
        $Class .= "\t{\n";
        $Class .= "\t	%Sql='DELETE FROM \"" . $ClassName . "\" WHERE \"i_Id\" ='.%" . $ClearName . "->getId();\n";
        $Class .= "\t\treturn %this->MySql->executeNoneQuery(%Sql);\n";
        $Class .= "\t}\n";
        $Class .= "}
?>";
// klasse zu ende
        $Class = str_replace("%", "$", $Class);

        $Path = pathinfo($this->Agruments[0]);
        if ( !is_dir($Path['dirname'] . "/../class/DatabaseObjects/base") )
        {
            mkdir($Path['dirname'] . "/../class/DatabaseObjects/base");
        }
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/base/cls_Base" . $ClearName . "Manager.php", $Class);
        printf("PHP Class created >> " . $Path['dirname'] . "/../class/DatabaseObjects/base/cls_" . $ClearName . "Manager.php\n");

        if ( file_exists($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Manager.php") )
            return;
// create the file for user edit
        $Class = "<?php\n";
        $Class .= "class " . $ClearName . "Manager extends Base" . $ClearName . "Manager\n{\n\n";
        $Class .= "}\n";
        $Class .= "?>";
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Manager.php", $Class);
        printf("PHP Class created >> cls_" . $ClearName . "Manager.php\n");
    }
    
    private function isDBColInt($Col)
    {
        if(  strpos($Col, "i_") === 0) return true;
        if(  strpos($Col, "f_") === 0) return true;
        if(  strpos($Col, "f_") === 0) return true;
    }
    
    
    private function createFinderPostgres( $ClassName, $Fields )
    {
        $ClearName = ucfirst( $this->clearDatabaseNames( $ClassName ) );
        $ClassNameOld = $ClassName;
        $SmallClassName = strtolower($ClassName);
        $Class = "<?php\n";
        $Class .= "class Base" . $ClearName . "Finder extends SystemFinder\n{\n";
// Konstruktor anfang
        $Class .= "\tfunction __construct(";
        $Class .= ")\n\t{\n";
        $Class .= "\t\tparent::__construct();\n";
        $Class .= "\t}\n\n";
        
        $Class .= "\tprotected %Fields = array(" ;
         
        $i=1;
        foreach($Fields as $MyField )
        {
            $Class .= "'". $MyField ."'";
            if($i < count($Fields) )
            {
                $Class .= ",";
            }
            $i++;
        }        
        $Class .= ");\n\n";
        
        
// konstruktor ende	
// doload

        $Class .= "\tprotected function doLoad(%RecordSet)
	{
		%" . $ClearName . "Collection = new " . $ClearName . "Collection();
		foreach (%RecordSet as %Row)
		{
			%" . $ClearName . "Collection->add(%this->load(%Row));
		}
		return %" . $ClearName . "Collection;
	}\n\n";

        $TempArray = array(); // das array aufbereiten
        foreach ( $Fields as
                $Field )
        {
            $TempArray[] = "%Row['" . $Field . "']";
        }
        $Class .= "\tprotected function load(%Row)
	{
		return new " . $ClearName . "(" . implode(",", $TempArray) . ");
	}\n\n";


        $Class .= "\tpublic function findAll()
        {
            %Sql ='select  \"" . implode("\",\"", $Fields) . "\"
                    from \"$ClassName\"';
            return %this->doLoad(%this->MySql->executeQuery(%Sql));
        }\n\n";


        $i = 0;
        foreach ( $Fields as  $Field )
        {
            $FieldClear = ucfirst($this->clearDatabaseNames($Field));
            $Class .= "\tpublic function findBy" . $FieldClear . "(%" . $FieldClear . ")
	{
		%Sql='select \"" . implode("\",\"", $Fields) . "\"
		from \"$ClassName\"";
                if( $this->isDBColInt($Field))
                {
                    $Class .= "where \"" . $Field . "\" = '.%" . $FieldClear . ";\n";
                }else
                {
                    $Class .= "where \"" . $Field . "\" = \''.%" . $FieldClear . ".'\'';\n";
                }
            if ( $Field == "i_Id" )
            {
                $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql))->getByIndex(0);\n";
            } else
            {
                $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql));\n";
            }
            $i++;
            $Class .= "\t}\n\n";
        }
        
        

            $FieldClear = ucfirst($this->clearDatabaseNames($Field));
            $Class .= "\tpublic function findByValue(%StringValue ,  %Limit = 30)
	{
		%Sql='select \"" . implode("\",\"", $Fields) . "\"
		from \"$ClassName\"" ;
                    
            $Class .= " where ";
            $FieldCount = count($Fields);
            $I = 0;
            foreach ( $Fields as  $Field )
            {
                if($Field == "i_Id" || $Field == "d_CreateDate" || $Field == "d_LastEdit")
                {
                     $I++;
                     continue;
                }
                if( $this->isDBColInt($Field))
                {
                    $Class .= "\"" . $Field . "\" = '.intval( %StringValue ).'\n";
                }else
                {
                    $Class .= "\"" . $Field . "\" like \'^'. %StringValue .'^\'\n";
                }
                if($FieldCount-1> $I )
                {
                    $Class .= " or ";
                    //exit("jo");
                }
                $I++;
                //echo $FieldCount . " " . $I . "\n";
            }
            $Class .= ' limit  \'. %Limit ;';
            $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql));\n";
            $Class .= "\t}\n\n";

            
            
        $FieldClear = ucfirst($this->clearDatabaseNames($Field));
        $Class .= "\tpublic function findByIdArray(%IdArray )
	{
		%Sql='select \"" . implode("\",\"", $Fields) . "\"
		from \"$ClassName\"" ;
                    
            $Class .= " where \"i_Id\" in ('.implode(\",\", %IdArray).')'; \n";
            
            //$Class .= '\';';
            $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql));\n";
            $Class .= "\t}\n\n";    
            
            
            
            
        $Class .= "}
		?>";
        // klasse zu ende
        $Class = str_replace("%", "$", $Class);
        $Class = str_replace("^", "%", $Class);
        $Path = pathinfo($this->Agruments[0]);
        if ( !is_dir($Path['dirname'] . "/../class/DatabaseObjects/base") )
        {
            mkdir($Path['dirname'] . "/../class/DatabaseObjects/base");
        }
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/base/cls_Base" . $ClearName . "Finder.php", $Class);
        printf("PHP Class created >> " . $Path['dirname'] . "/../class/DatabaseObjects/cls_Base" . $ClearName . "Finder.php\n");


        if ( file_exists($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Finder.php") )
            return;
// create the file for user edit
        $Class = "<?php\n";
        $Class .= "class " . $ClearName . "Finder extends Base" . $ClearName . "Finder\n{\n\n";
        $Class .= "}\n";
        $Class .= "?>";
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Finder.php", $Class);
        printf("PHP Class created >> cls_" . $ClearName . "Finder.php\n");
    }
    
    
    
    
    private function createFinder( $ClassName, $Fields )
    {
        $ClearName = ucfirst( $this->clearDatabaseNames( $ClassName ) );
        $ClassNameOld = $ClassName;
        $SmallClassName = strtolower($ClassName);
        $Class = "<?php\n";
        $Class .= "class Base" . $ClearName . "Finder extends SystemFinder\n{\n";
        // Konstruktor anfang
        $Class .= "\tfunction __construct(";
        $Class .= ")\n\t{\n";
        $Class .= "\t\tparent::__construct();\n";
        $Class .= "\t}\n\n";
        
        $Class .= "\tprotected %Fields = array(" ;
         
        $i=1;
        foreach($Fields as $MyField )
        {
            $Class .= "'". $MyField ."'";
            if($i < count($Fields) )
            {
                $Class .= ",";
            }
            $i++;
        }        
        $Class .= ");\n\n";
        
        
// konstruktor ende	
// doload

        $Class .= "\tprotected function doLoad(%RecordSet)
	{
		%" . $ClearName . "Collection = new " . $ClearName . "Collection();
		foreach (%RecordSet as %Row)
		{
			%" . $ClearName . "Collection->add(%this->load(%Row));
		}
		return %" . $ClearName . "Collection;
	}\n\n";


        
        
        
        $TempArray = array(); // das array aufbereiten
        foreach ( $Fields as
                $Field )
        {
            $TempArray[] = "%Row['" . $Field . "']";
        }
        $Class .= "\tprotected function load(%Row)
	{
		return new " . $ClearName . "(" . implode(",", $TempArray) . ");
	}\n\n";


        $Class .= "\tpublic function findAll()
        {
            %Sql =\"select  " . implode(",", $Fields) . "
                    from $SmallClassName\";
            return %this->doLoad(%this->MySql->executeQuery(%Sql));
        }\n\n";


        $i = 0;
        foreach ( $Fields as  $Field )
        {
            $FieldClear = ucfirst($this->clearDatabaseNames($Field));
            $Class .= "\tpublic function findBy" . $FieldClear . "(%" . $FieldClear . ")
	{
		%Sql=\"select " . implode(",", $Fields) . "
		from " . $SmallClassName . "
		where " . $Field . " = '\".%" . $FieldClear . ".\"'\";\n";
            if ( $i == 0 )
            {
                $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql))->getByIndex(0);\n";
            } else
            {
                $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql));\n";
            }
            $i++;
            $Class .= "\t}\n\n";
        }
        
        

        $FieldClear = ucfirst($this->clearDatabaseNames($Field));
        $Class .= "\tpublic function findByValue(%StringValue ,  %Limit = 30)
	{
		%Sql=\"select " . implode(",", $Fields) . "
		from " . $SmallClassName ;
                    
            $Class .= " where ";
            $FieldCount = count($Fields);
            $I = 0;
            foreach ( $Fields as  $Field )
            {
                $Class .= $Field .  " like '^\".%StringValue.\"^' ";
                if($FieldCount-1> $I )
                {
                    $Class .= " or ";
                }
                $I++;
            }
            $Class .= '";';
            $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql));\n";
            $Class .= "\t}\n\n";

        $FieldClear = ucfirst($this->clearDatabaseNames($Field));
        $Class .= "\tpublic function findByValueAndUserId(%StringValue , %UserId, %Limit = 30)
	{
		%Sql=\"select " . implode(",", $Fields) . "
		from " . $SmallClassName ;
                    
            $Class .= " where (";
            $FieldCount = count($Fields);
            $I = 0;
            foreach ( $Fields as  $Field )
            {
                $Class .= $Field .  " like '^\".%StringValue.\"^' ";
                if($FieldCount-1> $I )
                {
                    $Class .= " or ";
                }
                $I++;
            }
            $Class .= ' ) and i_UserId = \'%UserId\'";';
            $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql));\n";
            $Class .= "\t}\n\n";     
            
        $FieldClear = ucfirst($this->clearDatabaseNames($Field));
        $Class .= "\tpublic function findByIdArray(%IdArray )
	{
		%Sql=\"select " . implode(",", $Fields) . "
		from " . $SmallClassName ;
                    
            $Class .= " where i_Id in (\".implode(\",\", %IdArray).\")";
            
            $Class .= '";';
            $Class .= "\t\treturn %this->doLoad(%this->MySql->executeQuery(%Sql));\n";
            $Class .= "\t}\n\n";    
            
        
            
        $Class .= "\tpublic function getCount()
	{
		%Sql=\"select count(i_Id) as 'MyCount'
		from " . $SmallClassName ;            
            $Class .= '";';
            $Class .= "\t\t%Temp = %this->MySql->executeQuery(%Sql)\t;
		\nreturn %Temp[0]['MyCount'];\n";
            $Class .= "\t}\n\n"; 
             
        $Class .= "}
		?>";
        // klasse zu ende
        $Class = str_replace("%", "$", $Class);
        $Class = str_replace("^", "%", $Class);
        $Path = pathinfo($this->Agruments[0]);
        if ( !is_dir($Path['dirname'] . "/../class/DatabaseObjects/base") )
        {
            mkdir($Path['dirname'] . "/../class/DatabaseObjects/base");
        }
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/base/cls_Base" . $ClearName . "Finder.php", $Class);
        printf("PHP Class created >> " . $Path['dirname'] . "/../class/DatabaseObjects/cls_Base" . $ClearName . "Finder.php\n");


        if ( file_exists($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Finder.php") )
            return;
// create the file for user edit
        $Class = "<?php\n";
        $Class .= "class " . $ClearName . "Finder extends Base" . $ClearName . "Finder\n{\n\n";
        $Class .= "}\n";
        $Class .= "?>";
        file_put_contents($Path['dirname'] . "/../class/DatabaseObjects/cls_" . $ClearName . "Finder.php", $Class);
        printf("PHP Class created >> cls_" . $ClearName . "Finder.php\n");
    }

    public function createClass()
    {
        printf("Erstellen einer neuen Klasse\n");
        printf("geben Sie den Namen der Klasse an:\n");
        $ClassName = $this->getInput();
        $MemberVariablen = array();

        $NewVar = true;
        do
        {
            printf("Member Variablen name:\n");
            $MemberVariablen[] = $this->getInput(); // member hinzufügen

            printf("weiteren meber hinzufügen: Y/N\n");
            $NewVar = $this->getInput();
            if ( $NewVar == "Y" )
            {
                $NewVar = true;
            } else
            {
                $NewVar = false;
            }
        } while ( $NewVar );

        $this->createPHPClass($ClassName, $MemberVariablen);
        $this->createPHPCollectionClass($ClassName, $MemberVariablen);
        $this->createJSClass($ClassName, $MemberVariablen);
    }

    private function createJSClass( $ClassName, $MemberVariablen )
    {
        $ClassName = ucfirst($this->clearDatabaseNames($ClassName));
        $Class = $ClassName . "= function(Init)\n";
        $Class .= "{\n";

        foreach ( $MemberVariablen as
                $Parameter )
        {
            $Parameter = $this->clearDatabaseNames($Parameter);
            $Class .= "\tthis." . $Parameter . "=(Init." . $Parameter . ") ? Init." . $Parameter . " : '';\n";
        }
        $Class .= "\t";

        foreach ( $MemberVariablen as
                $Parameter )
        {
            $Parameter = $this->clearDatabaseNames($Parameter);
            $Class .= "\tthis.get" . $Parameter . " = function()\n";
            $Class .= "\t{\n";
            $Class .= "\t\treturn this." . $Parameter . ";\n";
            $Class .= "\t}\n\t";
            $Class .= "\tthis.set" . $Parameter . " = function(" . $Parameter . ")\n";
            $Class .= "\t{\n";
            $Class .= "\t\tthis." . $Parameter . "=" . $Parameter . ";\n";
            $Class .= "\t}\n\n";
        }
// getter und setter definieren
        $Class .= "}";
        $Path = pathinfo($this->Agruments[0]);
        @mkdir($Path['dirname'] . "/../js/objects/", "0777"); // fals der ordner nicht exsistiert dann hier neu stellen
        file_put_contents($Path['dirname'] . "/../js/objects/cls_" . $ClassName . ".js", $Class);
        printf("JS  Class created >> cls_" . $ClassName . ".js\n");
    }

    private function createPHPCollectionClass( $ClassName, $MemberVariablen )
    {
        $ClassName = ucfirst($this->clearDatabaseNames($ClassName));
        $Class = "<?php\n";
        $Class .= "class Base" . $ClassName . "Collection extends Collection  \n{\n";
        $Class .= "\tpublic function add( %Element )
		{
			if(isset(%Element))
			{
				%this->Elements[]=%Element;
			}
		}\n";


        $Class .= "\tpublic function getById(%Id)
	{
		foreach (%this->Elements as %Element)
		{
			if(%Element->getId()==%Id)
			{
				return %Element;
			}
		}
		return " . $ClassName . "::getEmptyInstance();
	}\n";


        $Class .= "\tpublic function getByIndex(%Index)
	{
		if (!isset(%this->Elements[%Index]) || %this->countElements() <  0)
		{
			return " . $ClassName . "::getEmptyInstance();
		}
		return %this->Elements[%Index];	
	}\n";

        $Class .= "}
		?>";
// klasse zu ende
        $Class = str_replace("%", "$", $Class);
        $Path = pathinfo($this->Agruments[0]);
        if ( !is_dir($Path['dirname'] . "/../class/objects/base") )
        {
            mkdir($Path['dirname'] . "/../class/objects/base");
        }
        file_put_contents($Path['dirname'] . "/../class/objects/base/cls_Base" . $ClassName . "Collection.php", $Class);
        printf("PHP Class created >> cls_Base" . $ClassName . "Collection.php\n");


        if ( file_exists( $Path['dirname'] . "/../class/objects/cls_" . $ClassName . "Collection.php") )
            return;
// create the file for user edit
        $Class = "<?php\n";
        $Class .= "class " . $ClassName . "Collection extends Base" . $ClassName . "Collection\n{\n\n";
        $Class .= "}\n";
        $Class .= "?>";
        file_put_contents($Path['dirname'] . "/../class/objects/cls_" . $ClassName . "Collection.php", $Class);
        printf("PHP Class created >> cls_" . $ClassName . "Collection.php\n");
    }

    /**
     * erzeugt eine php classe aus den übergeben daten
     */
    private function createPHPClass( $ClassName, $MemberVariablen )
    {
        $ClassName = ucfirst($this->clearDatabaseNames($ClassName));
        $Class = "<?php\n";
        $Class .= "class Base" . $ClassName . " extends i_CollectionElement \n{\n";
        foreach ( $MemberVariablen as
                $Parameter )
        {
            $Parameter = ucfirst($this->clearDatabaseNames($Parameter));
            $Class .= "\tprotected $" . $Parameter . ";\n";
        }
// Konstruktor anfang
        $Class .= "\n\tfunction __construct(";
        $i = 0;
        foreach ( $MemberVariablen as
                $Parameter )
        {
            $Parameter = ucfirst($this->clearDatabaseNames($Parameter));
            $Class .= "$" . $Parameter;
            $i++;
            if ( $i < count($MemberVariablen) )
            {
                $Class .= ",";
            }
        }
        $Class .= ")\n\t{\n";

        $Class .= "\n";
        $Class .= "\t\tif (is_array(%Id))
        \t{
        \t\t%this->setValuesFromArray(%Id);
        \t\treturn;
        \t}
        ";
        $Class .= "\n\n";

        foreach ( $MemberVariablen as $Parameter )
        {
            $Parameter = ucfirst($this->clearDatabaseNames($Parameter));
            $Class .= "\t\t%this->" . $Parameter . "=$" . $Parameter . ";\n";
        }

        $Class .= "\t}\n\n";
// konstruktor ende
// getter und setter definieren


        foreach ( $MemberVariablen as $Parameter )
        {
            $Parameter = ucfirst($this->clearDatabaseNames($Parameter));
            $Class .= "\tpublic function get" . $Parameter . "()\n";
            $Class .= "\t{\n";
            $Class .= "\t\treturn %this->" . $Parameter . ";\n";
            $Class .= "\t}\n";
            $Class .= "\tpublic function set" . $Parameter . "($" . $Parameter . ")\n";
            $Class .= "\t{\n";
            $Class .= "\t\t%this->" . $Parameter . "=$" . $Parameter . ";\n";
            $Class .= "\t}\n\n";
        }
        
        
        foreach ( $MemberVariablen as $Parameter )
        {
            $Prefix = $this->getPrefix($Parameter);
            
            //var_dump( $Prefix );
            //var_dump( $Parameter );
            
            //if( $Prefix != "i" && $Prefix != "f" || $Prefix != "d") continue;

            switch($Prefix)
            {
                case "i":
                case "f":  
                $Parameter = ucfirst($this->clearDatabaseNames($Parameter));
                $Class .= "\tpublic function get" . $Parameter . "OrNull()\n";
                $Class .= "\t{\n";
                $Class .= "\t\t if(%this->" . $Parameter . ") return %this->" . $Parameter . ";\n\t\t return 0;\n";
                $Class .= "\t}\n";
                
                break;
                case "d": 
                $Parameter = ucfirst($this->clearDatabaseNames($Parameter));
                $Class .= "\tpublic function get" . $Parameter . "OrNull()\n";
                $Class .= "\t{\n";
                $Class .= "\t\t if(%this->" . $Parameter . ") return %this->" . $Parameter . ";\n\t\t return '0000-00-00';\n";
                $Class .= "\t}\n";
                break;
            }
            
        }
        
        
// getter und setter definieren

        $Class .= "\tpublic static function getEmptyInstance()\n";
        $Class .= "\t{\n";
        $Class .= "\t return new " . $ClassName;

        $Class .= "(";
        $i = 0;
        foreach ( $MemberVariablen as
                $Parameter )
        {
            $Parameter = ucfirst($this->clearDatabaseNames($Parameter));
            $Class .= "$" . $Parameter;
            $i++;
            if ( $i < count($MemberVariablen) )
            {
                $Class .= ",";
            }
        }
        $Class .= ");";
        $Class .= "\n";
        $Class .= "\t}\n";

        $Class .= "}
		?>";
// klasse zu ende
        $Class = str_replace("%", "$", $Class);
        $Path = pathinfo($this->Agruments[0]);
        if ( !is_dir($Path['dirname'] . "/../class/objects/base") )
        {
            mkdir($Path['dirname'] . "/../class/objects/base");
        }
        file_put_contents($Path['dirname'] . "/../class/objects/base/cls_Base" . $ClassName . ".php", $Class);
        printf("PHP Class created >> cls_Base" . $ClassName . ".php\n");


        if ( file_exists($Path['dirname'] . "/../class/objects/cls_" . $ClassName . ".php") )
            return;
// create the file for user edit
        $Class = "<?php\n";
        $Class .= "class " . $ClassName . " extends Base" . $ClassName . "\n{\n\n";
        $Class .= "}\n";
        $Class .= "?>";
        file_put_contents( $Path['dirname'] . "/../class/objects/cls_" . $ClassName . ".php", $Class );
        printf("PHP Class created >> cls_" . $ClassName . ".php\n");
    }

    
    private function generateDeviceTemplates()
    {
        $Fields = array();
        
        
        printf("File pfad eingeben:\n");
        $DeviceName = $this->getInput();
        printf( $ClassName );
        
        $New = true;
       
        while($New)
        {
            $Element = array();
           
            printf("geben Sie den Namen für das Element ein:\n");
            $Element['Name'] = $this->getInput();
            printf("geben Sie die Art drs Element ein:\n");
            printf("Text:\n");
            printf("Number:\n");
            printf("Ip:\n");
            printf("Port:\n");
            printf("Slider:\n");
            $Element['Type'] = $this->getInput();
            
            switch( $Element['Type'] )
            {
                case "Number":
                case "Slider":
                    printf("geben Sie den Maximalwert für das Element ein:\n");
                    $Element['Max'] = $this->getInput();
                    printf("geben Sie den Minimalwert für das Element ein:\n");
                    $Element['Min'] = $this->getInput();
                    break;
            }
            
            $Fields[] = $Element;
            printf("Ein weiteres Element abferagen? Ja | Nein:\n");
            If($this->getInput() == "Nein")
            {
                $New = false;
            }
            
        }
        
        // hier das form generieren
        
        var_dump( $DeviceName );
        var_dump( $Fields );
        
        
    }
    
    
    private function generateDeviceTemplateFromArray( $Fields, $DeviceName )
    {
        // kopf rendern
        
       $Html =' <html><head><meta http-equiv="content-type" content="text/html; charset=utf-8">
	 <style>
.MainHeader 
{
    text-transform: uppercase;
    border-bottom: 2px solid #006ec8;
    font-family: Open Sans Bold Italic;
    letter-spacing: 1px;
    padding-left: 15px;
    /*width: 665px;*/
}       
.table {
    width: 100%;
    max-width: 100%;
    margin-bottom: 1rem;
    background-color: transparent;
}   
table {
    border-collapse: collapse;
}   
.table td, .table th {
    padding: .75rem;
    vertical-align: top;
    border-top: 1px solid #dee2e6;
}
.table thead th {
    vertical-align: bottom;
    border-bottom: 2px solid #dee2e6;
}
.table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(0,0,0,.05);
}
.table-hover tbody tr:hover {
    background-color: rgba(0,0,0,.075);
}.form-control {
    display: block;
    width: 100%;
    padding: .375rem .75rem;
    font-size: 1rem;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: .25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
  .btn {
    width: 100%;
    display: inline-block;
    margin-bottom: 0;
    font-size: 14px !important;
    font-weight: 400;
    line-height: 40px;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border-radius: 3px;
    text-transform: uppercase;
    letter-spacing: 1px;
    border: 0 none;
}     

.btn-success {
    color: #fff;
    background-color: #28a745;
    border-color: #28a745;
}

 
    </style>
	
	
</head>
<body>
	<h1 class="MainHeader"> $DeviceName </h2>
	<h2>Config-Mode</h3>
        <form id="GeneratatedForm" 
                  class="form-horizontal" 
                  data-tablename="Task"
                  enctype="multipart/form-data">
                ';
        
        
       foreach($Fields as $Row)
       {
            switch ( $Row["Type"] )
            {
                case "Text":
                    $Html .= '   
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="' . $Row["Name"] . '">' . $Row["Name"] . '</label>
                  <div class="col-md-6">
                  <input id="tb_' . $Row["Name"] . '"
                         name="tb_' . $Row["Name"] . '" 
                         data-type="s"
                         type="text" 
                         placeholder="' . $Row["Name"] . '" 
                         class="form-control input-md ' . $Row["Name"] . ' "
                         ></div>
                </div>';
                break;
            
                case "Number":
                    $Html .= '   
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for="' . $Row["Name"] . '">' . $Row["Name"] . '</label>
                  <div class="col-md-6">
                  <input id="tb_' . $Row["Name"] . '"
                         name="tb_' . $Row["Name"] . '" 
                         data-type="s"
                         type="number" 
                         min="' . $Row["Min"] . '"
                         max="' . $Row["Max"] . '"
                         placeholder="' . $Row["Name"] . '" 
                         class="form-control input-md ' . $Row["Name"] . ' "
                         ></div>
                </div>';
                break;
            
            
           }
       }
       
        // die einzelnen  Elmenete rendern
        //$Html .= $this->generateElementsForm( $Fields );
        
        $Html .= "</form></div></body></html>";
        
        
        
        // den Footer dran machen
        
        if ( !is_dir("generated") )
        {
// from erstellen
            echo "\n ordner wird \n";
            mkdir("generated", 0700);
        }

        if ( file_exists($Path['dirname'] . "/../utils/generated/tpl_" . $ClassName . ".php") )
        {
            echo "Form schon vorhanden!\n";
            file_put_contents($Path['dirname'] . "/../utils/generated/tpl_" . $ClassName . " " . date("y-m-d H-i") . ".php", $Html );
            echo "Form erstellt: tpl_" . $ClassName . " " . date("y-m-d H-i") . ".php\n";
        } else
        {
            file_put_contents($Path['dirname'] . "/../utils/generated/tpl_" . $ClassName . ".php", $Html );
            echo "Form erstellt: tpl_" . $ClassName . ".php\n";
        }
        
    }
    
    
    
    /**
     * Erstellt Templates für Form und Data-Show einer Tabelle
     * @param type $TableName
     */
    private function generateTemplates( $TableName )
    {
        if ( !$this->DatabaseConection )
        {
            $this->checkDataBaseConnection(); // open database Connection
        }

        echo "\n";
        if ( strlen($TableName) == 0 )
        {
            printf("Tabellenname angeben:\n");
            $TableName = $this->getInput();
        }

        switch(PDO_DRIVER)
        {
            case  PDO_PSQL:
                $Sql = "SELECT 
                \"column_name\" AS \"Field\"
                ,\"data_type\" AS \"Type\"
                ,'' AS \"Comment\"
                FROM information_schema.columns
                WHERE table_schema = '" . DB_SCHEME . "'
                  AND table_name   = '" . $TableName . "'" ;
                $Result = $this->DatabaseConection->executeQuery($Sql);
                
                break;
            default:
                $Sql = "SHOW FULL COLUMNS FROM " . $TableName;
                $Result = $this->DatabaseConection->executeQuery($Sql);
        }
        
        

        
        
        
        
        
        $ColumnsArray = $this->generateColumnsArray($Result);
        
        
        //$ColumnsArray = $this->getColumsFromTable($TableName);

        $this->writeForm($TableName, $ColumnsArray);
        $this->writeObjectShow($TableName, $ColumnsArray);

        $this->generateTemplates(NULL);
    }

    /**
     * * Erstellt Templates für Forms und Data-Shows einer Datenbank
     * @param type $DBName
     */
    private function generateTemplatesDB( $DBName )
    {
        if ( !$this->DatabaseConection )
        {
            $this->checkDataBaseConnection(); // open database Connection
        }

        $Sql = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = '" . DB_DATABASE . "'";

        $Result = $this->DatabaseConection->executeQuery($Sql);

        foreach ( $Result as $TableName )
        {
            $this->generateTemplates($TableName["TABLE_NAME"]);
        }
    }

    private function generateColumnsArray( $Columns )
    {
        $ColumnsArray = array();

        foreach ( $Columns as
                $Column )
        {
            $ThisColumn = array();



// Wenn kein ";"-Zeichen in $Column['Comment'] vorhanden: $Column['Comment'] ist deutscher Bezeichner
            if ( strpos($Column['Comment'], ";") === false )
            {
                $ThisColumn['Name'] = $Column['Field'];
                $ThisColumn['NameGer'] = $Column['Comment'];
            }
// Sonst: $Column['Comment'] anhand von ";"-Zeichen zerlegen
            else
            {
                $ThisColumn['Name'] = $Column['Field'];
//    $ThisColumn = $this->parseColumnComment($Column);
                $Temp = $this->parseColumnComment($Column);


                foreach ( $Temp as
                        $Key =>
                        $Value )
                {
                    $ThisColumn[$Key] = $Value;
                }
            }

            $ColumnsArray[] = $ThisColumn;
        }

        return $ColumnsArray;
    }

    private function parseColumnComment( $Column )
    {
        $CommentArray = explode(";", $Column['Comment']);

        foreach ( $CommentArray as
                $CommentPart )
        {
            $CommentPart = trim($CommentPart);

// Jeden $CommentPart anhand von "="-Zeichen in $CommentKey und $CommentValue teilen
            $PositionEqualSign = strpos($CommentPart, '=');
            $CommentKey = trim(substr($CommentPart, 0, $PositionEqualSign));
            $CommentValue = trim(substr($CommentPart, $PositionEqualSign + 1));

//  Wenn kein ","-Zeichen in $CommentValue vorhanden: $CommentValue ist ein String
            if ( strpos($CommentValue, ",") === false )
            {
                $CommentValue = trim(str_replace('"', '', $CommentValue));
            } else
            {
// Sosnt: $CommentValue ist ein Array    
                $CommentValue = array_map("trim", str_replace('"', '', explode(",", $CommentValue)));
            }

            $ColumnArrayPart[$CommentKey] = $CommentValue;
        }

        return $ColumnArrayPart;
    }

    private function writeForm( $TableName, $Fields )
    {

        $Complete = $this->generateTemplateForm($TableName, $Fields);

        $Path = pathinfo($this->Agruments[0]);

        $ClassName = ucfirst($this->clearDatabaseNames($TableName));

        if ( !is_dir("generated") )
        {
// from erstellen
            echo "\n ordner wird \n";
            mkdir("generated", 0700);
        }

        if ( file_exists($Path['dirname'] . "/../utils/generated/tpl_" . $ClassName . ".php") )
        {
            echo "Form schon vorhanden!\n";
            file_put_contents($Path['dirname'] . "/../utils/generated/tpl_" . $ClassName . " " . date("y-m-d H-i") . ".php", $Complete);
            echo "Form erstellt: tpl_" . $ClassName . " " . date("y-m-d H-i") . ".php\n";
        } else
        {
            file_put_contents($Path['dirname'] . "/../utils/generated/tpl_" . $ClassName . ".php", $Complete);
            echo "Form erstellt: tpl_" . $ClassName . ".php\n";
        }
    }

    private function writeObjectShow( $TableName, $Fields )
    {
        $Complete = $this->generateTemplateObjectShow($TableName, $Fields);

        $Path = pathinfo($this->Agruments[0]);

        $ClassName = ucfirst($this->clearDatabaseNames($TableName));

        if ( !is_dir("generated") )
        {
// from erstellenanzeigen
            echo "\n ordner wird \n";
            mkdir("generated", 0700);
        }


        if ( file_exists($Path['dirname'] . "/../utils/generated/tpl_Show" . $ClassName . ".php") )
        {
            echo "Object-Show schon vorhanden!\n";
            file_put_contents($Path['dirname'] . "/../utils/generated/tpl_Show" . $ClassName . " " . date("y-m-d H-i") . ".php", $Complete);
            echo "Object-Show erstellt: tpl_Show" . $ClassName . " " . date("y-m-d H-i") . ".php\n";
        } else
        {
            file_put_contents($Path['dirname'] . "/../utils/generated/tpl_Show" . $ClassName . ".php", $Complete);
            echo "Object-Show erstellt: tpl_Show" . $ClassName . ".php\n";
        }
    }

    /**
     * generiert das Formular mit header und footer
     * @param type $TableName
     * @param type $Fields
     * @return type
     */
    private function generateTemplateForm( $TableName, $Fields )
    {
        $TemplateStart = $this->generateTemplateStartForm($TableName);
        $Elements = $this->generateElementsForm($Fields);
        $ControlButtons = $this->generateControlButtonsForm();
        $TemplateEnd = $this->generateTemplateEndForm();

        $Complete = $TemplateStart . $Elements . $ControlButtons . $TemplateEnd;

        return $Complete;
    }

    /**
     * generiert den Data-Show
     * @param type $TableName
     * @param type $Fields
     * @return type
     */
    private function generateTemplateObjectShow( $TableName, $Fields )
    {
        $TemplateStart = $this->generateTemplateStartObjectShow($TableName);
        $Elements = $this->generateElementsObjectShow($TableName, $Fields);
        $TemplateEnd = $this->generateTemplateEndObjectShow();

        $Complete = $TemplateStart . $Elements . $TemplateEnd;

        return $Complete;
    }

    private function generateTemplateStartForm( $TableName )
    {
        if ( $this->Agruments[3] == "-p" )
        {
            $HtmlFrame = '    
<!doctype html>
    <html>
        <head>
            <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
            <link rel="stylesheet" type="text/css" href="../../css/screen.css">
        </head>
        <body>';
        } else
        {
            $HtmlFrame = '';
        }


        $TemplateStart = $HtmlFrame . '

        <div id="main" class="container">
        
<!-- Start tpl -->

            <form id="GeneratatedForm" 
                  class="form-horizontal" 
                  data-tablename="' . ucfirst($this->clearDatabaseNames($TableName)) . '"
                  enctype="multipart/form-data">
                <fieldset>

                <!-- Form Name -->
                <legend><h1>' . ucfirst($this->clearDatabaseNames($TableName)) . '</h1></legend>

                    <input id = "hidden_TableName" name = "hidden_TableName" type = "hidden" value = "' . ucfirst($this->clearDatabaseNames($TableName)) . '" >
                    ';

        return $TemplateStart;
    }

    private function generateTemplateStartObjectShow( $TableName )
    {
        $TemplateStart = '     
    <fieldset>

        <!-- Form Name -->

        <legend><h1 class="text-center">' . $TableName . ' anzeigen</h1></legend>
        ';

        return $TemplateStart;
    }

    private function generateElementsForm( $Fields )
    {
        /*var_dump($Fields);
        exit();*/
        foreach ( $Fields as $Field )
        {
            $Prefix = $this->getPrefix($Field['Name']);

            $Field['Name'] = $this->clearDatabaseNames($Field['Name']);

            $HiddenFields = array("Id", "CreateDate", "LastUpdate", "LastLogin", "LastLogout");
            $SearchFor = array(":Name:", ":NameGer:", ":Placeholder:");
            if ( isset($Field['Placeholder']) )
            {
                $ReplaceWith = array($Field['Name'], $Field['NameGer'], $Field['Placeholder']);
            } else
            {
                $ReplaceWith = array($Field['Name'], $Field['NameGer'], $Field['NameGer']);
            }
            $FormSnippet = $this->generateSnippetForm($Prefix, $Field, $HiddenFields);

            $FormElement = str_replace($SearchFor, $ReplaceWith, $FormSnippet);
            $FormElements .= $FormElement;
        }
        return $FormElements;
    }

    private function generateElementsObjectShow( $TableName, $Fields )
    {
        foreach ( $Fields as
                $Field )
        {
            $Prefix = $this->getPrefix($Field['Name']);

            $Field['Name'] = $this->clearDatabaseNames($Field['Name']);

            $HiddenFields = array("Id", "CreateDate", "LastUpdate", "LastLogin", "LastLogout");

            $FormSnippet = $this->generateSnippetObjectShow($Prefix, $Field, $HiddenFields);

            $SearchFor = array(":Name:", ":NameGer:", ":Placeholder:");
            if ( isset($Field['Placeholder']) )
            {
                $ReplaceWith = array($Field['Name'], $Field['NameGer'], $Field['Placeholder']);
            } else
            {
                $ReplaceWith = array($Field['Name'], $Field['NameGer'], $Field['NameGer']);
            }


            $FormElement = str_replace($SearchFor, $ReplaceWith, $FormSnippet);
            $FormElements .= $FormElement;
        }
        return $FormElements;
    }

    /**
     * erzeugt die einzelenen formular elemente
     * @param type $Prefix
     * @param type $Field
     * @param type $HiddenFields
     * @return string
     */
    private function generateSnippetForm( $Prefix, $Field, $HiddenFields )
    {

        $FinalPrefix = $this->getFinalPrefix($Field, $Prefix);

        if ( in_array($Field['Name'], $HiddenFields) || isset($Field['Hidden']) )
        {
            $HiddenCSS = 'style="display:none;"';
        } else
        {
            $HiddenCSS = '';
        }


        if ( isset($Field['Required']) )
        {
            $Required = "required";
            $Star = "*";
        } else
        {
            $Required = "";
            $Star = "";
        }

        switch ( $FinalPrefix )
        {

            case "b":
                $FormSnippet = '
            <!-- Select Basic (Ja-Nein) -->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <select id="s_:Name:" 
                            name="s_:Name:" 
                            data-type="s" 
                            class="form-control :Name:">
                      <option value="1" selected="selected">Ja</option>
                      <option value="2">Nein</option>
                    </select>
                  </div>
                </div>
                    ';
                break;


            case "s":
                $FormSnippet = ' 
            <!-- Input-Field -->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                  <input id="tb_:Name:"
                         name="tb_:Name:" 
                         data-type="s"
                         type="text" 
                         placeholder=":Placeholder:" 
                         class="form-control input-md :Name: "
                         ' . $Required . '>
                  </div>
                </div>
            ';
                break;


            case "t":
                $FormSnippet = '
            <!-- Textarea -->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <textarea class="form-control :Name:" 
                              id="rtb_:Name:" 
                              name="rtb_:Name:" 
                              data-type="t"
                         ' . $Required . '></textarea>
                  </div>
                </div>
                    ';
                break;


            case "p":
                $FormSnippet = '
            <!-- Password input-->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <input id="tb_:Name:" 
                           name="tb_:Name:" 
                           data-type="s" 
                           type="password" 
                           placeholder=":Placeholder:" 
                           class="form-control 
                           input-md :Name:"
                         ' . $Required . '>
                  </div>
                </div>
                
            <!-- Password input-->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer: wiederholen' . $Star . '</label>
                  <div class="col-md-6">
                    <input id="tb_:Name:2" 
                           name="tb_:Name:2" 
                           data-type="s" 
                           type="password" 
                           placeholder=":Placeholder: wiederholen" 
                           class="form-control 
                           input-md :Name:"
                         ' . $Required . '>
                  </div>
                </div>
            ';
                break;


            case "m":
                $FormSnippet = '
            <!-- Password input-->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <input id="tb_:Name:" 
                           name="tb_:Name:" 
                           data-type="s" 
                           type="text" 
                           placeholder=":Placeholder:" 
                           class="form-control input-md :Name:"
                           type="email" 
                                                                                                
                         ' . $Required . '>
                  </div>
                </div>
            ';
                break;

            case "d":
                $FormSnippet = '
            <!-- Datepicker -->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <input type="date" 
                           class="form-control :Name:" 
                             
                           id="tb_:Name:" 
                           name="tb_:Name:" 
                           data-type="d"
                         ' . $Required . '>
                  </div>
                </div>
                    ';
                break;


            case "e":
                $i = 1;
                foreach ( $Field['Select'] as
                        $Value )
                {
                    $Options .= '<option value="' . $i . '">' . $Value . '</option>';
                    $i++;
                }

                $FormSnippet = '
            <!-- Select Basic -->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <select id="s_:Name:" 
                            name="s_:Name:" 
                            data-type="s" 
                            class="form-control :Name:">
                    '
                        . $Options .
                        '
                    </select>
                  </div>
                </div>
                    ';
                break;

            case "tbl":
                $FinderName = $this->getTableStringToFinder($Field['TableLink']);
                if ( isset($Field['Where']) )
                {
                    $ByName = $this->clearDatabaseNames($Field['Where']);
                }
                $DisplayName = $this->clearDatabaseNames($Field['TableLinkFields']);

                $FormSnippet = '
            <!-- Select Basic -->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <select id="s_:Name:" 
                            name="s_:Name:" 
                            data-type="s" 
                            class=" form-control :Name:">
                    '
                        . "
                        <?php
                        
                        echo \$this->getOptionHTMLElements('$FinderName','$DisplayName','$ByName', \$this->User->getId());
                        
                        ?>" .
                        '
                    </select>
                  </div>
                </div>';
//              echo $FormSnippet;
                break;


            case "file":
                $FormSnippet = '
            <!-- Password input-->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                    <input id="tb_:Name:" 
                           name="tb_:Name:" 
                           data-type="s" 
                           type="file" 
                           placeholder=":Placeholder:" 
                           class="form-control 
                           input-md :Name:"
                         ' . $Required . '>
                  </div>
                </div>
            ';

                break;


            default:
                $FormSnippet = ' 
            <!-- Input-Field -->
                <div class="form-group row"  ' . $HiddenCSS . ' >
                  <label class="col-md-4 col-form-label control-label generated-label text-md-right text-xs-left" for=":Name:">:NameGer:' . $Star . '</label>
                  <div class="col-md-6">
                  <input id="tb_:Name:" 
                         name="tb_:Name:" 
                         data-type="s"
                         type="text" 
                         placeholder=":Placeholder:" 
                         class="form-control input-md :Name:"
                         ' . $Required . '>
                  </div>
                </div>
            ';
                break;
        }

        return $FormSnippet;

// UNUSED....
//        $CheckBox = '
//            <!-- Multiple Checkboxes (inline) -->
//                <div class="form-group row">
//                  <label class="col-md-4 control-label generated-label text-md-right text-xs-left" for="checkboxes">:NameGer:' . $Star . '</label>
//                  <div class="col-md-6">
//                    <label class="checkbox-inline" for="checkboxes-0">
//                      <input type="checkbox" name="cb_:Name:" id="cb_:Name:" value="1">
//                      1
//                    </label>
//                  </div>
//                </div>
//                    ';
// ....UNUSED
    }

    private function generateSnippetObjectShow( $Prefix, $Field )
    {

        $FinalPrefix = $this->getFinalPrefix($Field, $Prefix);


        switch ( $FinalPrefix )
        {
            case "b":
                $Snippet = '     
        <div class="row">
            <span class="col-md-6 col-md-2 text-right" for=":Name:">:NameGer:</span>
            <span class="col-6 text-left" for=":Name:"> <?php echo $this->intToString($this->Object->get:Name:()); ?> </span>
        </div>';
                break;


            case "d":
                $Snippet = '     
        <div class="row">
            <span class="col-md-6 col-md-2 text-right" for=":Name:">:NameGer:</span>
            <span class="col-6 text-left" for=":Name:"> <?php echo $this->formatDate($this->Object->get:Name:()); ?> </span>
        </div>';
                break;


            case "e":
                $Snippet = '
        <div class="row">
            <span class="col-md-6 col-md-2 text-right" for=":Name:">:NameGer:</span>
            <span class="col-6 text-left" for=":Name:"> <?php echo $this->getSelectValue($this->Object->get:Name:(), "' . implode(",", $Field['Select']) . '"); ?> </span>
        </div>';
                break;


            default:
                $Snippet = '
        <div class = "row">
            <span class = "col-md-6 col-md-2 text-right" for = ":Name:">:NameGer:</span>
            <span class = "col-6 text-left" for = ":Name:"> <?php if($this->Object->get:Name:()) echo $this->Object->get:Name:(); else echo "-"; ?> </span>
        </div>';
                break;
        }
        return $Snippet;
    }

    private function generateControlButtonsForm()
    {

        $Buttons = '
            <!-- Button (Double) -->
                    <div class="form-group row">
                        <br />
                        <div class="col-md-2"></div>
                        <div class="col-md-8 row">      
                            <div class="col-md-6">
                                <input type="submit" id="btn_Controls0" name="btn_Controls0" class="btn btn-success btn-block" value="Speichern" />
                                <br />
                            </div>
                            <div class="col-md-6">
                                <a href="index.php?Section=">
                                    <button id="btn_:Name:1" name="btn_:Name:1" class="btn btn-danger btn-block"> verwerfen </button>
                                </a>
                            </div>
                      </div>
                    </div>
                        ';


        $ControlButtons = str_replace(":Name:", "Controls", $Buttons);

        return $ControlButtons;
    }

    private function generateTemplateEndForm()
    {
        $TemplateEnd = '
                <script>

                    $(function ()
                    {
                        Engine.setFormEvents(<?php echo $this->JsonData; ?>);
                    });
                </script>
            <!-- end tpl -->
            </fieldset>
        </form>
    </div>';

        return $TemplateEnd;
    }

    private function generateTemplateEndObjectShow()
    {
        $TemplateEnd = '
        <script>
            $(function ()
            {
                Engine.setFormEvents(<?php echo $this->JsonData; ?>);
            });
        </script>
    <!-- end tpl -->
    </fieldset>';

        return $TemplateEnd;
    }

    private function getTableStringToFinder( $TabelString )
    {
        $TabelString = str_replace("tbl_", "", $TabelString);
        return ucfirst($TabelString);
    }

    /**
     * �ndert das Prefix f�r Spezialfelder wie Passwort, Mail, File, ...
     * @param type $Field
     * @param type $Prefix
     * @return string
     */
    private function getFinalPrefix( $Field, $Prefix )
    {
        if ( isset($Field['Select']) )
        {
            $Prefix = 'e';
        } else if ( isset($Field['TableLink']) )
        {
            $Prefix = 'tbl';
        } else if ( isset($Field['File']) )
        {
            $Prefix = 'file';
        } else if ( $Field['Name'] == "Pass" )
        {
            $Prefix = 'p';
        } else if ( $Field['Name'] == "Mail" )
        {
            $Prefix = 'm';
        }

        return $Prefix;
    }

    private function getPlaceholder( $Field )
    {
        if ( isset($Field['Placeholder']) )
        {
            $Placeholder = $Field['Placeholder'];
        } else
        {
            $Placeholder = $Field['NameGer'];
        }

        return $Placeholder;
    }

    private function getInput()
    {
        $Input = "";
        $stdin = fopen("php://stdin", "r");
        $Input = trim(fgets($stdin));
        fclose($stdin);
        return $Input;
    }

}

error_reporting(E_ALL & ~(E_STRICT | E_NOTICE));

$Generator = new OrmCreator();
$Generator->start($argv);
?>
