/**
 * Created by Matthias Herzog on 03.06.2015.
 */

engine = function () {
    this.Controller = {};
    this.ContentContainer = {}; // der Content Container
    this.IsInited = false;
    this.User = {};
    this.Notification = window.Notification || false;
    this.Storage = Storage;
    this.LastUrl = "";
    this.Values = [];
    this.Utils = function () {};
    this.OfficeController = new OfficeController();
    this.TimesController = new TimesController();
    this.ErpController = new ErpController();
    this.CashBookController = new CashBook();
    this.ManagementController = new ManagementController();
    this.AuthController = new AuthController();
    this.DataController = new DataController();

    this.setDebugMode = function (DebugMode) {
        this.DebugMode = DebugMode;
    };

    this.setUser = function (User) {
        this.User = User;
    };

    this.init = function () {
        if (this.IsInited)
            return;

        this.Controller = {};

        $.ajaxSetup({
            headers: {
                'Ajax-Request': 'true'
            }
        });
        this.ContentContainer = $('.ContentLayer');
        setEvents();
        this.IsInited = true;
    };



    this.speek= function( TextToSpeek )
    {
        this.SpeechSynthesisMessage = new SpeechSynthesisUtterance();
        this.SpeechSynthesisMessage.voice = window.speechSynthesis.getVoices()[0]; // hier die Sprache setzen
        this.SpeechSynthesisMessage.rate = 1;
        this.SpeechSynthesisMessage.pitch = 0;
        this.SpeechSynthesisMessage.text = TextToSpeek ;
        speechSynthesis.speak(this.SpeechSynthesisMessage);
    }


    /**
     *	load routing data
     */
    this.getPath = function (routeName) {
        if (typeof this.Routing[routeName] == 'undefined')
            return '#';

        var path = this.Routing[routeName];
        for (var i = 1, cn = arguments.length; i < cn; i++) {
            path += arguments[i] + '/';
        }
        return path;
    };
    /**
     * lädt alle js und css datein neu
     */
    this.reloadJs = function () {
        var Timestamp = new Date().getTime();
        $('script.cb').each(function (Index, Item) {
            var $Item = $(Item);
            var Scource = $Item.attr("src");

            if (~Scource.indexOf("?")) {
                Scource = Scource + "?";
            } else {
                Scource = Scource + "&";
            }
            $Item.attr("src", Scource + "time=" + Timestamp);
        });
    };


    function setEvents() 
    {
        $('.SystemDropDown ul a').on("click vclick", function () {
            $(".SystemDropDown").removeClass('open');
        });

        $(document).keyup(function (e) {
            if (e.keyCode == 27) {
                $('.bootbox').modal("hide");
            }
        });

        $(document).on("touchstart click", ".InfoIcon", function (e) {
            var $this = $(this);
            var Href = $this.attr("data-href");
            var Header = $this.attr("data-header") || "Hilfe";

            if (!Href)
                return;
            $.get(Href, function (Data) {
                bootbox.dialog({
                    title: Header,
                    message: Data,
                    buttons: {
                        success: {
                            label: "Schließen",
                            className: "btn-success",
                            callback: function () {
                                var name = $('#name').val();
                                var answer = $("input[name='awesomeness']:checked").val();
                            }
                        }
                    }
                });
            });

        });

    };

    /**
     * neue Funktion zum anzeigen von popups
     * @param {type} Parameter
     * @returns {undefined}
     */
    this.showPopup = function (Parameter) 
    {
        //Url, Header, CallBack, Size, ClassName
        Parameter = Parameter || {};
        var Header = Parameter.Header || "";
        var callBackAfterLoad = Parameter.CallBackAfterLoad || function () {};
        var callBackButtonClick = Parameter.CallBackButtonClick || function () {};
        var Size = Parameter.Size || CONSTANTS.POPUP.SIZE.LARGE;
        var ClassName = Parameter.ClassName || "";
        var Html = Parameter.Html || "";
        var Data = Parameter.Data || {};
        var CallbackParameter = Parameter.CallbackParameter || {};
        var Backdrop = Parameter.Backdrop || false;
        var CloseButton = Parameter.CloseButton || true;

        if (typeof Parameter.CloseButton !== 'undefined') {
            CloseButton = Parameter.CloseButton;
        }


        if (typeof Parameter.Backdrop !== 'undefined') {
            Backdrop = Parameter.Backdrop;
        }


        if (!Parameter.Url && Html == "") {
            console.warn("No URl and no HTML Given!");
            return;
        }

        if (Size == CONSTANTS.POPUP.SIZE.EXTRA_LARGE) {
            ClassName += " ExtraLageModal ";
            Size = CONSTANTS.POPUP.SIZE.LARGE;
        }

        if (!Parameter.Url && Html != "") {
            bootbox.dialog({
                title: Header,
                message: Html,
                onEscape: true,
                size: Size,
                className: ClassName,
                backdrop: Backdrop,
                buttons: {
                    success: {
                        label: "Schließen",
                        className: "btn-success btn-block",
                        callback: callBackButtonClick
                    }
                }
            });

            /* if(Backdrop === false)
             {
                 $('.bootbox.modal').off();
             }*/
            callBackAfterLoad(CallbackParameter);
            return;
        }

        $.ajax({
            url: Parameter.Url,
            data: Data,
            type: 'POST',
            success: function (Data) {
                bootbox.dialog({
                    title: Header,
                    message: Data,
                    onEscape: true,
                    size: Size,
                    className: ClassName,
                    data: Data,
                    backdrop: Backdrop,
                    closeButton: CloseButton,
                    buttons: {
                        success: {
                            label: "Schließen",
                            className: "btn-success btn-block",
                            callback: callBackButtonClick
                        }
                    }
                });
                /*if(Backdrop === false)
                {
                    $('.bootbox.modal').unbind("click");
                }*/
                callBackAfterLoad(CallbackParameter);
            }
        });

    };


    this.hidePopup = function () {
        $('.bootbox').modal("hide");
    };


    /**
     * nicht mehr nehmen! nimm die showPopup
     */
    this.showUrlInPopup = function ( Url, Header, CallBack, Size, ClassName ) 
    {
        console.warn("function is deprecated");
        Header = Header || "";
        CallBack = CallBack || function () {};
        Size = Size || "large";
        ClassName = ClassName || "";
        if (!Url) {
            console.log("No URl Given!");
            return;
        }
        $.get(Url, function (Data) {
            bootbox.dialog({
                title: Header,
                message: Data,
                onEscape: true,
                size: Size,
                className: ClassName,
                buttons: {
                    success: {
                        label: "Schließen",
                        className: "btn-success",
                        callback: CallBack
                    }
                }
            });
        });

    };



    this.goToPage = function (Page) 
    {
        Engine.LastUrl = location.href;
        location.href= Page ;
        /* Engine.hidePopup(); */
    };

    
    this.openInNewTab = function ( Url )
    {
        window.open(location.protocol + "//" + location.host + "/" + Url );
    }
    this.get = function (Url) {
        $.get(Url);
    };



    $(function () {
        Engine.init(); // init machen wenn dom ready
    });
    
    this.setFormEvents = function(Values)
    {
        this.setFromEvents(Values);
    }

    this.setFromEvents = function (Values, CallBack) {
        Values = Values || {};
        CallBack = CallBack || function(){};

        $('form').submit(function (e) {
            e.preventDefault();

            // gucken ob ein Password feld drin ist
            var $PassField = $('#tb_Pass');
            if ($PassField.length && $PassField.val().length > 0) {
                var $PassField2 = $('#tb_Pass2');
                if ($PassField2.val() != $PassField.val()) {
                    Engine.showPopup({
                        Html: "Die Passwörter stimmen nicht überein!  Bitte Prüfen sie die angegeben Passwörter",
                        Size: CONSTANTS.POPUP.SIZE.SMALL,
                        Backdrop: CONSTANTS.POPUP.BACKDROP.SHOW,
                        CloseButton: false,
                        Header: "Fehler"
                    });
                    return;
                }
            }
            // form per Ajax wegschicken
            var Link = $('form').attr("data-Url") || "";
            if (!Link.length) {
                Link = "index.php?Section=UpdateValues&Action=UpdateValues&Table=" + $('form').attr("data-tablename");
            }
            
            Engine.Values = [];
            Engine.getFormValue( Engine.sendForm, Link ); // async with files
            return false;
        });


        $('#btn_Controls1').click(function (e) {
            e.preventDefault(); // den Click wegmachen
            e.stopImmediatePropagation();
            
            // den letzten link 
            //var Link = "index.php?Section=Managment&Action=ShowManage" + $('form').attr("data-tablename");
            if( Engine.LastUrl )
            {
                Engine.goToPage( Engine.LastUrl );
            } else 
            {
              location.href = document.referrer ;
            
            }

        });

        var Keys = Object.keys(Values);
        Keys.remove("Pass");
        Keys.remove("Pass1");
        for (var i = 0; i < Keys.length; i++) 
        {
            var Key = Keys[i];
            var Value = Values[Key];

            try {

                var Element = $("." + Key);
                var ElementType = Element.attr("type");

                if (Element.is("select") && Element.prop( "multiple" ) ) {
                    Value = Value.split(",");
                    Element.find("option").each(function ( Index, Item ) {
                        var Item = $(Item);
                        if (~Value.indexOf(Item.attr("value"))) {
                            Item.prop("selected", "Selected");
                        }
                    });
                    continue;
                }
                
                if (Element.is("select") ) 
                {
                    Element.val( Value );
                    continue;
                }
                
                if( ElementType == "color" && Value)
                {
                    Element.val( "#" + Value );
                    continue;
                }
                

                if( !Element.val( ))
                {
                    Element.val( Value );
                }
                
                if ( Element.attr("data-type") == 'd' ) 
                {
                    var ValueDate = new Date( Value );
                    Element.val( ValueDate.getGermanDate() );
                }


            } catch (e) {};
        }


        $('select').select2({
            placeholder: "Bitte auswählen!",    
        });
        
        /*$(document).on('select2:open', () => 
        {
            document.querySelector('.select2-search__field').focus();
        });*/

        $('.btn_CreatePass').click(function () {
            $('#tb_Pass, #tb_Pass2').val(Utils.getRandomPass(8));
        });
        
        CallBack(Values);
    };

    this.sendForm = function (Link, Values) {
        $.ajax({
            type: "POST",
            url: Link,
            data: Values,
            success: function (Data) {
                if (Data.code == '1') {
                    $.alert({
                        title: 'Erfolgreich!',
                        content: 'Die Daten wurden erfolgreich übernommen.',
                        confirmButtonClass: 'btn-default btn-block',
                        onClose: function () {
                            // when the modal is removed from DOM
                            //alert('onDestroy');

                            var ConfirmLink = $('form').attr("data-confirm-link");
                            if (ConfirmLink) {
                                Engine.goToPage( "index.php?Section=UpdateValues&Action=Manage" + ConfirmLink );
                                return;
                            }
                            
                            
                            
                            var ContinueUrl = $('form').attr("data-continue-url");
                            if (ContinueUrl) {
                                Engine.goToPage( ContinueUrl );
                                return;
                            }
                            
                            var Link = $('form').attr("data-tablename");
                            if (Link) {
                                Engine.goToPage("index.php?Section=Values&Action=ShowManage&Table=" + Link);
                                return;
                            }

                            var LastPage = $('form').attr("last-page");
                            Engine.goToPage( Engine.LastUrl );
                        }
                    });
                    return;

                }

                $.alert({
                    title: 'Fehler!',
                    content: 'Das Objekt konnte nicht gespeichert werden. ' + Data.message,
                    confirmButtonClass: 'btn-default btn-block'
                });
                return;

            }
        });
    };

    this.getSimpleFormValue = function()
    {
        var InputElements = $('form input, form select, form textarea');
        Engine.Values = {};

        InputElements.each(function (Index, Item) {
            var $this = $(this);
            if ($this.attr("data-type") == "d")
            {
                var Value = $this.val();
                if( !Value )
                {
                    Engine.Values[$this.attr("name")] = "0000-00-00";
                    return true;
                }
                var ValueArray = Value.split(".");
                Engine.Values[$this.attr("name")] = ValueArray[2] + "-" + ValueArray[1] + "-" + ValueArray[0];
                return true;
            }
            Engine.Values[$this.attr("name")] = $this.val();
        });
        return Engine.Values
    }
    
    
    this.send = function( Url, Data, CallBack )
    {
        CallBack = CallBack || function(){};
        
        
    }
    
    
    this.getFormValuesSimple = function( Form )
    {
        if(  typeof Form == "string" ) Form = $(Form);
	var InputElements = $(Form).find('input, select, textarea');
        Engine.FileCounter = InputElements.length;
	var TempData = {};

        InputElements.each( function(Index, Item) 
	{
            var $this = $( this );
            TempData[ $this.attr("name") ] = $this.val();
	});
	return TempData;
    }
    
    

    this.getFormValue = function (CallBack, Link) {
        Engine.Values = {};
        var HasFile = false;
        Engine.FileCounter = 0;
        Engine.CallBack = CallBack;
        Engine.Link = Link;

        var InputElements = $('form input, form select, form textarea');
        Engine.FileCounter = InputElements.length;

        InputElements.each(function (Index, Item) {
            var $this = $(this);
            if ($this.attr("type") == "file") {
                if (!$this.get(0).files[0]) {
                    Engine.FileCounter--; // wenn kein Bild aktialisiert werden soll
                    return;
                }
                HasFile = true;
                
                var Extention = $this.get(0).files[0].name.split(".")[1];
                Engine.Values[$this.attr("name") + "Extention"] = Extention; // Die File Extention mitschicken
                Engine.Values[$this.attr("name") + "Name"] = $this.get(0).files[0].name; // Die File Extention mitschicken
                Engine.getBase64($this.attr("name"), $this.get(0).files[0]);
                return true;
            }

            if ($this.attr("data-type") == "d") {
                var Value = $this.val();
                
                if(Value == "")
                {
                    Engine.Values[$this.attr("name")] = "0000-00-00" ;
                    Engine.fileLoaded();
                    return;
                }
                
                 if( Value.indexOf("-") == 4 )// wenn in form 2021-05-10 
                {
                    Engine.Values[$this.attr("name")] = Value  ;
                    Engine.fileLoaded();
                    return;
                }
                
                
                var ValueArray = Value.split(".");
                Engine.Values[$this.attr("name")] = ValueArray[2] + "-" + ValueArray[1] + "-" + ValueArray[0];
                Engine.fileLoaded();
                return true;
            }

            if ($this.hasClass("chosen-search-input")) {
                Engine.fileLoaded();
                return;
            }

            if ($this.attr("data-type") == "f") {
                var Value = $this.val();
                Value = Value.replace(",",".");
                Engine.Values[$this.attr("name")] = Value;
                Engine.fileLoaded();
                return true;
            }
                


            Engine.Values[$this.attr("name")] = $this.val();
            Engine.fileLoaded();
        });
        return;
        //return Engine.Values

    };


    this.fileLoaded = function () {

        if (Engine.FileCounter > 1) {
            Engine.FileCounter--;
            return;
        }
        Engine.FileCounter--;
        Engine.CallBack(Engine.Link, Engine.Values );

    };


    this.getBase64 = function (Name, File) {
        var reader = new FileReader();
        reader.onload = function (readerEvt) {
            //console.log(reader.result);
            Engine.Values[Name] = btoa(reader.result);
            Engine.fileLoaded(File);
            //return reader.result;
        };

        reader.onerror = function (error) {
            console.log('Error: ', error);
        };

        return reader.readAsBinaryString(File);
    };


    this.Utils.toggleDropDown = function () {
        document.getElementById("myDropdown").classList.toggle("show");
    };




    this.showConfirm = function (Parameter) 
    {
        Parameter.callback = Parameter.callback || function() {};
        Parameter.Text = Parameter.Text || "";
        bootbox.confirm({
            message: Parameter.Text,
            locale: "de",
            callback: function (result) 
            {
                Parameter.callback(result);
                console.log('Confirm: ' + result);
            }
        }); 
    }


    this.showPromt = function (Parameter) 
    {
        Parameter.callback = Parameter.callback || function() {};
        Parameter.Text = Parameter.Text || "";
        Parameter.Type = Parameter.Type || "text";
        bootbox.prompt({
            title: Parameter.Text,
            locale: "de",
            inputType: Parameter.Type,
            callback: function ( result ) 
            {
                console.log( 'Promt: ' + result );
                Parameter.callback( result );
                
            }
        }); 
    }
    
    
    this.initTableSearch = function (Url, Templates)
    {

        $( "select.chosen.filter" ).select2({
            no_results_text: "leider nichts gefunden.",
            search_contains: true,
            max_shown_results: 10,
        });

        Templates = Templates || '';
        Url = Url || "";
        var Option = {
            Container: $('.SearchElementContainer'),
            SearchBar: $('#TableSearch'),
            TriggerElements: $('#TableSearch, .filter'),
            Templates: Templates
        };

        if (Url) {
            Option.Url = Url;
        }

        this.TableSearch = new TableSearch(Option);
    };
    


};

Array.prototype.remove = function () {
    var what, a = arguments,
        L = a.length,
        ax;
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1);
        }
    }
    return this;
};

Array.prototype.getUnique = function() {
 var o = {}, a = [], i, e;
 for (i = 0; e = this[i]; i++) {o[e] = 1};
 for (e in o) {a.push (e)};
 return a;
}


String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};


if (typeof Engine == "undefined") {
    Engine = new engine();
}


// Close the dropdown if the user clicks outside of it
window.onclick = function (event) {
    if (!event.target.matches('.dropbtn')) {

        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
Array.prototype.getColumn = function(name) {
    return this.map(function(el) {
       // gets corresponding 'column'
       if (el.hasOwnProperty(name)) return el[name];
       // removes undefined values
    }).filter(function(el) { return typeof el != 'undefined'; }); 
};
};

Date.prototype.monthDays= function(){
    var d= new Date(this.getFullYear(), this.getMonth()+1, 0);
    return d.getDate();
};

$(document).on('select2:open', () => {
    document.querySelector('.select2-search__field').focus();
});


class ImageLoader 
{
    async getImageDimensions( src )
    {
        return new Promise((resolve, reject) => 
        {
            let img = new Image()
            img.onload = () => resolve({"Height": img.height, "Width" : img.width })
            img.onerror = reject
            img.src = src
        });
    }
}