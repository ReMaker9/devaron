/**
 * Created by Matthias Herzog on 27.11.2019.
 */

/**
 * der ExampleController
 * @constructor
 */
ExampleController = function() 
{
    var __ExampleController = this; // own instance accessebela only from here __ExampleController.doSomething()

    this.Data = {};
	this.StrgPresset;

	// this.Storage = new Storage();


    this.init = function() 
	{
        setEvents();
        Engine.ExampleController = this; // den controler setzen
		this.IsMobile = false;
		if(  $(window).width() < 1000 )
		{
			this.IsMobile = true;
		}
		
    };
	
    function setEvents() 
	{

    }
	

    this.init();


	Engine.ExampleController = this;

}();