/**
 * Created by Matthias Herzog on 30.09.2016.
 */

/**
 * der AuthController für Dormino
 * @constructor
 */
AuthController = function () {
    var __AuthController = this; // own instance accessebela only from here

    this.Data = {};


    this.init = function () {
        setEvents();
    };

    this.setPassStrengtEvents = function () {
        var PassStrengthElement = $('.l_PassStrenght');
        $('.tb_Pass').keyup(function () {
            var $this = $(this);
            PassStrengthElement.removeClass("Medium");
            PassStrengthElement.removeClass("Good");
            PassStrengthElement.html("Schwach");


            if ($this.val().length >= 6) {
                PassStrengthElement.html("Ok");
                PassStrengthElement.addClass("Medium");
            }

            if ($this.val().length >= 8) {
                PassStrengthElement.html("Gut");
                PassStrengthElement.addClass("Good");
            }

        });
    };



    function setEvents() {

    }


    this.showLogin = function () 
    {
        $('#btn_Login').click(function (Event) {
            Event.preventDefault();
            if (!$('#tb_Name').val())
                return false;
            if (!$('#tb_Pass').val())
                return false;


            $('#f_LoginForm').removeClass("animated pulse");

            $.ajax({
                type: "POST",
                url: "index.php?Section=Login&Action=UserLogin",
                data: {
                    tb_Name: $('#tb_Name').val(),
                    tb_Pass: $('#tb_Pass').val()
                },
                success: function (Data) {
                    if (!Data)
                        return;

                    if (Data.code != 0) {
                        $('#f_LoginForm').addClass("animated pulse");

                        $.alert({
                            title: 'Fehler!',
                            content: Data.message,
                            confirmButtonClass: 'btn-default btn-block'
                        });
                        return false;
                    }

                    Engine.goToPage("index.php?Section=Start&Action=ShowDashboard");
                    return;

                    $.get("index.php?Section=Start&Action=ShowDashboard", function (Data) {
                        window.history.pushState({
                            "html": "index.php?Section=Start&Action=ShowDashboard",
                            "pageTitle": "titel"
                        }, "", "index.php?Section=Start&Action=ShowDashboard");
                        //Interface.setLastUrl( "index.php?Section=Start&Action=ShowDashboard" );
                        Engine.ContentContainer.hide();
                        Engine.ContentContainer.html(Data);
                        Engine.ContentContainer.fadeIn();


                    });
                    // eingeloggt und logout butten setzen
                    // registrieren verändern

                }
            });

            Event.preventDefault();
            return false;
        });

    };


    this.showPasswortReset = function () {
        $('#btn_Login').click(function (Event) {
            $.ajax({
                type: "POST",
                url: "index.php?Section=Login&Action=SendPasswortReset",
                data: {
                    tb_Mail: $('#tb_Mail').val()
                },
                success: function (Data) {
                    if (!Data)
                        return;

                    if( typeof Data == "string" )
                    {
                         Data = JSON.parse(Data);   
                    }

                    if (Data.code) {
                        $.alert({
                            title: 'Erfolgreich!',
                            content: Data.message,
                            confirmButtonClass: 'btn-default btn-block'
                        });
                        return;
                    }

                    $.alert({
                        title: 'Fehler!',
                        content: Data.message,
                        confirmButtonClass: 'btn-default btn-block'
                    });


                }
            });
            Event.preventDefault();
            return false;
        });
    };



    this.showPasswortResetSend = function () {
        $('#btn_ChangePass').click(function (Event) {

            if ($('#tbl_Pass').val() != $('#tbl_Pass2').val()) {
                $.alert({
                    title: 'Fehler!',
                    content: "Die Passwörter stimmen nicht überein.",
                    confirmButtonClass: 'btn-default btn-block'
                });
                return;
            }

            $.ajax({
                type: "POST",
                url: "index.php?Section=Login&Action=ResetPass",
                data: {
                    tb_Pass: $('#tb_Pass').val(),
                    tb_Pass2: $('#tb_Pass2').val(),
                    tb_Hash: $('#tb_Hash').val()
                },
                success: function (Data) {
                    if (!Data)
                        return;
                    
                    if( typeof Data == "string" )
                    {
                         Data = JSON.parse(Data);   
                    }
                    
                    if (Data.code) {
                        $.alert({
                            title: 'Erfolgreich!',
                            content: Data.message,
                            confirmButtonClass: 'btn-default btn-block'
                        });
                        return;
                    }

                    $.alert({
                        title: 'Fehler!',
                        content: Data.message,
                        confirmButtonClass: 'btn-default btn-block'
                    });


                }
            });
            Event.preventDefault();
            return false;
        });
    };


    this.init();

};