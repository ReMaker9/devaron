/**
 * Created by Matthias Herzog on 29.06.2015.
 */

/**
 * stellt funktionen zur animation und anzeige des interfaces zur verfügung. bsp fehlerausgabe, user abfragen usw.
 * @constructor
 */
InverfaceController = function()
{
	var Instance = this;
	var LastLoadUrl = '';
	var RTEKey = "";
	var publicIncludePath = 'static/';
	var includeFileHash = '';

	/*
	 *
	 */
	this.setLastUrl = function( Url )
	{
		LastLoadUrl = Url;
	};


	/**
	 * zeigt einen fehler an
	 * @param Response
	 */
	this.showError = function(Response)
	{
		bootbox.alert(
			{
				title : Engine.dict("error"),
				message : Response.message,
				className : "ModalError",
				backdrop : false
			});
	};
	/**
	 * zeigt einen fehler an
	 * @param Response
	 */
	this.alert = function(text, header)
	{
		bootbox.alert({
			title : header,
			message : text,
			className : "ModalError",
			backdrop : false
		});
	};
	/**
	 * zeigt einen fehler an
	 * @param Response
	 */
	this.inform = function(text, header)
	{
		bootbox.hideAll();
		bootbox.alert({
			title : header,
			message : text,
			className : "ModalSuccess",
			backdrop : false
		});
	};
	/**
	 * zeigt eine Modal box an mit einer Nachfrage
	 * @param param
	 * {
	 * 	Title : 'der Titel des Modals',
	 * 	buttons: {die Buttons des Panels}
	 * }
	 */
	this.confirm = function(param) {
	
		bootbox.hideAll();

		var option = {
			size: 'small',
			show : true,
			title : param.title || '',
			message : param.message || '',
			closeButton : param.closeButton || true,
			backdrop : param.backdrop || false,
			onEscape : true
		};
		
		var callback = param.callback || function(){};

		var buttons = param.buttons || {
			"ok" : {
				label: Engine.dict( 'ok' ),
				className: 'success',
				callback: callback
			},
			"cancel" : 1
		};

		option.buttons = getBoxButtons(buttons);
		
		var box = bootbox.dialog( option );
		
	}
	/**
	 * zeigt eine Modal box an mit einem Ajay get
	 * @param Param
	 * {
	 * 	Title : 'der Titel des Modals',
	 * 	buttons: {die Buttons des Panels}
	 * }
	 */
	this.showAjaxModal = function(Param)
	{
		bootbox.hideAll();
		
		var Options = {};
		Options.title = Param.Title || '';
		Options.closeButton = Param.CloseButton || true;

		var CallBack = Param.onLoad || function(){};

		Options.message = '<div class="spinner LoadingIndicator"> <div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"> </div></div>';


		if( typeof Param.Backdrop !== 'undefined')
		{
			Options.backdrop = Param.Backdrop;
		}
		Options.backdrop = null;


		if( typeof Param.OnEscape !== 'undefined')
		{
			Options.onEscape = true;
		}

		if( typeof Param.CloseButton !== 'undefined')
		{
			Options.closeButton = true;
		}

		Options.buttons = getBoxButtons( Param.Buttons || [ "ok" ] );
			
		Options.show = true; // das dialog fenster wird nicht gleich angezeigt

		var box = bootbox.dialog( Options );

		box.on("shown.bs.modal", function()
		{
			if( !Param.RequestUrl ) return;
			$.ajax(
			{
					type: "POST",
					url: Param.RequestUrl,
					data: {},
					success: function ( Data )
					{
						if( !Data )
						{
							return;
						}
						box.find(".bootbox-body").html( Data );
						CallBack();
					}
			});
		});
	};
	/**
	 *
	 */
	getBoxButtons = function( buttons ){
		var addCancel = false;
		
		$.each( buttons, function(i, btn){
			var btnName;
			if (typeof btn == 'object') return;
			
			if ( typeof i == 'number' ) {
				btnName = btn.toLowerCase();
				
			} else if ( typeof i == 'string' ) {
				btnName = i.toLowerCase();
				
			} else return;
			
			switch(btnName) {
				case 'delete':
				case 'ok':
					buttons[i] = {
						label: Engine.dict( btnName ),
						className: 'success',
						callback: function() {
							bootbox.hideAll();
						}
					};
					break;

 				case 'no':
				case 'yes': 
					buttons[i] = {
						label: Engine.dict( btnName ),
						className: 'success',
						callback: function() {
							bootbox.hideAll();
						}
					};
					break;
					
				case 'save':
				case 'apply':
					addCancel = true;
					buttons[i] = {
						label: Engine.dict( btnName ),
						className: 'success',
						callback: function() {
							$(".modal-content form").submit();
							return false;
						}
					};
					break;
					
				case 'close':

					addCancel = false;
					buttons[i] = {
						label: Engine.dict('Schließen'),
                        className: 'success',
                        callback: function()
                        {
							bootbox.hideAll();
						}
					};
					break;

				case 'cancel':
					addCancel = false;
					buttons[i] = {
						label: Engine.dict( btnName ),
						className: "btn-cancel",
						callback: function() {
							bootbox.hideAll();
						}
					};
					break;					
			}
		});
		if (addCancel) buttons['cancel'] = getBoxButtons( ['cancel'] ).pop();
		return buttons;
		return true;
	};
	/**
	 * läd den frame neu
	 */
	this.reload = function()
	{
		if(LastLoadUrl)
		{
			$.get( LastLoadUrl , function( data )
			{
				Engine.ContentContainer.html( data );
			});
			return;
		}

		$.get( location.pathname , function( data )
		{
			Engine.ContentContainer.html( data );
		});
		return;
		//window.location.reload();

	};





	InterfaceController = function()  // singelton
	{
		return Instance;
	};

	/**
	 * die css suchfunktion zum suchen in den übersichtsseiten
	 */
	this.searchFunction = function()
	{
		var $This = $(this);
		var Value = $This.val().toLowerCase(),
			$Elements = $('.l_SearchElements .Item');

		if( !Value.length )
		{
			// alles sichbar machen
			$Elements.fadeIn("100");
			return;
		}
		Value = Value.toLowerCase();
		$Elements.hide();
		$('[data-search*=' + Value + ']').show();

	};

	/**
	 * zeigt ein Popup über dem Element an.
	 * @param Element
	 * @param Content
	 */
	this.showPopupOnElement = function(Element, Content)
	{
		var $Element = $(Element ),
			$Position = $Element.offset();

		// Popup erzeugen

		var PopupHtml = "<div class='InfoPopup'>" + Content + "</div>";

		PopupHtml = $(PopupHtml);
		PopupHtml.css({
			top: CONSTANTS.INTERFACE.POPUP.OFFSET_TOP + $Position.top - parseInt( $Element.outerHeight(),10 ), 
			left: CONSTANTS.INTERFACE.POPUP.OFFSET_LEFT + $Position.left
		});
		$( 'body' ).append( PopupHtml );
		setTimeout(function(){ 
			PopupHtml.remove();
		}, 1000);

	};

	/**
	 * entfernt popups vom html dom tree
	 */
	this.hidePopup = function ()
	{
		$('.InfoPopup' ).remove();
	};

	this.closeModals = function()
	{
		bootbox.hideAll();
	};

	this.loadContent = function(Href)
	{
		if( !Href ) return;

		$.get( Href , function( data )
		{
			window.history.pushState({"html" : Href , "pageTitle":"titel"}, "", Href);
			Engine.ContentContainer.html( data );
		});
	};

	/**
	 * scrollt die Seite ganz nach unten
	 */
	this.scrollToBottom = function()
	{
		$("html, body").animate({ scrollTop: $(document).height() }, CONSTANTS.INTERFACE.SCROLL_TO_BOTTOM_TIMEOUT);
	};
	/*
	 *
	 */
	this.setPublicIncludePath = function( val ) {
		publicIncludePath = val;
	}
	/*
	 *
	 */
	this.setIncludesHash = function( val ) {
		includeFileHash = val;
	}
	
	/*
	 *
	 */
	this.setRTEKey = function( key ) {
		RTEKey = key;
	}
	/*
	 * init RichTextEditor
	 * @param selector - CSS - selector 
	 */
	this.initRTE = function( selector, options ){
		
		var btnGroups = {
			none  : [],
			small : ['bold', 'italic', 'underline'],
			normal: ['bold', 'italic', 'underline', 'strikeThrough', 'subscript', 'superscript', 'fontFamily', 'fontSize', '|', 'color', 'emoticons', 'inlineStyle', 'paragraphStyle', '|', 'paragraphFormat', 'align', 'formatOL', 'formatUL', 'outdent', 'indent', 'quote',  'insertLink', 'undo', 'redo', 'clearFormatting', 'html'],			
				     
			full : ['fullscreen', 'bold', 'italic', 'underline', 'strikeThrough', 'subscript', 'superscript', 'fontFamily', 'fontSize', '|', 'color', 'emoticons', 'inlineStyle', 'paragraphStyle', '|', 'paragraphFormat', 'align', 'formatOL', 'formatUL', 'outdent', 'indent', 'quote', 'insertHR', '-', 'insertLink', 'insertImage', 'insertVideo', 'insertFile', 'insertTable', 'undo', 'redo', 'clearFormatting', 'selectAll', 'html'] // "-" - is ein separator fuer neue zeile
		};
		var placeholderDefault = 'Type something';
		var options = options || {};
		
		var params = {
			toolbarInline   : (typeof options.inline != "undefined" ? options.inline : true),
			toolbarButtons  : options.buttons || btnGroups.small,
			placeholderText : options.placeholder || placeholderDefault,
			minHeight       : options.minHeight || false,
			height          : options.height || false
			//todo: ...
		}
		//set buttons
		if (typeof options.btnGroup != "undefined" || btnGroups[options.btnGroup] != 'undefined' ) 
			params.toolbarButtons = $.extend( params.toolbarButtons, btnGroups[options.btnGroup] );
			
		//include scripts
		var required = [
			{ path : 'ext/froala/css/froala_editor.min.css' },
			{ path : 'ext/froala/css/froala_style.min.css' },
			{ path : 'css/froalaCustom.css' },			
			{ path : 'ext/froala/js/froala_editor.min.js' } 
		];
		if ( this.isIEBrowserLowerThan( 9 ) ) {
			required[required.length] = { path: 'ext/froala/js/froala_editor_ie8.min.js' };
		}
		
		//add plug-ins
		if ( $.inArray( 'insertLink', params.buttons) > -1) {
			//??required[required.length] = { path: 'ext/froala/js/plugins/url.min.js' };
			required[required.length] = { path: 'ext/froala/js/plugins/link.min.js' };
			params.linkList = false;
			params.linkEditButtons = ['linkEdit', 'linkRemove'];
		}
		
		if ( $.inArray( 'insertImage', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/css/plugins/image.min.css' };
			required[required.length] = { path: 'ext/froala/css/plugins/image_manager.min.css' };
			required[required.length] = { path: 'ext/froala/js/plugins/image.min.js' };
			required[required.length] = { path: 'ext/froala/js/plugins/image_manager.min.js' };
		}
		
		if ( $.inArray( 'align', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/js/plugins/align.min.js' };
		}
		if ( $.inArray( 'fontFamily', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/js/plugins/font_family.min.js' };
		}
		if ( $.inArray( 'fontSize', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/js/plugins/font_size.min.js' };
		}
		if ( $.inArray( 'table', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/css/plugins/table.min.css' };
			required[required.length] = { path: 'ext/froala/js/plugins/table.min.js' };
		}
		if ( $.inArray( 'fullscreen', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/css/plugins/fullscreen.min.css' };
			required[required.length] = { path: 'ext/froala/js/plugins/fullscreen.min.js' };
		}
		if ( $.inArray( 'color', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/css/plugins/colors.min.css' };
			required[required.length] = { path: 'ext/froala/js/plugins/colors.min.js' };
		}
		if ( $.inArray( 'quote', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/js/plugins/quote.min.js' };
		}
		if ( $.inArray( 'emoticons', params.buttons) > -1) {
			//todo: required[required.length] = { path: 'ext/froala/css/plugins/emoticons.min.css' };
			//todo: required[required.length] = { path: 'ext/froala/js/plugins/emoticons.min.js' };
		}
		if ( $.inArray( 'inlineStyle', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/js/plugins/inline_style.min.js' };
		}		
		if ( $.inArray( 'formatOL', params.buttons) || $.inArray( 'formatUL', params.buttons) ) {
			required[required.length] = { path: 'ext/froala/js/plugins/lists.min.js' };
		}
		if ( $.inArray( 'paragraphFormat', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/js/plugins/paragraph_format.min.js' };
		}
		if ( $.inArray( 'paragraphStyle', params.buttons) > -1) {
			required[required.length] = { path: 'ext/froala/js/plugins/paragraph_style.min.js' };
		}
		if ( $.inArray( 'html', params.buttons) > -1 ) {
			required[required.length] = { path: 'ext/froala/css/plugins/code_view.min.css' };
			required[required.length] = { path: 'ext/froala/js/plugins/code_view.min.js' };
			//add code mirror
			required[required.length] = { path: 'ext/codemirror/codemirror.css' };
			required[required.length] = { path: 'ext/codemirror/codemirror.js' };
			required[required.length] = { path: 'ext/codemirror/mode/xml/xml.js' };
			params.codeMirror = true;
			params.codeBeautifier = true;
			params.codeMirrorOptions = {
				indentWithTabs: true,
				lineNumbers: true,
				lineWrapping: true,
				mode: 'text/html',
				tabMode: 'indent',
				tabSize: 2
			};
		}
		
		//set init on load
		required[required.length-1].onload = function(){
			$.FroalaEditor.DEFAULTS.key = RTEKey;
			
			console.log("Froala editor", selector, params);
			
			var $el;
			if (typeof selector == "object") $el = typeof selector.get == "undefined" ? $(el) : selector;
			else if (selector.substr(0,1) == '.' || selector.substr(0,1) == '#') $el = $(selector);
			else $el = $(selector);
			
			//klein hook $('a[href="https://froala.com/wysiwyg-editor"]').remove();
			
			$el.each(function(){
				
				var p = $.extend({},params);
				
				//set text placeholder
				if (p.placeholderText == placeholderDefault && $(this).attr('placeholder') != '') {
					p.placeholderText = $(this).attr('placeholder');
				}
				//set height
				if (p.height == false ) p.height = p.minHeight = $(this).height();
				
				//init RTE
				$(this).froalaEditor( p );					
				
				// set event onBlur, set text in textarea
				$(this).on('froalaEditor.blur', function (e, editor) {
					$(this).val( editor.html.get()); 
				});	
				
				//set classes from textarea 
				$( $(this.parentNode).find("div.fr-wrapper")[0] ).addClass( $(this).attr("class") );
				//set custom classes
				if (params.editorClass) 
					$( $(this.parentNode).find("div.fr-wrapper")[0] ).addClass( params.editorClass );
					
			});
			
		};	
		
		this.include( required );	
	}
	//$(selector).data('froala.editor').$el.text().
	this.initCodemirror = function( selector, options )
	{

		var CodeMirrorConfig = {
			mode: "text/html",
			lineNumbers: true,
			lineWrapping: true,
			foldGutter: true,
			gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
			matchTags: {bothTags: true},
			autoCloseTags: true,
			autoCloseBrackets: true,
			styleActiveLine: true,
			extraKeys: {
				"Ctrl-Q": function(cm){ cm.foldCode(cm.getCursor()); }, 
				"Ctrl-Space": "autocomplete", 
				"Ctrl-J": "toMatchingTag"
			}
		};
		var params = $.extend({},CodeMirrorConfig);
		 
		for( k in CodeMirrorConfig ) {
			if (typeof options[k] !== "undefined") params[k] = options[k];

		}
		
		
		this.include([
			{ path : 'ext/codemirror/codemirror.css' },
			{ path : 'ext/codemirror/addons.css' },
			{ path : 'ext/codemirror/codemirror.js' },
			{ path : 'ext/codemirror/addons.js', onload: function(){
				
				var myCodeMirror = CodeMirror.fromTextArea( $( selector ).get(0), params);
				var myCodeMirror_delay;
				myCodeMirror.on("change", function() {
				clearTimeout(myCodeMirror_delay);
					myCodeMirror_delay = setTimeout(updatePreview, 300);
				});
		
				function updatePreview() {
					var previewFrame = document.getElementById("tb_email_template_preview");
					var preview =  previewFrame.contentDocument ||  previewFrame.contentWindow.document;
					preview.open();
					preview.write(myCodeMirror.getValue());
					preview.close();
				};
				setTimeout(updatePreview, 300);
			}}
		]);
	};
												
	/*
	 * init the uploader
	 *
	 */
	var uploaders = [];
	this.initUploader = function( el, options )
	{
		uploaders[el] = false;
		var options = options || {}
		var templateName = ( options.template || 'default' );
		
		options.template = 'tpl_uploader_'+templateName;
		options.element = document.getElementById(el);
		
				
		var required = [
			{ path : 'ext/fineuploader/fine-uploader-gallery.css' },
			{ path : 'ext/fineuploader/fine-uploader.js' },
			{ path : 'js/lib/class.uploader.js' },
			{ path : 'ext/fineuploader/tpl/'+ templateName+'.tpl', id: options.template , onload : function(){
			
				uploaders[el] = new Uploader( options );
			}}
		];
		this.include( required );
	};
	/**
	 *
	 */
	this.getUploader = function( el ) {
	console.log( el , uploaders );
		if (typeof uploaders[el] != 'undefined') return uploaders[el];
		else return false;
	};

	
	/*
	 *	add js or css to document <head />
	 *	@param array of objects { path: string, onload: function }
	 */
	this.include = function( includeList ) {
		var d = document;
		
		var js_path = css_path = publicIncludePath;
		
		if (includeList.length == 0) return true;
		var item;
		while( item = includeList.shift() ) {
			
			var e = item.path.split('.');
			if (e.length < 2) continue;
			e = e[e.length-1].toLowerCase();
			var tagName, tagType, pathAttrName, path;
			
			switch( e ) {
				case "tpl":tagName = "SCRIPT"; tagType = ""; pathAttrName = "PSEUDOSRC"; path = js_path; break;
				case "js": tagName = "SCRIPT"; tagType = ""; pathAttrName = "SRC"; path = js_path; break;
				case "css": tagName = "LINK"; tagType = "text/css", pathAttrName = "HREF"; path =css_path; break;
				default: continue;
			}
			var loaded = false;
			
			var dl = d.getElementsByTagName(tagName);
			var itemPath = item.path;
			if (itemPath.substr(0,4) != "http" && itemPath.substr(0,2) != "//") itemPath = path+item.path;
				
			for(var j = 0; j < dl.length; j++) {
				if (tagType != "") {
					var dlt = dl[j].getAttribute("type");
					if ( dlt != tagType ) continue;
				}
				var dla = dl[j].getAttribute(pathAttrName);
				if (typeof dla == "undefined" || dla == "" || !dla) continue;
				//todo: includeFileHash beachten!
				if (dla == itemPath ) { loaded = true; break; } 
				
			}
			if (loaded && typeof item.onload != "undefined") {
				item.onload();
				continue;
			} else if (loaded) continue;
			
			switch( e ) {
				case "js": 
					var o = d.createElement( tagName );
					o.type = "text/javascript";
					if (typeof item.id != "undefined") o.id = item.id;
					
					o.setAttribute( pathAttrName, itemPath );
					if (typeof item.onload == "function" ) { 
						o.onAfterLoad = item.onload;
						o.onload = function() { 
							//console.log( 'loaded',this , includeList ); 
							this.onAfterLoad();
							Instance.include( includeList );
						}; 
					} else { o.onload = function() { 
							//console.log( 'loaded',this , includeList ); 
							Instance.include( includeList );
						}; 
					}
					document.getElementsByTagName("head")[0].appendChild(o);
					console.log( "included" ,  tagName, itemPath);
					
					return ;
				
				case "tpl": 
					var o = d.createElement( tagName );
					o.type = "text/template";
					if (typeof item.id != "undefined") o.id = item.id;
					
					o.setAttribute( pathAttrName, itemPath );
					
					if (typeof item.onload == "function" ) { 
						o.onAfterLoad = item.onload;
						o.onload = function() { 
							//console.log( 'loaded',this , includeList); 
							this.onAfterLoad();
							Instance.include( includeList );
						}; 
					} else { 
						o.onload = function() { 
							//console.log( 'loaded',this, includeList ); 
							Instance.include( includeList );
						}; 
					}
					
					document.getElementsByTagName("head")[0].appendChild(o);
					$(o).load( itemPath, function( response ) {
							//o.innerHTML = response;
							o.onload();
							console.log( "included" , tagName, itemPath);
					}); 
					
					return ;
				
				case "css": 
					if(d.createStyleSheet) {
						d.createStyleSheet( itemPath );
					} else {
						var o = d.createElement( tagName );
						o.type = "text/css";
						o.rel = "stylesheet";
						o.href = itemPath; 
						document.getElementsByTagName("head")[0].appendChild(o);
						if (typeof item.onload == "function" ) { item.onload(); }
					}
					console.log( "included" ,  tagName, itemPath);
					break;
			}
		}	
	}
	
	this.isIEBrowserLowerThan = function( version ) {
		var div = document.createElement('DIV');
		div.innerHTML = '<!--[if lte IE '+version+']><I></I><![endif]-->';
		return div.getElementsByTagName('I').length > 0;
	};
 
};

if(typeof Interface == "undefined" )
{
	Interface = new InverfaceController(); // das interface Global verfügbarmachen
}




