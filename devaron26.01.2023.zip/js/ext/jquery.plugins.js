/**
 * Created by Matthias Herzog on 25.06.2015.
 */

/**
 * {
 * Element : das element das im sichtbaren bereich sein soll
 * onScroll : function() {} die function die ausgeführt werden sollen wenn unterhalb eines bestimmten bereichts gescrollt wurden ist
 * }
 * @param Param
 */
$.fn.yScroll = function( Param )
{
	var $this = $( this ),
		Param = Param || {},
		onScroll = Param.onScroll || function() {},
		Element =  typeof Param.Element  == 'string' ? $( Param.Element ) : Param.Element;


	if( $this.length > 1 )
	{
		$this.each(function( Index, Item )
		{
			$( Item ).yScroll( Param );
		});
		return;
	}


	var Height = $this.height(),
		WindowHeight = $(window).height();

	var onscroll = function(){
	
		if(  Element.isOnScreen() )
		{
			onScroll( $this );
			$this.unbind('scroll'); // den request wieder wegmachen nachdem einmal geladen wurde
		}
	
	}
	$this.unbind('scroll', onscroll).bind( 'scroll',  onscroll );
	onscroll();
		
};

/**
 * Prüft ob das element im sichtbaren bereich ist
 * @returns {boolean}
 */
$.fn.isOnScreen = function()
{
	try{
		var viewport = {};
		viewport.top = $(window).scrollTop();
		viewport.bottom = viewport.top + $(window).height();
		var bounds = {};
		bounds.top = this.offset().top;
		bounds.bottom = bounds.top + this.outerHeight();
		return ((bounds.top <= viewport.bottom) && (bounds.bottom >= viewport.top));
	} catch( Exception )
	{
		return true;
	}
};

$.fn.focusToEnd = function()
{
	return this.each(function()
	{
		var v = $(this).val();
		$(this).focus().val("").val( v );
	});
};

/* set ajax-marker in header */
$.ajaxSetup({
    headers: { 'Ajax-Request': 'true' }
});


/*! jQuery Ajax Queue v0.1.2pre | (c) 2013 Corey Frang | Licensed MIT */
(function(e){var r=e({});e.ajaxQueue=function(n){function t(r){u=e.ajax(n),u.done(a.resolve).fail(a.reject).then(r,r)}var u,a=e.Deferred(),i=a.promise();return r.queue(t),i.abort=function(o){if(u)return u.abort(o);var c=r.queue(),f=e.inArray(t,c);return f>-1&&c.splice(f,1),a.rejectWith(n.context||n,[i,o,""]),i},i}})(jQuery);
//@ sourceMappingURL=dist/jquery.ajaxQueue.min.map

