jQuery.fn.jFormValid = function (init)
{
    var $this = $(this);

    init = init || {};

    // Do your awesome plugin stuff here	
    $this.ErrorCssClass = init.ErrorClass || "MyError";
    $this.Left = (init.Left) ? init.Left * 1 : 60;
    $this.RenderError = init.RenderError || false;
    $this.ErrorLog = '';



    $this.submit(function ()
    {
        return $this.check();
        return false;
    });


    $this.renderError = function (Element)
    {
        $this.ErrorLog += "<p>" + Element.attr("jfvError") + "</p>";
        if (!$this.RenderError)
            return;
        Element.addClass($this.ErrorCssClass);
        // tooltip zeichen
        var position = Element.offset();
        $("<div class='jfvErrorLayer' style='left:" + (position.left + $this.Left + Element.width()) + "px;top:" + position.top + "px;'><p>" + Element.attr("jfvError") + "</p></div>").appendTo("body")

    };


    $this.ClearError = function (Element)
    {
        Element.removeClass($this.ErrorCssClass);
        // tooltip zeichen	
    };
    $this.ClearErrorLayer = function (Element)
    {
        $('.jfvErrorLayer').remove();
        return true;
    };

    $this.check = function ()
    {
        // .tagName
        var $Inputs = $this.find("input");
        var FormErrors = 0;
        $this.ClearErrorLayer();
        $.each($Inputs, function (index, value)
        {
            value = $(value);
            $this.ClearError(value);
            if (value.css('display') == "none")
                return;
            //return false;
            // pr�fen ob elemente fehlerhaft sind oder nicht 
            switch (value.attr("jfvType"))
            {
                case "string":
                    {
                        var Length = (value.attr("jfvLength")) ? value.attr("jfvLength") : 1;
                        if (Length > value.val().length)
                        {
                            FormErrors++;
                            $this.renderError(value);
                        }
                    }
                    break;
                case "mail":
                    {
                        var MailValue = value.val();
                        if (MailValue.indexOf("@") == -1 || MailValue.indexOf(".") == -1)
                        {
                            FormErrors++;
                            $this.renderError(value);
                        }
                    }
                    break;

                case "number":
                    {
                        var NumberValue = value.val();
                        NumberValue = NumberValue.replace(",", ".");
                        if (isNaN(NumberValue) || NumberValue == "")
                        {
                            FormErrors++;
                            $this.renderError(value);
                        }
                    }
                    break;
                case "select":
                    {
                        var SelectValue = value.val();
                        if (SelectValue == "-1")
                        {
                            FormErrors++;
                            $this.renderError(value);
                        }
                    }
                    break;


                case "confirm":
                {
                    var Passwordvalue = value.val();
                    var ConfirmId = value.attr("jvfConfirmId");
                    var ConfirmValue = $("#" + ConfirmId).val();
                    if (Passwordvalue != ConfirmValue)
                    {
                        FormErrors++;
                        $this.renderError(value);
                    }
                }
            }
        });
        if (FormErrors > 0)
        {
            return false;
        }
        return true;

    };


    return {
        check: function () {
            return $this.check();
        },
        clear: function ()
        {
            return $this.ClearErrorLayer();
        },
        getError: function ()
        {
            return $this.ErrorLog;
        }
    };


};