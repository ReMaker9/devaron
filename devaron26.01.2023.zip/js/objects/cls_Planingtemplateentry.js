Planingtemplateentry= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.LastEdit=(Init.LastEdit) ? Init.LastEdit : '';
	this.PlaningTemplateId=(Init.PlaningTemplateId) ? Init.PlaningTemplateId : '';
	this.PlaningTemplateEntryType=(Init.PlaningTemplateEntryType) ? Init.PlaningTemplateEntryType : '';
	this.Sort=(Init.Sort) ? Init.Sort : '';
	this.Lines=(Init.Lines) ? Init.Lines : '';
	this.Name=(Init.Name) ? Init.Name : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getLastEdit = function()
	{
		return this.LastEdit;
	}
		this.setLastEdit = function(LastEdit)
	{
		this.LastEdit=LastEdit;
	}

	this.getPlaningTemplateId = function()
	{
		return this.PlaningTemplateId;
	}
		this.setPlaningTemplateId = function(PlaningTemplateId)
	{
		this.PlaningTemplateId=PlaningTemplateId;
	}

	this.getPlaningTemplateEntryType = function()
	{
		return this.PlaningTemplateEntryType;
	}
		this.setPlaningTemplateEntryType = function(PlaningTemplateEntryType)
	{
		this.PlaningTemplateEntryType=PlaningTemplateEntryType;
	}

	this.getSort = function()
	{
		return this.Sort;
	}
		this.setSort = function(Sort)
	{
		this.Sort=Sort;
	}

	this.getLines = function()
	{
		return this.Lines;
	}
		this.setLines = function(Lines)
	{
		this.Lines=Lines;
	}

	this.getName = function()
	{
		return this.Name;
	}
		this.setName = function(Name)
	{
		this.Name=Name;
	}

}