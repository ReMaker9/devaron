Planingtemplate= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.LastEdit=(Init.LastEdit) ? Init.LastEdit : '';
	this.Name=(Init.Name) ? Init.Name : '';
	this.PositionX=(Init.PositionX) ? Init.PositionX : '';
	this.PositionY=(Init.PositionY) ? Init.PositionY : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getLastEdit = function()
	{
		return this.LastEdit;
	}
		this.setLastEdit = function(LastEdit)
	{
		this.LastEdit=LastEdit;
	}

	this.getName = function()
	{
		return this.Name;
	}
		this.setName = function(Name)
	{
		this.Name=Name;
	}

	this.getPositionX = function()
	{
		return this.PositionX;
	}
		this.setPositionX = function(PositionX)
	{
		this.PositionX=PositionX;
	}

	this.getPositionY = function()
	{
		return this.PositionY;
	}
		this.setPositionY = function(PositionY)
	{
		this.PositionY=PositionY;
	}

}