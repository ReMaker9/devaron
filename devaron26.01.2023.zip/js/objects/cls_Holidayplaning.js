Holidayplaning= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.UserId=(Init.UserId) ? Init.UserId : '';
	this.Date=(Init.Date) ? Init.Date : '';
	this.State=(Init.State) ? Init.State : '';
	this.CommentUser=(Init.CommentUser) ? Init.CommentUser : '';
	this.CommentSupervisor=(Init.CommentSupervisor) ? Init.CommentSupervisor : '';
	this.AcceptDateSupervisor=(Init.AcceptDateSupervisor) ? Init.AcceptDateSupervisor : '';
	this.AcceptDateLineManager=(Init.AcceptDateLineManager) ? Init.AcceptDateLineManager : '';
	this.LastEditDate=(Init.LastEditDate) ? Init.LastEditDate : '';
	this.SupervisorId=(Init.SupervisorId) ? Init.SupervisorId : '';
	this.LineManagerId=(Init.LineManagerId) ? Init.LineManagerId : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getUserId = function()
	{
		return this.UserId;
	}
		this.setUserId = function(UserId)
	{
		this.UserId=UserId;
	}

	this.getDate = function()
	{
		return this.Date;
	}
		this.setDate = function(Date)
	{
		this.Date=Date;
	}

	this.getState = function()
	{
		return this.State;
	}
		this.setState = function(State)
	{
		this.State=State;
	}

	this.getCommentUser = function()
	{
		return this.CommentUser;
	}
		this.setCommentUser = function(CommentUser)
	{
		this.CommentUser=CommentUser;
	}

	this.getCommentSupervisor = function()
	{
		return this.CommentSupervisor;
	}
		this.setCommentSupervisor = function(CommentSupervisor)
	{
		this.CommentSupervisor=CommentSupervisor;
	}

	this.getAcceptDateSupervisor = function()
	{
		return this.AcceptDateSupervisor;
	}
		this.setAcceptDateSupervisor = function(AcceptDateSupervisor)
	{
		this.AcceptDateSupervisor=AcceptDateSupervisor;
	}

	this.getAcceptDateLineManager = function()
	{
		return this.AcceptDateLineManager;
	}
		this.setAcceptDateLineManager = function(AcceptDateLineManager)
	{
		this.AcceptDateLineManager=AcceptDateLineManager;
	}

	this.getLastEditDate = function()
	{
		return this.LastEditDate;
	}
		this.setLastEditDate = function(LastEditDate)
	{
		this.LastEditDate=LastEditDate;
	}

	this.getSupervisorId = function()
	{
		return this.SupervisorId;
	}
		this.setSupervisorId = function(SupervisorId)
	{
		this.SupervisorId=SupervisorId;
	}

	this.getLineManagerId = function()
	{
		return this.LineManagerId;
	}
		this.setLineManagerId = function(LineManagerId)
	{
		this.LineManagerId=LineManagerId;
	}

}