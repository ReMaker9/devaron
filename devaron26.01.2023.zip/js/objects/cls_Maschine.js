Maschine= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.Name=(Init.Name) ? Init.Name : '';
	this.ExternalId=(Init.ExternalId) ? Init.ExternalId : '';
	this.Description=(Init.Description) ? Init.Description : '';
	this.Type=(Init.Type) ? Init.Type : '';
	this.Sort=(Init.Sort) ? Init.Sort : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getName = function()
	{
		return this.Name;
	}
		this.setName = function(Name)
	{
		this.Name=Name;
	}

	this.getExternalId = function()
	{
		return this.ExternalId;
	}
		this.setExternalId = function(ExternalId)
	{
		this.ExternalId=ExternalId;
	}

	this.getDescription = function()
	{
		return this.Description;
	}
		this.setDescription = function(Description)
	{
		this.Description=Description;
	}

	this.getType = function()
	{
		return this.Type;
	}
		this.setType = function(Type)
	{
		this.Type=Type;
	}

	this.getSort = function()
	{
		return this.Sort;
	}
		this.setSort = function(Sort)
	{
		this.Sort=Sort;
	}

}