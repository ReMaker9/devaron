Sickdays= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.UserId=(Init.UserId) ? Init.UserId : '';
	this.Date=(Init.Date) ? Init.Date : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getUserId = function()
	{
		return this.UserId;
	}
		this.setUserId = function(UserId)
	{
		this.UserId=UserId;
	}

	this.getDate = function()
	{
		return this.Date;
	}
		this.setDate = function(Date)
	{
		this.Date=Date;
	}

}