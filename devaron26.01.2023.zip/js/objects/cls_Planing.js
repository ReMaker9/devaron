Planing= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.Week=(Init.Week) ? Init.Week : '';
	this.Year=(Init.Year) ? Init.Year : '';
	this.Description=(Init.Description) ? Init.Description : '';
	this.Name=(Init.Name) ? Init.Name : '';
	this.ShiftGroup=(Init.ShiftGroup) ? Init.ShiftGroup : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getWeek = function()
	{
		return this.Week;
	}
		this.setWeek = function(Week)
	{
		this.Week=Week;
	}

	this.getYear = function()
	{
		return this.Year;
	}
		this.setYear = function(Year)
	{
		this.Year=Year;
	}

	this.getDescription = function()
	{
		return this.Description;
	}
		this.setDescription = function(Description)
	{
		this.Description=Description;
	}

	this.getName = function()
	{
		return this.Name;
	}
		this.setName = function(Name)
	{
		this.Name=Name;
	}

	this.getShiftGroup = function()
	{
		return this.ShiftGroup;
	}
		this.setShiftGroup = function(ShiftGroup)
	{
		this.ShiftGroup=ShiftGroup;
	}

}