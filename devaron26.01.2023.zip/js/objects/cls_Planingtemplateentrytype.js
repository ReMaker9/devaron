Planingtemplateentrytype= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.Type=(Init.Type) ? Init.Type : '';
	this.Name=(Init.Name) ? Init.Name : '';
	this.Description=(Init.Description) ? Init.Description : '';
	this.Color=(Init.Color) ? Init.Color : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getType = function()
	{
		return this.Type;
	}
		this.setType = function(Type)
	{
		this.Type=Type;
	}

	this.getName = function()
	{
		return this.Name;
	}
		this.setName = function(Name)
	{
		this.Name=Name;
	}

	this.getDescription = function()
	{
		return this.Description;
	}
		this.setDescription = function(Description)
	{
		this.Description=Description;
	}

	this.getColor = function()
	{
		return this.Color;
	}
		this.setColor = function(Color)
	{
		this.Color=Color;
	}

}