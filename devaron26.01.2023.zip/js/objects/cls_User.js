User= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.Name=(Init.Name) ? Init.Name : '';
	this.Pass=(Init.Pass) ? Init.Pass : '';
	this.LastLogin=(Init.LastLogin) ? Init.LastLogin : '';
	this.Mail=(Init.Mail) ? Init.Mail : '';
	this.Type=(Init.Type) ? Init.Type : '';
	this.adName=(Init.adName) ? Init.adName : '';
	this.Active=(Init.Active) ? Init.Active : '';
	this.EntryIds=(Init.EntryIds) ? Init.EntryIds : '';
	this.LeasedEmployee=(Init.LeasedEmployee) ? Init.LeasedEmployee : '';
	this.Department=(Init.Department) ? Init.Department : '';
	this.ErrorReporter=(Init.ErrorReporter) ? Init.ErrorReporter : '';
	this.MailCC=(Init.MailCC) ? Init.MailCC : '';
	this.CanPlan=(Init.CanPlan) ? Init.CanPlan : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getName = function()
	{
		return this.Name;
	}
		this.setName = function(Name)
	{
		this.Name=Name;
	}

	this.getPass = function()
	{
		return this.Pass;
	}
		this.setPass = function(Pass)
	{
		this.Pass=Pass;
	}

	this.getLastLogin = function()
	{
		return this.LastLogin;
	}
		this.setLastLogin = function(LastLogin)
	{
		this.LastLogin=LastLogin;
	}

	this.getMail = function()
	{
		return this.Mail;
	}
		this.setMail = function(Mail)
	{
		this.Mail=Mail;
	}

	this.getType = function()
	{
		return this.Type;
	}
		this.setType = function(Type)
	{
		this.Type=Type;
	}

	this.getadName = function()
	{
		return this.adName;
	}
		this.setadName = function(adName)
	{
		this.adName=adName;
	}

	this.getActive = function()
	{
		return this.Active;
	}
		this.setActive = function(Active)
	{
		this.Active=Active;
	}

	this.getEntryIds = function()
	{
		return this.EntryIds;
	}
		this.setEntryIds = function(EntryIds)
	{
		this.EntryIds=EntryIds;
	}

	this.getLeasedEmployee = function()
	{
		return this.LeasedEmployee;
	}
		this.setLeasedEmployee = function(LeasedEmployee)
	{
		this.LeasedEmployee=LeasedEmployee;
	}

	this.getDepartment = function()
	{
		return this.Department;
	}
		this.setDepartment = function(Department)
	{
		this.Department=Department;
	}

	this.getErrorReporter = function()
	{
		return this.ErrorReporter;
	}
		this.setErrorReporter = function(ErrorReporter)
	{
		this.ErrorReporter=ErrorReporter;
	}

	this.getMailCC = function()
	{
		return this.MailCC;
	}
		this.setMailCC = function(MailCC)
	{
		this.MailCC=MailCC;
	}

	this.getCanPlan = function()
	{
		return this.CanPlan;
	}
		this.setCanPlan = function(CanPlan)
	{
		this.CanPlan=CanPlan;
	}

}