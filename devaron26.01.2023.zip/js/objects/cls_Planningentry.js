Planningentry= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.Date=(Init.Date) ? Init.Date : '';
	this.UserId=(Init.UserId) ? Init.UserId : '';
	this.Sort=(Init.Sort) ? Init.Sort : '';
	this.Description=(Init.Description) ? Init.Description : '';
	this.InternalDescription=(Init.InternalDescription) ? Init.InternalDescription : '';
	this.PlaningTemplateId=(Init.PlaningTemplateId) ? Init.PlaningTemplateId : '';
	this.PlaningTemplateEntryId=(Init.PlaningTemplateEntryId) ? Init.PlaningTemplateEntryId : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getDate = function()
	{
		return this.Date;
	}
		this.setDate = function(Date)
	{
		this.Date=Date;
	}

	this.getUserId = function()
	{
		return this.UserId;
	}
		this.setUserId = function(UserId)
	{
		this.UserId=UserId;
	}

	this.getSort = function()
	{
		return this.Sort;
	}
		this.setSort = function(Sort)
	{
		this.Sort=Sort;
	}

	this.getDescription = function()
	{
		return this.Description;
	}
		this.setDescription = function(Description)
	{
		this.Description=Description;
	}

	this.getInternalDescription = function()
	{
		return this.InternalDescription;
	}
		this.setInternalDescription = function(InternalDescription)
	{
		this.InternalDescription=InternalDescription;
	}

	this.getPlaningTemplateId = function()
	{
		return this.PlaningTemplateId;
	}
		this.setPlaningTemplateId = function(PlaningTemplateId)
	{
		this.PlaningTemplateId=PlaningTemplateId;
	}

	this.getPlaningTemplateEntryId = function()
	{
		return this.PlaningTemplateEntryId;
	}
		this.setPlaningTemplateEntryId = function(PlaningTemplateEntryId)
	{
		this.PlaningTemplateEntryId=PlaningTemplateEntryId;
	}

}