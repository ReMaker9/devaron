Downtimes= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.DownDate=(Init.DownDate) ? Init.DownDate : '';
	this.Minutes=(Init.Minutes) ? Init.Minutes : '';
	this.Shift=(Init.Shift) ? Init.Shift : '';
	this.MaschineName=(Init.MaschineName) ? Init.MaschineName : '';
	this.PlanningEntryTypeId=(Init.PlanningEntryTypeId) ? Init.PlanningEntryTypeId : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getDownDate = function()
	{
		return this.DownDate;
	}
		this.setDownDate = function(DownDate)
	{
		this.DownDate=DownDate;
	}

	this.getMinutes = function()
	{
		return this.Minutes;
	}
		this.setMinutes = function(Minutes)
	{
		this.Minutes=Minutes;
	}

	this.getShift = function()
	{
		return this.Shift;
	}
		this.setShift = function(Shift)
	{
		this.Shift=Shift;
	}

	this.getMaschineName = function()
	{
		return this.MaschineName;
	}
		this.setMaschineName = function(MaschineName)
	{
		this.MaschineName=MaschineName;
	}

	this.getPlanningEntryTypeId = function()
	{
		return this.PlanningEntryTypeId;
	}
		this.setPlanningEntryTypeId = function(PlanningEntryTypeId)
	{
		this.PlanningEntryTypeId=PlanningEntryTypeId;
	}

}