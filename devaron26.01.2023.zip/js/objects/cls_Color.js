Color= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.Year=(Init.Year) ? Init.Year : '';
	this.Week=(Init.Week) ? Init.Week : '';
	this.TemplateId=(Init.TemplateId) ? Init.TemplateId : '';
	this.DataId=(Init.DataId) ? Init.DataId : '';
	this.Sort=(Init.Sort) ? Init.Sort : '';
	this.Day=(Init.Day) ? Init.Day : '';
	this.Value=(Init.Value) ? Init.Value : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getYear = function()
	{
		return this.Year;
	}
		this.setYear = function(Year)
	{
		this.Year=Year;
	}

	this.getWeek = function()
	{
		return this.Week;
	}
		this.setWeek = function(Week)
	{
		this.Week=Week;
	}

	this.getTemplateId = function()
	{
		return this.TemplateId;
	}
		this.setTemplateId = function(TemplateId)
	{
		this.TemplateId=TemplateId;
	}

	this.getDataId = function()
	{
		return this.DataId;
	}
		this.setDataId = function(DataId)
	{
		this.DataId=DataId;
	}

	this.getSort = function()
	{
		return this.Sort;
	}
		this.setSort = function(Sort)
	{
		this.Sort=Sort;
	}

	this.getDay = function()
	{
		return this.Day;
	}
		this.setDay = function(Day)
	{
		this.Day=Day;
	}

	this.getValue = function()
	{
		return this.Value;
	}
		this.setValue = function(Value)
	{
		this.Value=Value;
	}

}