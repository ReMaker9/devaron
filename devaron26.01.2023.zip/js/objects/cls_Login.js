Login= function(Init)
{
	this.Id=(Init.Id) ? Init.Id : '';
	this.CreateDate=(Init.CreateDate) ? Init.CreateDate : '';
	this.UserId=(Init.UserId) ? Init.UserId : '';
	this.UserTable=(Init.UserTable) ? Init.UserTable : '';
	this.Ip=(Init.Ip) ? Init.Ip : '';
	this.Browser=(Init.Browser) ? Init.Browser : '';
	this.OS=(Init.OS) ? Init.OS : '';
	this.UserName=(Init.UserName) ? Init.UserName : '';
	this.City=(Init.City) ? Init.City : '';
	this.Country=(Init.Country) ? Init.Country : '';
	this.LoginSuccess=(Init.LoginSuccess) ? Init.LoginSuccess : '';
		this.getId = function()
	{
		return this.Id;
	}
		this.setId = function(Id)
	{
		this.Id=Id;
	}

	this.getCreateDate = function()
	{
		return this.CreateDate;
	}
		this.setCreateDate = function(CreateDate)
	{
		this.CreateDate=CreateDate;
	}

	this.getUserId = function()
	{
		return this.UserId;
	}
		this.setUserId = function(UserId)
	{
		this.UserId=UserId;
	}

	this.getUserTable = function()
	{
		return this.UserTable;
	}
		this.setUserTable = function(UserTable)
	{
		this.UserTable=UserTable;
	}

	this.getIp = function()
	{
		return this.Ip;
	}
		this.setIp = function(Ip)
	{
		this.Ip=Ip;
	}

	this.getBrowser = function()
	{
		return this.Browser;
	}
		this.setBrowser = function(Browser)
	{
		this.Browser=Browser;
	}

	this.getOS = function()
	{
		return this.OS;
	}
		this.setOS = function(OS)
	{
		this.OS=OS;
	}

	this.getUserName = function()
	{
		return this.UserName;
	}
		this.setUserName = function(UserName)
	{
		this.UserName=UserName;
	}

	this.getCity = function()
	{
		return this.City;
	}
		this.setCity = function(City)
	{
		this.City=City;
	}

	this.getCountry = function()
	{
		return this.Country;
	}
		this.setCountry = function(Country)
	{
		this.Country=Country;
	}

	this.getLoginSuccess = function()
	{
		return this.LoginSuccess;
	}
		this.setLoginSuccess = function(LoginSuccess)
	{
		this.LoginSuccess=LoginSuccess;
	}

}